@echo off
setlocal
cd /d "%~dp0"
docker compose -p itcontrol-community-rc --env-file .env stop
