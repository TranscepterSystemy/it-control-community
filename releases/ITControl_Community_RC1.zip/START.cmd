@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title IT.Control Community RC1

set "PROJECT=itcontrol-community-rc"
set "ENVFILE=%~dp0.env"
set "LOGFILE=%~dp0STARTUP_ERROR.log"
if exist "%LOGFILE%" del /q "%LOGFILE%" >nul 2>nul

where docker >nul 2>nul
if errorlevel 1 (
  echo Docker Desktop is required to run IT.Control Community RC1.
  echo Docker CLI not found.>"%LOGFILE%"
  pause
  exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
  echo Docker Desktop is not running. Start Docker Desktop and launch IT.Control again.
  echo Docker Desktop is not running.>"%LOGFILE%"
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Configure-Startup.ps1" >>"%LOGFILE%" 2>&1
if errorlevel 1 (
  echo Startup configuration failed. See STARTUP_ERROR.log for details.
  type "%LOGFILE%"
  pause
  exit /b 1
)
set "RC_SETUP_TOKEN="
for /f "tokens=1,* delims==" %%A in ('findstr /B /C:"ITCONTROL_SETUP_TOKEN=" .env') do set "RC_SETUP_TOKEN=%%B"

rem Validate that both generated values really reached .env before Docker sees them.
set "CHECK_DB_PASSWORD="
set "CHECK_PORT="
for /f "tokens=1,* delims==" %%A in ('findstr /B /C:"POSTGRES_PASSWORD=" .env') do set "CHECK_DB_PASSWORD=%%B"
for /f "tokens=1,* delims==" %%A in ('findstr /B /C:"WEB_PORT=" .env') do set "CHECK_PORT=%%B"
if not defined CHECK_DB_PASSWORD (
  echo Internal startup error: database password was not written to .env.
  echo POSTGRES_PASSWORD is empty in .env.>"%LOGFILE%"
  pause
  exit /b 1
)
if not defined CHECK_PORT (
  echo Internal startup error: web port was not written to .env.
  echo WEB_PORT is empty in .env.>"%LOGFILE%"
  pause
  exit /b 1
)
set "RC_PORT=!CHECK_PORT!"

echo.
echo IT.Control Community RC1
echo Starting isolated RC environment on http://localhost:!RC_PORT!/
echo.

docker compose -p %PROJECT% --env-file .env config >nul 2>"%LOGFILE%"
if errorlevel 1 goto FAILED

docker compose -p %PROJECT% --env-file .env up -d --build >>"%LOGFILE%" 2>&1
if errorlevel 1 goto FAILED

echo Waiting for IT.Control...
set /a tries=0
:WAIT_WEB
set /a tries+=1
powershell -NoProfile -Command "try{$r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:!RC_PORT!/api/health' -TimeoutSec 2;if($r.StatusCode -eq 200){exit 0}}catch{};exit 1" >nul 2>nul
if not errorlevel 1 goto READY

set "WEB_RUNNING="
for /f %%S in ('docker compose -p %PROJECT% --env-file .env ps --status running -q web 2^>nul') do set "WEB_RUNNING=%%S"
if not defined WEB_RUNNING if !tries! GEQ 5 goto FAILED
if !tries! GEQ 45 goto FAILED
timeout /t 2 /nobreak >nul
goto WAIT_WEB

:READY
if exist "%LOGFILE%" del /q "%LOGFILE%" >nul 2>nul
echo IT.Control Community RC1 is ready.
set "RC_FRAGMENT="
for /f %%S in ('powershell -NoProfile -Command "(Invoke-RestMethod http://localhost:!RC_PORT!/api/auth/status).setup_required"') do if /I "%%S"=="True" set "RC_FRAGMENT=#setup=!RC_SETUP_TOKEN!"
start "" "http://localhost:!RC_PORT!/!RC_FRAGMENT!"
exit /b 0

:FAILED
echo.
echo IT.Control did not start correctly.
echo Diagnostic information is saved in STARTUP_ERROR.log.
echo.>>"%LOGFILE%"
echo ==== compose config (secrets hidden) ====>>"%LOGFILE%"
docker compose -p %PROJECT% --env-file .env config 2>&1 | powershell -NoProfile -Command "$input -replace '(?i)(POSTGRES_PASSWORD: ).*','$1***' -replace '(?i)(PGPASSWORD: ).*','$1***' -replace '(?i)(ITCONTROL_SETUP_TOKEN: ).*','$1***' -replace '(postgresql\+psycopg://[^:]+:)[^@]+@','$1***@'" >>"%LOGFILE%"
echo.>>"%LOGFILE%"
echo ==== compose ps ====>>"%LOGFILE%"
docker compose -p %PROJECT% --env-file .env ps -a >>"%LOGFILE%" 2>&1
echo.>>"%LOGFILE%"
echo ==== web logs ====>>"%LOGFILE%"
docker compose -p %PROJECT% --env-file .env logs --no-color --tail=250 web >>"%LOGFILE%" 2>&1
echo.>>"%LOGFILE%"
echo ==== db logs ====>>"%LOGFILE%"
docker compose -p %PROJECT% --env-file .env logs --no-color --tail=100 db >>"%LOGFILE%" 2>&1
pause
exit /b 1
