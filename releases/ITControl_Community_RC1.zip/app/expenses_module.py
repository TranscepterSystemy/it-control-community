from __future__ import annotations

import io
from datetime import date, datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import Date, DateTime, Integer, Numeric, String, Text, select
from sqlalchemy.orm import Mapped, mapped_column

Expense = None
_m = None

CATEGORY_LABELS = {
    "equipment": "Оборудование",
    "software": "ПО и лицензии",
    "communications": "Связь и интернет",
    "repair": "Ремонт",
    "consumables": "Расходники",
    "services": "Услуги",
    "subscription": "Подписки",
    "leasing": "Аренда / лизинг",
    "other": "Прочее",
}

STATUS_LABELS = {
    "planned": "Запланировано",
    "paid": "Оплачено",
    "documents_pending": "Ждём документы",
    "closed": "Закрыто",
}

PAYMENT_LABELS = {
    "bank": "Безналичный расчёт",
    "corporate_card": "Корпоративная карта",
    "cash": "Наличные",
    "personal": "Личные средства",
    "other": "Другое",
}


class ExpenseIn(BaseModel):
    expense_date: date
    category: str = "equipment"
    description: str
    amount: float
    currency: str = "RUB"
    vendor_name: Optional[str] = None
    contractor_id: Optional[int] = None
    contract_id: Optional[int] = None
    asset_id: Optional[int] = None
    employee_id: Optional[int] = None
    department_id: Optional[int] = None
    site_id: Optional[int] = None
    buyer_name: Optional[str] = None
    payment_method: Optional[str] = "bank"
    status: str = "paid"
    document_type: Optional[str] = None
    document_number: Optional[str] = None
    document_date: Optional[date] = None
    document_location: Optional[str] = None
    notes: Optional[str] = None


def _money(v):
    return float(v or 0)


def _label(mapping, value):
    return mapping.get(value or "", value or "—")


def _audit(s, action: str, details: str):
    if _m is not None:
        s.add(_m.AuditLog(action=action, details=details))


def _optional_contractors():
    try:
        from app import contractors_module as cm
        if cm.Contractor is not None:
            return cm
    except Exception:
        pass
    return None


def _ensure_org_entity(s, model, entity_id, organization_id, label):
    if not entity_id:
        return None
    x = s.get(model, entity_id)
    if not x or getattr(x, "organization_id", None) != organization_id:
        raise _m.HTTPException(404, f"{label} не найден")
    return x


def _validate_links(s, data: dict, organization_id: int):
    _ensure_org_entity(s, _m.Asset, data.get("asset_id"), organization_id, "Оборудование")
    _ensure_org_entity(s, _m.Employee, data.get("employee_id"), organization_id, "Сотрудник")
    _ensure_org_entity(s, _m.Department, data.get("department_id"), organization_id, "Подразделение")
    _ensure_org_entity(s, _m.Site, data.get("site_id"), organization_id, "Площадка")

    cm = _optional_contractors()
    contractor = None
    contract = None
    if data.get("contractor_id"):
        if not cm:
            raise _m.HTTPException(400, "Модуль контрагентов недоступен")
        contractor = s.get(cm.Contractor, data["contractor_id"])
        if not contractor or contractor.organization_id != organization_id:
            raise _m.HTTPException(404, "Контрагент не найден")
    if data.get("contract_id"):
        if not cm:
            raise _m.HTTPException(400, "Модуль договоров недоступен")
        contract = s.get(cm.Contract, data["contract_id"])
        if not contract or contract.organization_id != organization_id:
            raise _m.HTTPException(404, "Договор не найден")
        if contractor and contract.contractor_id != contractor.id:
            raise _m.HTTPException(400, "Договор не относится к выбранному контрагенту")
    if contractor and not (data.get("vendor_name") or "").strip():
        data["vendor_name"] = contractor.name
    return data


def _expense_dict(s, x):
    asset = s.get(_m.Asset, x.asset_id) if x.asset_id else None
    employee = s.get(_m.Employee, x.employee_id) if x.employee_id else None
    department = s.get(_m.Department, x.department_id) if x.department_id else None
    site = s.get(_m.Site, x.site_id) if x.site_id else None

    contractor_name = None
    contract_number = None
    cm = _optional_contractors()
    if cm:
        if x.contractor_id:
            c = s.get(cm.Contractor, x.contractor_id)
            contractor_name = c.name if c else None
        if x.contract_id:
            c = s.get(cm.Contract, x.contract_id)
            contract_number = c.number if c else None

    return {
        "id": x.id,
        "expense_date": str(x.expense_date),
        "category": x.category,
        "category_label": _label(CATEGORY_LABELS, x.category),
        "description": x.description,
        "amount": _money(x.amount),
        "currency": x.currency,
        "vendor_name": x.vendor_name or contractor_name,
        "contractor_id": x.contractor_id,
        "contractor": contractor_name,
        "contract_id": x.contract_id,
        "contract": contract_number,
        "asset_id": x.asset_id,
        "asset": (asset.inventory_no or f"#{asset.id}") if asset else None,
        "employee_id": x.employee_id,
        "employee": employee.name if employee else None,
        "department_id": x.department_id,
        "department": department.name if department else None,
        "site_id": x.site_id,
        "site": site.name if site else None,
        "buyer_name": x.buyer_name,
        "payment_method": x.payment_method,
        "payment_method_label": _label(PAYMENT_LABELS, x.payment_method),
        "status": x.status,
        "status_label": _label(STATUS_LABELS, x.status),
        "document_type": x.document_type,
        "document_number": x.document_number,
        "document_date": str(x.document_date) if x.document_date else None,
        "document_location": x.document_location,
        "notes": x.notes,
        "created_at": x.created_at.isoformat() if x.created_at else None,
        "updated_at": x.updated_at.isoformat() if x.updated_at else None,
    }


def _expense_rows(s, organization_id: int):
    return s.scalars(
        select(Expense)
        .where(Expense.organization_id == organization_id)
        .order_by(Expense.expense_date.desc(), Expense.id.desc())
    ).all()


def register(m):
    global Expense, _m
    if Expense is not None:
        return
    _m = m

    class ExpenseModel(m.Base):
        __tablename__ = "it_expenses"
        id: Mapped[int] = mapped_column(Integer, primary_key=True)
        organization_id: Mapped[int] = mapped_column(Integer, index=True)
        expense_date: Mapped[date] = mapped_column(Date, index=True)
        category: Mapped[str] = mapped_column(String(40), default="equipment", index=True)
        description: Mapped[str] = mapped_column(String(300))
        amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
        currency: Mapped[str] = mapped_column(String(8), default="RUB")
        vendor_name: Mapped[Optional[str]] = mapped_column(String(220), nullable=True)
        contractor_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        contract_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        asset_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        employee_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        department_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        site_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
        buyer_name: Mapped[Optional[str]] = mapped_column(String(180), nullable=True)
        payment_method: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
        status: Mapped[str] = mapped_column(String(40), default="paid", index=True)
        document_type: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
        document_number: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
        document_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
        document_location: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
        updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    Expense = ExpenseModel
    m.Base.metadata.create_all(m.engine, tables=[Expense.__table__])

    @m.app.get("/api/expenses")
    def expense_list(s=m.Depends(m.db), organization_id: int = m.Depends(m.current_organization_id)):
        return [_expense_dict(s, x) for x in _expense_rows(s, organization_id)]

    @m.app.get("/api/expenses/summary")
    def expense_summary(s=m.Depends(m.db), organization_id: int = m.Depends(m.current_organization_id)):
        rows = _expense_rows(s, organization_id)
        today = date.today()
        month_total = Decimal("0")
        year_total = Decimal("0")
        all_total = Decimal("0")
        docs_missing = 0
        by_category = {}
        for x in rows:
            amount = Decimal(x.amount or 0)
            if x.status != "planned":
                all_total += amount
                if x.expense_date.year == today.year:
                    year_total += amount
                    if x.expense_date.month == today.month:
                        month_total += amount
                by_category[x.category] = by_category.get(x.category, Decimal("0")) + amount
            if not (x.document_location or "").strip() and x.status in ("paid", "documents_pending", "closed"):
                docs_missing += 1
        return {
            "count": len(rows),
            "month_total": float(month_total),
            "year_total": float(year_total),
            "all_total": float(all_total),
            "documents_missing": docs_missing,
            "by_category": [
                {"category": k, "label": _label(CATEGORY_LABELS, k), "amount": float(v)}
                for k, v in sorted(by_category.items(), key=lambda item: item[1], reverse=True)
            ],
        }

    @m.app.post("/api/expenses")
    def expense_add(
        d: ExpenseIn,
        s=m.Depends(m.db),
        organization_id: int = m.Depends(m.current_organization_id),
        actor=m.Depends(m.require_org_admin),
    ):
        data = _validate_links(s, d.model_dump(), organization_id)
        x = Expense(organization_id=organization_id, **data)
        s.add(x)
        _audit(s, "Расход добавлен", f"{x.description}; {x.amount} {x.currency}; {actor.username}")
        m.safe_commit(s, "Расход")
        s.refresh(x)
        return _expense_dict(s, x)

    @m.app.put("/api/expenses/{expense_id}")
    def expense_edit(
        expense_id: int,
        d: ExpenseIn,
        s=m.Depends(m.db),
        organization_id: int = m.Depends(m.current_organization_id),
        actor=m.Depends(m.require_org_admin),
    ):
        x = s.get(Expense, expense_id)
        if not x or x.organization_id != organization_id:
            raise m.HTTPException(404, "Расход не найден")
        data = _validate_links(s, d.model_dump(), organization_id)
        for k, v in data.items():
            setattr(x, k, v)
        _audit(s, "Расход изменён", f"#{x.id} {x.description}; {actor.username}")
        m.safe_commit(s, "Расход")
        return _expense_dict(s, x)

    @m.app.delete("/api/expenses/{expense_id}")
    def expense_delete(
        expense_id: int,
        s=m.Depends(m.db),
        organization_id: int = m.Depends(m.current_organization_id),
        actor=m.Depends(m.require_main_admin),
    ):
        x = s.get(Expense, expense_id)
        if not x or x.organization_id != organization_id:
            raise m.HTTPException(404, "Расход не найден")
        details = f"#{x.id} {x.description}; {x.amount} {x.currency}; {actor.username}"
        s.delete(x)
        _audit(s, "Расход удалён", details)
        m.safe_commit(s, "Расход")
        return {"ok": True}

    @m.app.get("/api/expenses/export.xlsx")
    def expense_export(s=m.Depends(m.db), organization_id: int = m.Depends(m.current_organization_id)):
        wb = m.Workbook()
        ws = wb.active
        ws.title = "Расходы"
        ws.append([
            "Дата", "Категория", "Что купили / за что платили", "Сумма", "Валюта",
            "Поставщик", "Контрагент", "Договор", "Для сотрудника", "Подразделение",
            "Площадка", "Оборудование", "Кто купил", "Способ оплаты", "Статус",
            "Тип документа", "№ документа", "Дата документа", "Где хранится документ",
            "Комментарий",
        ])
        for x in _expense_rows(s, organization_id):
            r = _expense_dict(s, x)
            ws.append([
                r["expense_date"], r["category_label"], r["description"], r["amount"], r["currency"],
                r["vendor_name"], r["contractor"], r["contract"], r["employee"], r["department"],
                r["site"], r["asset"], r["buyer_name"], r["payment_method_label"], r["status_label"],
                r["document_type"], r["document_number"], r["document_date"], r["document_location"],
                r["notes"],
            ])
        header_fill = m.PatternFill("solid", fgColor="DDEFE8")
        header_font = m.Font(bold=True, color="18392F")
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = m.Alignment(vertical="center", wrap_text=True)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            letter = col[0].column_letter
            maxlen = max([len(str(c.value)) if c.value is not None else 0 for c in col] or [0])
            ws.column_dimensions[letter].width = min(max(maxlen + 2, 12), 42)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = m.Alignment(vertical="top", wrap_text=True)
        b = io.BytesIO()
        wb.save(b)
        b.seek(0)
        return m.StreamingResponse(
            b,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=it_expenses.xlsx"},
        )
