"""Server-side sessions and fail-closed API authorization for Community."""
from datetime import datetime, timedelta
import hashlib
import os
import posixpath
import secrets
from urllib.parse import urlsplit

from fastapi import HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, Integer, String, select, text, func
from sqlalchemy.orm import Mapped, mapped_column

from app import main as core

COOKIE = "itcontrol_session"
SESSION_SECONDS = 12 * 60 * 60
MAIN_ADMIN = "Главный администратор"
WRITERS = {MAIN_ADMIN, "Администратор организации", "Администратор", "ИТ-специалист"}
PUBLIC = {"/api/health", "/api/product-info", "/api/auth/status", "/api/auth/login", "/api/auth/setup"}
ADMIN_PREFIXES = ("/api/admin", "/api/updates", "/api/migration", "/api/vault")


class AuthSession(core.Base):
    __tablename__ = "auth_sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    password_fingerprint: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)


class AuthThrottle(core.Base):
    __tablename__ = "auth_throttle"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime)


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=1024)


class SetupIn(BaseModel):
    token: str = Field(min_length=1, max_length=256)
    password: str = Field(min_length=12, max_length=1024)


def _digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _lock_writes(session):
    # Serializes first-run setup and rate counters on both supported databases.
    if core.engine.dialect.name == "sqlite":
        session.connection().exec_driver_sql("BEGIN IMMEDIATE")


def _throttle(request, username):
    now = datetime.utcnow()
    ip = request.client.host if request.client else "unknown"
    keys = [(_digest("account:" + ip + ":" + username.strip().casefold()), 15),
            (_digest("ip:" + ip), 300)]
    with core.SessionLocal() as session:
        _lock_writes(session)
        for key, maximum in keys:
            session.execute(text("INSERT INTO auth_throttle (key, attempts, started_at) "
                                 "VALUES (:key, 0, :now) ON CONFLICT (key) DO NOTHING"),
                            {"key": key, "now": now})
            row = session.scalar(select(AuthThrottle).where(AuthThrottle.key == key).with_for_update())
            if row.started_at < now - timedelta(minutes=5):
                row.started_at, row.attempts = now, 0
            if row.attempts >= maximum:
                raise HTTPException(429, "Слишком много попыток. Повторите через 5 минут.", headers={"Retry-After": "300"})
            row.attempts += 1
        session.commit()


def _setup_admin(session):
    # If ANY main administrator already has a password, public bootstrap is closed.
    admins = session.scalars(select(core.AppUser).where(core.AppUser.role == MAIN_ADMIN).with_for_update()).all()
    if any(user.password_hash for user in admins):
        return None
    active = [user for user in admins if user.is_active]
    return active[0] if len(active) == 1 else None


def _issue(session, user, request, response):
    old = request.cookies.get(COOKIE, "")
    if old:
        previous = session.get(AuthSession, _digest(old))
        if previous:
            session.delete(previous)
    token = secrets.token_urlsafe(32)
    session.add(AuthSession(token_hash=_digest(token), user_id=user.id,
                            password_fingerprint=_digest(user.password_hash),
                            expires_at=datetime.utcnow() + timedelta(seconds=SESSION_SECONDS)))
    session.query(AuthSession).filter(AuthSession.expires_at <= datetime.utcnow()).delete(synchronize_session=False)
    session.add(core.AuditLog(action="Вход в систему", details=f"{user.display_name} ({user.username})"))
    session.commit()
    response.set_cookie(COOKIE, token, max_age=SESSION_SECONDS, httponly=True,
                        secure=request.url.scheme == "https", samesite="strict", path="/")
    response.headers["Cache-Control"] = "no-store"
    return core._user_dict(user, session)


def install_security(app):
    core.Base.metadata.create_all(core.engine)

    @app.middleware("http")
    async def security_boundary(request: Request, call_next):
        path = posixpath.normpath("/" + request.url.path.lstrip("/"))
        if path.startswith("/api/") or path.startswith("/static/map-backgrounds/"):
            if request.method not in {"GET", "HEAD", "OPTIONS"}:
                origin = request.headers.get("origin")
                if (request.headers.get("X-ITControl-Request") != "1" or
                        request.headers.get("sec-fetch-site") == "cross-site" or
                        (origin and urlsplit(origin).netloc != request.url.netloc) or
                        (origin and urlsplit(origin).scheme != request.url.scheme)):
                    return JSONResponse({"detail": "Запрос отклонён: защита от межсайтовых запросов."}, status_code=403)
            if path not in PUBLIC:
                token = request.cookies.get(COOKIE, "")
                with core.SessionLocal() as session:
                    row = session.get(AuthSession, _digest(token)) if token else None
                    user = session.get(core.AppUser, row.user_id) if row else None
                    if (not row or row.expires_at <= datetime.utcnow() or not user or not user.is_active or
                            not user.password_hash or not secrets.compare_digest(row.password_fingerprint, _digest(user.password_hash))):
                        return JSONResponse({"detail": "Войдите в систему"}, status_code=401, headers={"Cache-Control": "no-store"})
                    request.state.authenticated_user_id = user.id
                    if user.role != MAIN_ADMIN and path != "/api/auth/logout":
                        # Community has one organization. Fail closed on older
                        # multi-organization databases rather than expose global legacy queries.
                        organizations = session.scalars(select(core.Organization)).all()
                        if (len(organizations) != 1 or not organizations[0].is_active or
                                user.organization_id != organizations[0].id):
                            return JSONResponse({"detail": "Учётная запись не привязана к единственной активной организации Community."}, status_code=403)
                        admin_path = any(path == p or path.startswith(p + "/") for p in ADMIN_PREFIXES)
                        admin_path |= path in {"/api/audit", "/api/system/postgres", "/api/assets/bulk-org"}
                        admin_path |= path.startswith("/api/users") and request.method not in {"GET", "HEAD"}
                        admin_path |= path.startswith("/api/organizations") and request.method not in {"GET", "HEAD"}
                        if admin_path or (path != "/api/auth/logout" and request.method not in {"GET", "HEAD", "OPTIONS"} and user.role not in WRITERS):
                            return JSONResponse({"detail": "Недостаточно прав для этой операции."}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        if path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/api/auth/status")
    def status(request: Request):
        with core.SessionLocal() as session:
            setup_required = _setup_admin(session) is not None
            raw = request.cookies.get(COOKIE, "")
            row = session.get(AuthSession, _digest(raw)) if raw else None
            user = session.get(core.AppUser, row.user_id) if row else None
            valid = (row and row.expires_at > datetime.utcnow() and user and user.is_active and user.password_hash
                     and secrets.compare_digest(row.password_fingerprint, _digest(user.password_hash)))
            return {"setup_required": setup_required, "user": core._user_dict(user, session) if valid else None}

    @app.post("/api/auth/setup")
    def setup(data: SetupIn, request: Request, response: Response):
        _throttle(request, "first-run-setup")
        expected = os.getenv("ITCONTROL_SETUP_TOKEN", "")
        if len(expected) < 32 or not secrets.compare_digest(data.token.encode("utf-8"), expected.encode("utf-8")):
            raise HTTPException(403, "Неверный код первоначальной настройки. Запусти START.cmd на сервере.")
        with core.SessionLocal() as session:
            _lock_writes(session)
            user = _setup_admin(session)
            if user is None:
                raise HTTPException(409, "Первоначальная настройка уже завершена. Используй вход по паролю.")
            user.password_hash = core._password_hash(data.password)
            session.add(core.AuditLog(action="Первоначальная настройка", details="Главному администратору назначен пароль"))
            # Persist the password before creating the session to close bootstrap atomically.
            session.flush()
            return _issue(session, user, request, response)

    @app.post("/api/auth/login")
    def login(data: LoginIn, request: Request, response: Response):
        _throttle(request, data.username)
        with core.SessionLocal() as session:
            user = session.scalar(select(core.AppUser).where(func.lower(core.AppUser.username) == data.username.strip().lower()))
            # Equal-cost verification also for unknown users and unconfigured accounts.
            stored = user.password_hash if user and user.password_hash else DUMMY_PASSWORD
            verified = core._password_verify(data.password, stored)
            if not user or not user.is_active or not user.password_hash or not verified:
                raise HTTPException(401, "Неверный логин или пароль")
            return _issue(session, user, request, response)

    @app.post("/api/auth/logout")
    def logout(request: Request, response: Response):
        with core.SessionLocal() as session:
            raw = request.cookies.get(COOKIE, "")
            row = session.get(AuthSession, _digest(raw)) if raw else None
            if row:
                session.delete(row)
                session.commit()
        response.delete_cookie(COOKIE, httponly=True, samesite="strict", path="/")
        return {"ok": True}


DUMMY_PASSWORD = core._password_hash(secrets.token_urlsafe(32))
