from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy import event, func, select, text
from sqlalchemy.orm import Session as SASession

from app.main import (
    app,
    Organization,
    Company,
    Site,
    Employee,
    Workplace,
    Asset,
    NasDevice,
    AppUser,
)

PRODUCT_EDITION = "Community"
PRODUCT_CHANNEL = "RC1"
PRODUCT_VERSION = "2.0.0-RC1"

# Community is intentionally restricted both by capabilities and by scale.
# Existing data remains readable/editable after a limit is reached; only creation
# of additional records is blocked.
COMMUNITY_LIMITS = {
    "organizations": 1,
    "companies": 1,
    "sites": 3,
    "employees": 25,
    "workplaces": 25,
    "equipment_total": 25,  # Asset + NAS; servers/printers are Assets.
    "users_total": 3,       # one main administrator + two additional users.
}

BLOCKED_PREFIXES = (
    "/api/control",
    "/api/wireguard",
    "/api/modules/wireguard",
)


def _count_rows(session: SASession, model) -> int:
    return int(session.connection().execute(select(func.count()).select_from(model)).scalar_one() or 0)


def _new_count(session: SASession, model) -> int:
    return sum(1 for obj in session.new if isinstance(obj, model))


def _limit_error(label: str, limit: int) -> HTTPException:
    return HTTPException(
        status_code=403,
        detail=(
            f"Достигнут лимит Community: {label} — {limit}. "
            "Существующие данные остаются доступными для просмотра и редактирования. "
            "Для добавления новых объектов требуется расширенная лицензия IT.Control."
        ),
    )


@event.listens_for(SASession, "before_flush")
def _community_quota_guard(session, flush_context, instances):
    limited_models = (Organization, Company, Site, Employee, Workplace, Asset, NasDevice, AppUser)
    if not any(isinstance(obj, limited_models) for obj in session.new):
        return
    connection = session.connection()
    if connection.dialect.name == "postgresql":
        connection.execute(text("SELECT pg_advisory_xact_lock(748219631)"))
    elif connection.dialect.name == "sqlite":
        raw = connection.connection.driver_connection
        if not raw.in_transaction:
            connection.exec_driver_sql("BEGIN IMMEDIATE")
    # Check only entity types being created in this flush. This lets existing
    # installations that are already over a limit remain readable/editable.
    checks = (
        (Organization, COMMUNITY_LIMITS["organizations"], "организаций"),
        (Company, COMMUNITY_LIMITS["companies"], "компаний"),
        (Site, COMMUNITY_LIMITS["sites"], "площадок"),
        (Employee, COMMUNITY_LIMITS["employees"], "сотрудников"),
        (Workplace, COMMUNITY_LIMITS["workplaces"], "рабочих мест"),
        (AppUser, COMMUNITY_LIMITS["users_total"], "пользователей"),
    )
    for model, limit, label in checks:
        created = _new_count(session, model)
        if not created:
            continue
        if _count_rows(session, model) + created > limit:
            raise _limit_error(label, limit)

    new_assets = _new_count(session, Asset)
    new_nas = _new_count(session, NasDevice)
    if new_assets or new_nas:
        current_equipment = _count_rows(session, Asset) + _count_rows(session, NasDevice)
        if current_equipment + new_assets + new_nas > COMMUNITY_LIMITS["equipment_total"]:
            raise _limit_error("единиц оборудования (включая NAS)", COMMUNITY_LIMITS["equipment_total"])


@app.middleware("http")
async def community_edition_gate(request: Request, call_next):
    path = request.url.path.rstrip("/") or "/"
    if any(path == prefix or path.startswith(prefix + "/") for prefix in BLOCKED_PREFIXES):
        return JSONResponse(
            status_code=403,
            content={
                "detail": "Функция не входит в редакцию IT.Control Community.",
                "edition": PRODUCT_EDITION,
                "paid_capability": True,
            },
        )
    return await call_next(request)


@app.get("/api/health", include_in_schema=False)
def community_health():
    return {
        "ok": True,
        "product": "IT.Control",
        "edition": PRODUCT_EDITION,
        "channel": PRODUCT_CHANNEL,
        "version": PRODUCT_VERSION,
    }


@app.get("/api/product-info", include_in_schema=False)
def community_product_info():
    return {
        "product": "IT.Control",
        "edition": PRODUCT_EDITION,
        "channel": PRODUCT_CHANNEL,
        "version": PRODUCT_VERSION,
        "licensing_model": "feature_and_scale",
        "quantitative_limits": COMMUNITY_LIMITS,
        "features": {
            "manual_inventory": True,
            "excel_import_export": True,
            "organization_structure": True,
            "helpdesk": True,
            "nas": True,
            "inventory_sessions": True,
            "manual_software_inventory": True,
            "monitoring": False,
            "agents": False,
            "collectors": False,
            "wireguard_automation": False,
            "deploy": False,
            "ad_modules": False,
        },
    }
