# LICENSE_ENGINE_V1
# License lifecycle foundation prepared in v1.1.0
from __future__ import annotations
import io, os, json, zipfile, shutil, subprocess, tempfile, re, threading, hashlib, secrets, socket, time, base64, ipaddress, ssl, urllib.request, urllib.parse, ssl, urllib.request, urllib.parse
from html import escape as html_escape
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, select, func, text, inspect
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session, sessionmaker
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
import qrcode
import barcode
from barcode.writer import SVGWriter
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from zoneinfo import ZoneInfo

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./inventory.db")
PREFIX = os.getenv("INVENTORY_PREFIX", "IT")
APP_DIR = Path(os.getenv("APP_DIR", "/app/app")).resolve()
UPDATE_DIR = Path(os.getenv("UPDATE_DIR", "/app/updates")).resolve()
BACKUP_DIR = UPDATE_DIR / "backups"
VAULT_CONFIG_FILE = UPDATE_DIR / "vault_master.json"
MIGRATION_LIMITS_FILE = UPDATE_DIR / "migration_limits.json"
VERSION_FILE = APP_DIR / "VERSION"
MAX_UPDATE_SIZE = 50 * 1024 * 1024
DEFAULT_MIGRATION_ARCHIVE_MB = 250
DEFAULT_MIGRATION_UNPACKED_MB = 2048
MIGRATION_HARD_ARCHIVE_MB = 2048
MIGRATION_HARD_UNPACKED_MB = 8192
MIGRATION_MAX_FILES = 100
MIGRATION_MAX_COMPRESSION_RATIO = 200
UPDATE_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

def current_version():
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip() or "1.0.0"
    except Exception:
        return "1.0.0"

def version_key(v: str):
    nums = [int(x) for x in re.findall(r"\d+", v)]
    return tuple(nums or [0])
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

class Base(DeclarativeBase): pass

class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), unique=True, index=True)
    organization_type: Mapped[str] = mapped_column(String(40), default="internal", index=True)
    is_active: Mapped[int] = mapped_column(Integer, default=1)
    service_status: Mapped[str] = mapped_column(String(30), default="active", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Company(Base):
    __tablename__ = "companies"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    organization: Mapped[Optional[Organization]] = relationship()

class Department(Base):
    __tablename__ = "departments"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    company: Mapped[Company] = relationship()

class Site(Base):
    __tablename__ = "sites"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    site_type: Mapped[Optional[str]] = mapped_column(String(60), nullable=True)
    address: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

class OrgUnit(Base):
    __tablename__ = "org_units"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"), index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    company: Mapped[Company] = relationship()

class Employee(Base):
    __tablename__ = "employees"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    department: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    org_unit_id: Mapped[Optional[int]] = mapped_column(ForeignKey("org_units.id"), nullable=True, index=True)
    location_id: Mapped[Optional[int]] = mapped_column(ForeignKey("locations.id"), nullable=True, index=True)
    position: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    personnel_no: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    work_phone: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    extension: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    mobile_phone: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    account_name: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    employment_status: Mapped[Optional[str]] = mapped_column(String(60), nullable=True, default="Работает")
    started_at: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    ended_at: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    company: Mapped[Optional[Company]] = relationship()
    department_rel: Mapped[Optional[Department]] = relationship()
    site: Mapped[Optional[Site]] = relationship()
    org_unit: Mapped[Optional[OrgUnit]] = relationship()
    location_rel: Mapped[Optional["Location"]] = relationship()

class Location(Base):
    __tablename__ = "locations"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    parent: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)

class Workplace(Base):
    __tablename__ = "workplaces"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(160))
    employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id"), nullable=True)
    location_id: Mapped[Optional[int]] = mapped_column(ForeignKey("locations.id"), nullable=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)
    employee: Mapped[Optional[Employee]] = relationship()
    location: Mapped[Optional[Location]] = relationship()

class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    inventory_no: Mapped[str] = mapped_column(String(80), index=True)
    category: Mapped[str] = mapped_column(String(100), index=True)
    manufacturer: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    serial_no: Mapped[Optional[str]] = mapped_column(String(160), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(60), default="На складе", index=True)
    employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id"), nullable=True)
    location_id: Mapped[Optional[int]] = mapped_column(ForeignKey("locations.id"), nullable=True)
    workplace_id: Mapped[Optional[int]] = mapped_column(ForeignKey("workplaces.id"), nullable=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)  # legacy
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    org_unit_id: Mapped[Optional[int]] = mapped_column(ForeignKey("org_units.id"), nullable=True, index=True)
    server_room_id: Mapped[Optional[int]] = mapped_column(ForeignKey("server_rooms.id"), nullable=True, index=True)
    rack_id: Mapped[Optional[int]] = mapped_column(ForeignKey("racks.id"), nullable=True, index=True)
    rack_unit: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    device_height_u: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    server_kind: Mapped[Optional[str]] = mapped_column(String(60), nullable=True)
    os_name: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    hypervisor: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    management_ip: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    primary_ip: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    purpose: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    cluster_name: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    purchase_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    warranty_until: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deletion_marked_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, index=True)
    deletion_marked_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    deletion_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    employee: Mapped[Optional[Employee]] = relationship()
    location: Mapped[Optional[Location]] = relationship()
    workplace: Mapped[Optional[Workplace]] = relationship()
    site: Mapped[Optional[Site]] = relationship()
    org_unit: Mapped[Optional[OrgUnit]] = relationship()


class AssetMap(Base):
    __tablename__ = "asset_maps"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    floor_name: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    background_file: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    canvas_width: Mapped[int] = mapped_column(Integer, default=1200)
    canvas_height: Mapped[int] = mapped_column(Integer, default=720)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    company: Mapped[Optional[Company]] = relationship()
    site: Mapped[Optional[Site]] = relationship()

class AssetMapNode(Base):
    __tablename__ = "asset_map_nodes"
    id: Mapped[int] = mapped_column(primary_key=True)
    map_id: Mapped[int] = mapped_column(ForeignKey("asset_maps.id"), index=True)
    node_type: Mapped[str] = mapped_column(String(40), index=True)  # asset/workplace/location/zone
    ref_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    label: Mapped[Optional[str]] = mapped_column(String(180), nullable=True)
    x: Mapped[int] = mapped_column(Integer, default=40)
    y: Mapped[int] = mapped_column(Integer, default=40)
    width: Mapped[int] = mapped_column(Integer, default=130)
    height: Mapped[int] = mapped_column(Integer, default=58)
    layer: Mapped[str] = mapped_column(String(40), default="equipment", index=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    map: Mapped[AssetMap] = relationship()

class AssetMapLink(Base):
    __tablename__ = "asset_map_links"
    id: Mapped[int] = mapped_column(primary_key=True)
    map_id: Mapped[int] = mapped_column(ForeignKey("asset_maps.id"), index=True)
    source_node_id: Mapped[int] = mapped_column(ForeignKey("asset_map_nodes.id"), index=True)
    target_node_id: Mapped[int] = mapped_column(ForeignKey("asset_map_nodes.id"), index=True)
    label: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    line_style: Mapped[str] = mapped_column(String(20), default="solid")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Component(Base):
    __tablename__ = "components"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    component_type: Mapped[str] = mapped_column(String(100), index=True)
    slot: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    manufacturer: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    serial_no: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    specification: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class ServerRoom(Base):
    __tablename__ = "server_rooms"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    company_id: Mapped[Optional[int]] = mapped_column(ForeignKey("companies.id"), nullable=True, index=True)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)  # legacy only
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    org_unit_id: Mapped[Optional[int]] = mapped_column(ForeignKey("org_units.id"), nullable=True, index=True)
    location_id: Mapped[Optional[int]] = mapped_column(ForeignKey("locations.id"), nullable=True, index=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    company: Mapped[Optional[Company]] = relationship()
    department_rel: Mapped[Optional[Department]] = relationship()
    site: Mapped[Optional[Site]] = relationship()
    org_unit: Mapped[Optional[OrgUnit]] = relationship()
    location: Mapped[Optional[Location]] = relationship()

class Rack(Base):
    __tablename__ = "racks"
    id: Mapped[int] = mapped_column(primary_key=True)
    server_room_id: Mapped[int] = mapped_column(ForeignKey("server_rooms.id"), index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    units: Mapped[int] = mapped_column(Integer, default=42)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    server_room: Mapped[ServerRoom] = relationship()

class PrintDeviceProfile(Base):
    __tablename__ = "print_device_profiles"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), unique=True, index=True)
    technology: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    color_mode: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    max_format: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    connection_type: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    network_name: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    asset: Mapped[Asset] = relationship()

class Consumable(Base):
    __tablename__ = "consumables"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    consumable_type: Mapped[str] = mapped_column(String(100), index=True)
    manufacturer: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    color: Mapped[Optional[str]] = mapped_column(String(60), nullable=True)
    sku: Mapped[Optional[str]] = mapped_column(String(120), nullable=True, index=True)
    resource: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    quantity: Mapped[int] = mapped_column(Integer, default=0)
    min_quantity: Mapped[int] = mapped_column(Integer, default=0)
    unit: Mapped[str] = mapped_column(String(40), default="шт.")
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ConsumableCompatibility(Base):
    __tablename__ = "consumable_compatibility"
    id: Mapped[int] = mapped_column(primary_key=True)
    consumable_id: Mapped[int] = mapped_column(ForeignKey("consumables.id"), index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)

class ConsumableMovement(Base):
    __tablename__ = "consumable_movements"
    id: Mapped[int] = mapped_column(primary_key=True)
    consumable_id: Mapped[int] = mapped_column(ForeignKey("consumables.id"), index=True)
    delta: Mapped[int] = mapped_column(Integer)
    reason: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

class Software(Base):
    __tablename__ = "software"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    vendor: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    version: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    license_type: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class SoftwareInstallation(Base):
    __tablename__ = "software_installations"
    id: Mapped[int] = mapped_column(primary_key=True)
    software_id: Mapped[int] = mapped_column(ForeignKey("software.id"), index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    installed_for_employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id"), nullable=True, index=True)
    installed_at: Mapped[date] = mapped_column(Date, default=date.today, index=True)
    environment: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    license_info: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    software: Mapped[Software] = relationship()
    asset: Mapped[Asset] = relationship()
    installed_for_employee: Mapped[Optional[Employee]] = relationship()

class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("assets.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(100))
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

class InventorySession(Base):
    __tablename__ = "inventory_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160))
    location_id: Mapped[Optional[int]] = mapped_column(ForeignKey("locations.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="Открыта")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class InventoryScan(Base):
    __tablename__ = "inventory_scans"
    id: Mapped[int] = mapped_column(primary_key=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("inventory_sessions.id"), index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    result: Mapped[str] = mapped_column(String(80), default="Найдено")
    scanned_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)















class VaultCredential(Base):
    __tablename__ = "vault_credentials"
    id: Mapped[int] = mapped_column(primary_key=True)
    system_name: Mapped[str] = mapped_column(String(180), index=True)
    category: Mapped[str] = mapped_column(String(80), default="Прочее", index=True)
    address: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    secret_ciphertext: Mapped[str] = mapped_column(Text)
    secret_nonce: Mapped[str] = mapped_column(String(120))
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("assets.id"), nullable=True, index=True)
    rotate_due: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    created_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    updated_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    asset: Mapped[Optional[Asset]] = relationship()

class VaultAudit(Base):
    __tablename__ = "vault_audit"
    id: Mapped[int] = mapped_column(primary_key=True)
    credential_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    system_name: Mapped[Optional[str]] = mapped_column(String(180), nullable=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    actor: Mapped[str] = mapped_column(String(160))
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

class UpdateRecord(Base):
    __tablename__ = "update_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    from_version: Mapped[str] = mapped_column(String(40))
    to_version: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(40), default="Установлено")
    package_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    backup_path: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class EquipmentTransfer(Base):
    __tablename__ = "equipment_transfers"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_no: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    document_type: Mapped[str] = mapped_column(String(20), default="transfer", index=True)  # transfer|return
    employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id"), nullable=True, index=True)
    parent_transfer_id: Mapped[Optional[int]] = mapped_column(ForeignKey("equipment_transfers.id"), nullable=True, index=True)
    transfer_date: Mapped[date] = mapped_column(Date, default=date.today, index=True)
    handed_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    received_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    asset_ids_json: Mapped[str] = mapped_column(Text, default="[]")
    snapshot_json: Mapped[str] = mapped_column(Text, default="{}")
    created_by: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class HelpdeskTicket(Base):
    __tablename__ = "helpdesk_tickets"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    ticket_no: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240), index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    category: Mapped[str] = mapped_column(String(60), default="Другое", index=True)
    priority: Mapped[str] = mapped_column(String(30), default="Обычный", index=True)
    status: Mapped[str] = mapped_column(String(30), default="Новая", index=True)
    requester_name: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    requester_email: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    assignee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("app_users.id"), nullable=True, index=True)
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    workplace_id: Mapped[Optional[int]] = mapped_column(ForeignKey("workplaces.id"), nullable=True, index=True)
    asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("assets.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

class HelpdeskComment(Base):
    __tablename__ = "helpdesk_comments"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("helpdesk_tickets.id"), index=True)
    author: Mapped[str] = mapped_column(String(160))
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

class NasDevice(Base):
    __tablename__ = "nas_devices"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    site_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    vendor: Mapped[str] = mapped_column(String(80), default="Synology", index=True)
    host: Mapped[str] = mapped_column(String(160), index=True)
    port: Mapped[int] = mapped_column(Integer, default=5001)
    use_https: Mapped[int] = mapped_column(Integer, default=1)
    model: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    dsm_version: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    serial_no: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="Не проверен", index=True)
    last_seen: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    details_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AppUser(Base):
    __tablename__ = "app_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    organization_id: Mapped[Optional[int]] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    username: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(String(40), default="Сотрудник", index=True)
    is_active: Mapped[int] = mapped_column(Integer, default=1)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    employee_id: Mapped[Optional[int]] = mapped_column(ForeignKey("employees.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    employee: Mapped[Optional[Employee]] = relationship()

Base.metadata.create_all(engine)

def ensure_schema_compatibility():
    """Non-destructive schema repair for incremental on-premise updates."""
    Base.metadata.create_all(engine)
    required_columns = {
        "companies": {"organization_id": "INTEGER"},
        "departments": {"organization_id": "INTEGER"},
        "sites": {"organization_id": "INTEGER"},
        "org_units": {"organization_id": "INTEGER"},
        "employees": {
            "organization_id": "INTEGER",
            "site_id": "INTEGER", "org_unit_id": "INTEGER", "location_id": "INTEGER",
            "position": "VARCHAR(160)", "personnel_no": "VARCHAR(80)",
            "work_phone": "VARCHAR(80)", "extension": "VARCHAR(40)",
            "mobile_phone": "VARCHAR(80)", "account_name": "VARCHAR(120)",
            "employment_status": "VARCHAR(60)", "started_at": "DATE",
            "ended_at": "DATE", "notes": "TEXT",
        },
        "locations": {"organization_id": "INTEGER"},
        "workplaces": {"organization_id": "INTEGER"},
        "assets": {"organization_id": "INTEGER", "site_id": "INTEGER", "org_unit_id": "INTEGER", "deletion_marked_at": "TIMESTAMP", "deletion_marked_by": "VARCHAR(160)", "deletion_reason": "TEXT"},
        "asset_maps": {"organization_id": "INTEGER"},
        "inventory_sessions": {"organization_id": "INTEGER"},
        "app_users": {"organization_id": "INTEGER"},
        "organizations": {"service_status": "VARCHAR(30) DEFAULT 'active'"},
        "nas_devices": {"site_id": "INTEGER"},
        "server_rooms": {"site_id": "INTEGER", "org_unit_id": "INTEGER"},
    }
    with engine.begin() as conn:
        for table_name, cols in required_columns.items():
            existing = {c["name"] for c in inspect(conn).get_columns(table_name)}
            for col_name, col_type in cols.items():
                if col_name not in existing:
                    conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}"))
        if engine.dialect.name == "postgresql":
            for stmt in (
                "CREATE INDEX IF NOT EXISTS ix_companies_organization_id ON companies(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_sites_organization_id ON sites(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_employees_organization_id ON employees(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_locations_organization_id ON locations(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_workplaces_organization_id ON workplaces(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_assets_organization_id ON assets(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_app_users_organization_id ON app_users(organization_id)",
                "CREATE INDEX IF NOT EXISTS ix_assets_site_id ON assets(site_id)",
                "CREATE INDEX IF NOT EXISTS ix_assets_org_unit_id ON assets(org_unit_id)",
                "CREATE INDEX IF NOT EXISTS ix_employees_site_id ON employees(site_id)",
                "CREATE INDEX IF NOT EXISTS ix_employees_org_unit_id ON employees(org_unit_id)",
            ):
                conn.execute(text(stmt))

        # v2.0.0-dev.5.7: uniqueness is tenant-scoped for MSP operation.
        # Different customers may legitimately use the same company/site name, WP code or inventory number.
        if engine.dialect.name == "postgresql":
            for stmt in (
                "ALTER TABLE companies DROP CONSTRAINT IF EXISTS companies_name_key",
                "ALTER TABLE sites DROP CONSTRAINT IF EXISTS sites_name_key",
                "ALTER TABLE workplaces DROP CONSTRAINT IF EXISTS workplaces_code_key",
                "ALTER TABLE assets DROP CONSTRAINT IF EXISTS assets_inventory_no_key",
            ):
                conn.execute(text(stmt))
        for idx in ("ix_companies_name","ix_sites_name","ix_workplaces_code","ix_assets_inventory_no"):
            try: conn.execute(text(f"DROP INDEX IF EXISTS {idx}"))
            except Exception: pass
        for stmt in (
            "CREATE INDEX IF NOT EXISTS ix_companies_name ON companies(name)",
            "CREATE INDEX IF NOT EXISTS ix_sites_name ON sites(name)",
            "CREATE INDEX IF NOT EXISTS ix_workplaces_code ON workplaces(code)",
            "CREATE INDEX IF NOT EXISTS ix_assets_inventory_no ON assets(inventory_no)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_companies_org_name ON companies(organization_id,name)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_sites_org_name ON sites(organization_id,name)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_workplaces_org_code ON workplaces(organization_id,code)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_assets_org_inventory_no ON assets(organization_id,inventory_no)",
        ):
            conn.execute(text(stmt))

        # v2.0.0-dev.5.5: normalize organization lifecycle status.
        try:
            conn.execute(text("UPDATE organizations SET service_status=CASE WHEN COALESCE(is_active,1)=1 THEN 'active' ELSE 'archived' END WHERE service_status IS NULL OR service_status=''"))
            conn.execute(text("UPDATE organizations SET service_status='archived' WHERE COALESCE(is_active,1)=0 AND service_status='active'"))
        except Exception:
            pass

        # v2: a clean installation starts with zero organizations.
        # A fallback organization is created only when legacy business data exists and needs a tenant during migration.
        org_count = conn.execute(text("SELECT COUNT(*) FROM organizations")).scalar() or 0
        legacy_tables = ("companies","departments","sites","org_units","employees","locations","workplaces","assets","asset_maps","inventory_sessions")
        legacy_rows = 0
        if org_count == 0:
            for table_name in legacy_tables:
                try:
                    legacy_rows += int(conn.execute(text(f"SELECT COUNT(*) FROM {table_name}")).scalar() or 0)
                except Exception:
                    pass
            if legacy_rows:
                default_name = os.getenv("ITCONTROL_ORGANIZATION_NAME", "Текущая организация")
                conn.execute(text("INSERT INTO organizations (name, organization_type, is_active, created_at) VALUES (:n, 'internal', 1, :dt)"), {"n": default_name, "dt": datetime.utcnow()})
        default_org = conn.execute(text("SELECT id FROM organizations ORDER BY id LIMIT 1")).scalar()
        if default_org:
            for table_name in legacy_tables:
                conn.execute(text(f"UPDATE {table_name} SET organization_id=:oid WHERE organization_id IS NULL"), {"oid": default_org})
            conn.execute(text("UPDATE app_users SET organization_id=NULL WHERE role='Главный администратор'"))

        # Remove the historical placeholder only when it is truly empty.
        placeholders = conn.execute(text("SELECT id FROM organizations WHERE name='Текущая организация'")).scalars().all()
        for placeholder_id in placeholders:
            busy = 0
            for table_name in ("companies","departments","sites","org_units","employees","locations","workplaces","assets","asset_maps","inventory_sessions","nas_devices","helpdesk_tickets"):
                try:
                    busy += int(conn.execute(text(f"SELECT COUNT(*) FROM {table_name} WHERE organization_id=:oid"), {"oid": placeholder_id}).scalar() or 0)
                except Exception:
                    pass
            if busy == 0:
                conn.execute(text("UPDATE app_users SET organization_id=NULL WHERE organization_id=:oid AND role='Главный администратор'"), {"oid": placeholder_id})
                conn.execute(text("DELETE FROM organizations WHERE id=:oid"), {"oid": placeholder_id})

try:
    ensure_schema_compatibility()
except Exception as exc:
    print(f"[SCHEMA WARNING] compatibility check failed: {exc}", flush=True)


def safe_commit(s: Session, entity_label: str):
    try:
        s.commit()
    except IntegrityError as exc:
        s.rollback()
        raise HTTPException(409, f"{entity_label}: запись с такими данными уже существует или конфликтует с текущими связями") from exc
    except SQLAlchemyError as exc:
        s.rollback()
        raise HTTPException(500, f"{entity_label}: ошибка базы данных. Подробности сохранены в журнале web-1.") from exc

def db():
    s = SessionLocal()
    try: yield s
    finally: s.close()

def current_actor(request: Request, s: Session = Depends(db)):
    user_id = getattr(request.state, "authenticated_user_id", None)
    if user_id is None:
        raise HTTPException(401, "Войдите в систему")
    user = s.get(AppUser, user_id)
    if not user or not user.is_active:
        raise HTTPException(401, "Сеанс завершён")
    return user


def current_organization_id(
    x_organization_id: Optional[int] = Header(default=None),
    actor: Optional[AppUser] = Depends(current_actor),
    s: Session = Depends(db),
):
    # Main admin may switch between all organizations. Other users stay in their assigned one.
    if actor and actor.role != "Главный администратор" and actor.organization_id:
        return actor.organization_id
    oid = x_organization_id
    if oid is None:
        oid = s.scalar(select(Organization.id).where(Organization.is_active == 1).order_by(Organization.id))
    if oid is None or not s.get(Organization, oid):
        raise HTTPException(400, "Организация не выбрана")
    return int(oid)

def ensure_same_organization(entity, organization_id: int, label: str = "Объект"):
    if not entity or getattr(entity, "organization_id", None) != organization_id:
        raise HTTPException(404, f"{label} не найден в выбранной организации")
    return entity

def require_main_admin(actor: Optional[AppUser] = Depends(current_actor)):
    if not actor or actor.role != "Главный администратор":
        raise HTTPException(403, "Операция доступна только Главному администратору системы")
    return actor

def require_org_admin(actor: Optional[AppUser] = Depends(current_actor)):
    if not actor or actor.role not in ("Главный администратор", "Администратор организации"):
        raise HTTPException(403, "Операция доступна администратору организации или Главному администратору")
    return actor

def asset_dict(a: Asset):
    return {
        "id": a.id, "inventory_no": a.inventory_no, "category": a.category,
        "manufacturer": a.manufacturer, "model": a.model, "serial_no": a.serial_no,
        "status": a.status, "employee_id": a.employee_id, "employee": a.employee.name if a.employee else None,
        "location_id": a.location_id, "location": a.location.name if a.location else None,
        "workplace_id": a.workplace_id, "workplace": a.workplace.code if a.workplace else None,
        "company_id": a.company_id, "department_id": a.department_id, "site_id": a.site_id, "site": a.site.name if a.site else None, "org_unit_id": a.org_unit_id, "org_unit": a.org_unit.name if a.org_unit else None,
        "server_room_id": a.server_room_id, "rack_id": a.rack_id, "rack_unit": a.rack_unit,
        "device_height_u": a.device_height_u, "server_kind": a.server_kind, "os_name": a.os_name,
        "hypervisor": a.hypervisor, "management_ip": a.management_ip, "primary_ip": a.primary_ip,
        "purpose": a.purpose, "cluster_name": a.cluster_name,
        "purchase_date": str(a.purchase_date) if a.purchase_date else None,
        "warranty_until": str(a.warranty_until) if a.warranty_until else None,
        "notes": a.notes, "updated_at": a.updated_at.isoformat() if a.updated_at else None,
        "deletion_marked": bool(a.deletion_marked_at),
        "deletion_marked_at": a.deletion_marked_at.isoformat() if a.deletion_marked_at else None,
        "deletion_marked_by": a.deletion_marked_by, "deletion_reason": a.deletion_reason,
    }


class AssetMapIn(BaseModel):
    name: str
    company_id: Optional[int] = None
    site_id: Optional[int] = None
    floor_name: Optional[str] = None
    canvas_width: int = 1200
    canvas_height: int = 720
    notes: Optional[str] = None

class AssetMapNodeIn(BaseModel):
    node_type: str
    ref_id: Optional[int] = None
    label: Optional[str] = None
    x: int = 40
    y: int = 40
    width: int = 130
    height: int = 58
    layer: str = "equipment"
    notes: Optional[str] = None

class AssetMapLinkIn(BaseModel):
    source_node_id: int
    target_node_id: int
    label: Optional[str] = None
    line_style: str = "solid"

class AssetMapNodeMove(BaseModel):
    x: int
    y: int
    width: Optional[int] = None
    height: Optional[int] = None


class EquipmentTransferIn(BaseModel):
    employee_id: int
    asset_ids: list[int]
    transfer_date: Optional[date] = None
    handed_by: Optional[str] = None
    note: Optional[str] = None

class EquipmentReturnIn(BaseModel):
    asset_ids: Optional[list[int]] = None
    return_date: Optional[date] = None
    received_by: Optional[str] = None
    note: Optional[str] = None

class AssetIn(BaseModel):
    inventory_no: Optional[str] = None
    category: str = "Компьютер"
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    serial_no: Optional[str] = None
    status: str = "На складе"
    employee_id: Optional[int] = None
    location_id: Optional[int] = None
    workplace_id: Optional[int] = None
    company_id: Optional[int] = None
    department_id: Optional[int] = None  # legacy
    site_id: Optional[int] = None
    org_unit_id: Optional[int] = None
    server_room_id: Optional[int] = None
    rack_id: Optional[int] = None
    rack_unit: Optional[int] = None
    device_height_u: Optional[int] = None
    server_kind: Optional[str] = None
    os_name: Optional[str] = None
    hypervisor: Optional[str] = None
    management_ip: Optional[str] = None
    primary_ip: Optional[str] = None
    purpose: Optional[str] = None
    cluster_name: Optional[str] = None
    purchase_date: Optional[date] = None
    warranty_until: Optional[date] = None
    notes: Optional[str] = None

class OrganizationIn(BaseModel):
    name: str
    organization_type: str = "internal"
    is_active: bool = True
    service_status: str = "active"

class OrgIn(BaseModel):
    name: str
    company_id: Optional[int] = None

class NamedIn(BaseModel):
    name: str
    department: Optional[str] = None
    email: Optional[str] = None
    parent: Optional[str] = None
    company_id: Optional[int] = None
    department_id: Optional[int] = None

class SiteIn(BaseModel):
    name: str
    site_type: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None

class OrgUnitIn(BaseModel):
    name: str
    company_id: int
    notes: Optional[str] = None

class EmployeeIn(BaseModel):
    name: str
    company_id: Optional[int] = None
    site_id: Optional[int] = None
    org_unit_id: Optional[int] = None
    location_id: Optional[int] = None
    position: Optional[str] = None
    personnel_no: Optional[str] = None
    email: Optional[str] = None
    work_phone: Optional[str] = None
    extension: Optional[str] = None
    mobile_phone: Optional[str] = None
    account_name: Optional[str] = None
    employment_status: Optional[str] = "Работает"
    started_at: Optional[date] = None
    ended_at: Optional[date] = None
    notes: Optional[str] = None
    department: Optional[str] = None
    department_id: Optional[int] = None

class WorkplaceIn(BaseModel):
    code: Optional[str] = None
    name: str
    employee_id: Optional[int] = None
    location_id: Optional[int] = None
    company_id: Optional[int] = None
    department_id: Optional[int] = None

class InventoryIn(BaseModel):
    name: str
    location_id: Optional[int] = None

class ScanIn(BaseModel):
    code: str

class ServerRoomIn(BaseModel):
    name: str
    company_id: Optional[int] = None
    site_id: Optional[int] = None
    org_unit_id: Optional[int] = None
    location_id: Optional[int] = None
    notes: Optional[str] = None
    department_id: Optional[int] = None  # legacy import/API compatibility

class RackIn(BaseModel):
    server_room_id: int
    code: str
    name: Optional[str] = None
    units: int = 42
    notes: Optional[str] = None

class PrintProfileIn(BaseModel):
    technology: Optional[str] = None
    color_mode: Optional[str] = None
    max_format: Optional[str] = None
    connection_type: Optional[str] = None
    network_name: Optional[str] = None
    ip_address: Optional[str] = None
    notes: Optional[str] = None

class ConsumableIn(BaseModel):
    name: str
    consumable_type: str = "Картридж"
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    color: Optional[str] = None
    sku: Optional[str] = None
    resource: Optional[str] = None
    quantity: int = 0
    min_quantity: int = 0
    unit: str = "шт."
    notes: Optional[str] = None
    compatible_asset_ids: list[int] = []

class ConsumableMoveIn(BaseModel):
    delta: int
    reason: Optional[str] = None

class SoftwareIn(BaseModel):
    name: str
    vendor: Optional[str] = None
    version: Optional[str] = None
    license_type: Optional[str] = None
    notes: Optional[str] = None

class SoftwareInstallationIn(BaseModel):
    software_id: int
    asset_id: int
    installed_for_employee_id: Optional[int] = None
    installed_at: Optional[date] = None
    environment: Optional[str] = None
    license_info: Optional[str] = None
    notes: Optional[str] = None

class UserIn(BaseModel):
    username: str
    display_name: str
    role: str = "Пользователь"
    organization_id: Optional[int] = None
    is_active: bool = True
    password: Optional[str] = None
    employee_id: Optional[int] = None

class AuthLoginIn(BaseModel):
    username: str
    password: str


class HelpdeskTicketIn(BaseModel):
    title: str
    description: Optional[str] = None
    category: str = "Другое"
    priority: str = "Обычный"
    status: str = "Новая"
    requester_name: Optional[str] = None
    requester_email: Optional[str] = None
    assignee_id: Optional[int] = None
    site_id: Optional[int] = None
    workplace_id: Optional[int] = None
    asset_id: Optional[int] = None

class HelpdeskTicketPatch(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    requester_name: Optional[str] = None
    requester_email: Optional[str] = None
    assignee_id: Optional[int] = None
    site_id: Optional[int] = None
    workplace_id: Optional[int] = None
    asset_id: Optional[int] = None

class HelpdeskCommentIn(BaseModel):
    body: str

class NasDeviceIn(BaseModel):
    name: str
    host: str
    port: int = 5001
    use_https: bool = True
    organization_id: Optional[int] = None
    site_id: Optional[int] = None


class VaultSetupIn(BaseModel):
    password: str






class VaultUnlockIn(BaseModel):
    password: str

class VaultRecoverySetupIn(BaseModel):
    replace: bool = False

class VaultRecoveryResetIn(BaseModel):
    recovery_key: str
    new_password: str

class VaultCredentialIn(BaseModel):
    system_name: str
    category: str = "Прочее"
    address: Optional[str] = None
    username: Optional[str] = None
    secret: str
    notes: Optional[str] = None
    asset_id: Optional[int] = None
    rotate_due: Optional[date] = None

class VaultCredentialUpdate(BaseModel):
    system_name: str
    category: str = "Прочее"
    address: Optional[str] = None
    username: Optional[str] = None
    secret: Optional[str] = None
    notes: Optional[str] = None
    asset_id: Optional[int] = None
    rotate_due: Optional[date] = None

app = FastAPI(title="ИТ.Контроль v2", docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")


# -----------------------------
# Secure Access Vault (v1.4.1)
# -----------------------------
VAULT_SESSION_MINUTES = int(os.getenv("VAULT_SESSION_MINUTES", "10"))
_vault_sessions: dict[str, dict] = {}
_vault_lock = threading.Lock()

def _vault_actor_name(actor: AppUser) -> str:
    return actor.display_name or actor.username

def _vault_kdf(password: str, salt: bytes) -> bytes:
    kdf = Scrypt(salt=salt, length=32, n=2**15, r=8, p=1)
    return kdf.derive(password.encode("utf-8"))

def _vault_load_master_config() -> Optional[dict]:
    if not VAULT_CONFIG_FILE.exists():
        return None
    try:
        return json.loads(VAULT_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None

def _vault_write_master_config(cfg: dict):
    tmp = VAULT_CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    tmp.replace(VAULT_CONFIG_FILE)
    try:
        os.chmod(VAULT_CONFIG_FILE, 0o600)
    except Exception:
        pass

def _vault_wrap_new_key(password: str) -> dict:
    salt = secrets.token_bytes(16)
    wrap_nonce = secrets.token_bytes(12)
    wrapping_key = _vault_kdf(password, salt)
    master_key = secrets.token_bytes(32)
    wrapped_key = AESGCM(wrapping_key).encrypt(wrap_nonce, master_key, b"ITCONTROL-VAULT-MASTER-V1")
    return {
        "version": 1,
        "salt": base64.b64encode(salt).decode(),
        "nonce": base64.b64encode(wrap_nonce).decode(),
        "wrapped_key": base64.b64encode(wrapped_key).decode(),
    }


def _vault_wrap_existing_key(password: str, master_key: bytes, cfg: Optional[dict] = None) -> dict:
    salt = secrets.token_bytes(16)
    wrap_nonce = secrets.token_bytes(12)
    wrapping_key = _vault_kdf(password, salt)
    wrapped_key = AESGCM(wrapping_key).encrypt(wrap_nonce, master_key, b"ITCONTROL-VAULT-MASTER-V1")
    out = dict(cfg or {})
    out.update({
        "version": max(int(out.get("version", 1)), 2),
        "salt": base64.b64encode(salt).decode(),
        "nonce": base64.b64encode(wrap_nonce).decode(),
        "wrapped_key": base64.b64encode(wrapped_key).decode(),
    })
    return out

def _vault_normalize_recovery_key(value: str) -> str:
    return re.sub(r"[^A-Z2-7]", "", (value or "").upper())

def _vault_format_recovery_key(raw: bytes) -> str:
    value = base64.b32encode(raw).decode("ascii").rstrip("=")
    return "-".join(value[i:i+5] for i in range(0, len(value), 5))

def _vault_add_recovery(cfg: dict, master_key: bytes) -> tuple[dict, str]:
    recovery_display = _vault_format_recovery_key(secrets.token_bytes(32))
    normalized = _vault_normalize_recovery_key(recovery_display)
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(12)
    recovery_wrap_key = _vault_kdf(normalized, salt)
    wrapped = AESGCM(recovery_wrap_key).encrypt(nonce, master_key, b"ITCONTROL-VAULT-RECOVERY-V1")
    out = dict(cfg)
    out["version"] = max(int(out.get("version", 1)), 2)
    out["recovery"] = {
        "version": 1,
        "salt": base64.b64encode(salt).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "wrapped_key": base64.b64encode(wrapped).decode(),
        "created_at": datetime.utcnow().isoformat(),
    }
    return out, recovery_display

def _vault_unwrap_recovery(recovery_key: str, cfg: dict) -> bytes:
    rec = cfg.get("recovery") if isinstance(cfg, dict) else None
    if not rec:
        raise HTTPException(404, "Ключ восстановления для этого хранилища не настроен")
    normalized = _vault_normalize_recovery_key(recovery_key)
    if len(normalized) < 40:
        raise HTTPException(400, "Некорректный ключ восстановления")
    try:
        salt = base64.b64decode(rec["salt"])
        nonce = base64.b64decode(rec["nonce"])
        wrapped_key = base64.b64decode(rec["wrapped_key"])
        recovery_wrap_key = _vault_kdf(normalized, salt)
        return AESGCM(recovery_wrap_key).decrypt(nonce, wrapped_key, b"ITCONTROL-VAULT-RECOVERY-V1")
    except Exception as exc:
        raise HTTPException(401, "Неверный ключ восстановления") from exc

def _vault_unwrap_key(password: str, cfg: dict) -> bytes:
    try:
        salt = base64.b64decode(cfg["salt"])
        nonce = base64.b64decode(cfg["nonce"])
        wrapped_key = base64.b64decode(cfg["wrapped_key"])
        wrapping_key = _vault_kdf(password, salt)
        return AESGCM(wrapping_key).decrypt(nonce, wrapped_key, b"ITCONTROL-VAULT-MASTER-V1")
    except Exception as exc:
        raise HTTPException(401, "Неверный мастер-пароль хранилища") from exc

def _vault_issue_session(actor: AppUser, master_key: bytes) -> tuple[str, datetime]:
    token = secrets.token_urlsafe(32)
    expires = datetime.utcnow() + timedelta(minutes=VAULT_SESSION_MINUTES)
    with _vault_lock:
        now = datetime.utcnow()
        for old in [k for k,v in _vault_sessions.items() if v["expires"] <= now]:
            _vault_sessions.pop(old, None)
        _vault_sessions[token] = {"actor_id": actor.id, "key": master_key, "expires": expires}
    return token, expires

def _vault_session_key(x_vault_token: Optional[str], actor: AppUser) -> bytes:
    if not x_vault_token:
        raise HTTPException(423, "Хранилище заблокировано")
    with _vault_lock:
        sess = _vault_sessions.get(x_vault_token)
        if not sess or sess["actor_id"] != actor.id or sess["expires"] <= datetime.utcnow():
            _vault_sessions.pop(x_vault_token, None)
            raise HTTPException(423, "Сеанс хранилища истёк. Разблокируйте его снова")
        # Sliding timeout while the administrator is actively working.
        sess["expires"] = datetime.utcnow() + timedelta(minutes=VAULT_SESSION_MINUTES)
        return sess["key"]

def _vault_encrypt(secret_value: str, master_key: bytes) -> tuple[str, str]:
    nonce = secrets.token_bytes(12)
    encrypted = AESGCM(master_key).encrypt(nonce, secret_value.encode("utf-8"), b"ITCONTROL-CREDENTIAL-V1")
    return base64.b64encode(encrypted).decode(), base64.b64encode(nonce).decode()

def _vault_decrypt(row: VaultCredential, master_key: bytes) -> str:
    try:
        return AESGCM(master_key).decrypt(
            base64.b64decode(row.secret_nonce),
            base64.b64decode(row.secret_ciphertext),
            b"ITCONTROL-CREDENTIAL-V1"
        ).decode("utf-8")
    except Exception as exc:
        raise HTTPException(500, "Не удалось расшифровать запись. Проверьте ключ хранилища") from exc

def _vault_audit(s: Session, actor: AppUser, action: str, row: Optional[VaultCredential]=None, details: Optional[str]=None):
    s.add(VaultAudit(
        credential_id=row.id if row else None,
        system_name=row.system_name if row else None,
        action=action,
        actor=_vault_actor_name(actor),
        details=details
    ))

def _vault_row_dict(v: VaultCredential):
    return {
        "id": v.id,
        "system_name": v.system_name,
        "category": v.category,
        "address": v.address,
        "username": v.username,
        "notes": v.notes,
        "asset_id": v.asset_id,
        "asset": (v.asset.inventory_no + " · " + " ".join(x for x in [v.asset.manufacturer, v.asset.model] if x)) if v.asset else None,
        "rotate_due": v.rotate_due.isoformat() if v.rotate_due else None,
        "created_by": v.created_by,
        "updated_by": v.updated_by,
        "created_at": v.created_at.isoformat() if v.created_at else None,
        "updated_at": v.updated_at.isoformat() if v.updated_at else None,
        "has_secret": True,
    }

@app.get("/api/vault/status")
def vault_status(actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None)):
    configured = bool(_vault_load_master_config())
    unlocked = False
    expires_at = None
    if configured and x_vault_token:
        with _vault_lock:
            sess = _vault_sessions.get(x_vault_token)
            if sess and sess["actor_id"] == actor.id and sess["expires"] > datetime.utcnow():
                unlocked = True
                expires_at = sess["expires"].isoformat()
    cfg = _vault_load_master_config() if configured else None
    return {
        "configured": configured,
        "unlocked": unlocked,
        "expires_at": expires_at,
        "session_minutes": VAULT_SESSION_MINUTES,
        "recovery_configured": bool(cfg and cfg.get("recovery")),
    }

@app.post("/api/vault/setup")
def vault_setup(data: VaultSetupIn, actor: AppUser = Depends(require_main_admin), s: Session = Depends(db)):
    if _vault_load_master_config():
        raise HTTPException(409, "Хранилище уже настроено")
    if len(data.password) < 10:
        raise HTTPException(400, "Мастер-пароль должен содержать не менее 10 символов")
    cfg = _vault_wrap_new_key(data.password)
    _vault_write_master_config(cfg)
    master_key = _vault_unwrap_key(data.password, cfg)
    token, expires = _vault_issue_session(actor, master_key)
    _vault_audit(s, actor, "Хранилище настроено", details="Создан локальный зашифрованный ключ")
    s.commit()
    return {"ok": True, "token": token, "expires_at": expires.isoformat()}

@app.post("/api/vault/unlock")
def vault_unlock(data: VaultUnlockIn, actor: AppUser = Depends(require_main_admin), s: Session = Depends(db)):
    cfg = _vault_load_master_config()
    if not cfg:
        raise HTTPException(404, "Хранилище ещё не настроено")
    master_key = _vault_unwrap_key(data.password, cfg)
    token, expires = _vault_issue_session(actor, master_key)
    _vault_audit(s, actor, "Хранилище разблокировано")
    s.commit()
    return {"ok": True, "token": token, "expires_at": expires.isoformat()}


@app.post("/api/vault/recovery/setup")
def vault_recovery_setup(
    data: VaultRecoverySetupIn,
    actor: AppUser = Depends(require_main_admin),
    x_vault_token: Optional[str] = Header(default=None),
    s: Session = Depends(db),
):
    master_key = _vault_session_key(x_vault_token, actor)
    cfg = _vault_load_master_config()
    if not cfg:
        raise HTTPException(404, "Хранилище ещё не настроено")
    if cfg.get("recovery") and not data.replace:
        raise HTTPException(409, "Ключ восстановления уже настроен")
    cfg, recovery_key = _vault_add_recovery(cfg, master_key)
    _vault_write_master_config(cfg)
    _vault_audit(
        s, actor,
        "Ключ восстановления создан" if not data.replace else "Ключ восстановления заменён",
        details="Сам ключ в журнал не записывается"
    )
    s.commit()
    return {"ok": True, "recovery_key": recovery_key}

@app.post("/api/vault/recovery/reset-master")
def vault_recovery_reset_master(
    data: VaultRecoveryResetIn,
    actor: AppUser = Depends(require_main_admin),
    s: Session = Depends(db),
):
    if len(data.new_password) < 10:
        raise HTTPException(400, "Новый мастер-пароль должен содержать не менее 10 символов")
    cfg = _vault_load_master_config()
    if not cfg:
        raise HTTPException(404, "Хранилище ещё не настроено")
    master_key = _vault_unwrap_recovery(data.recovery_key, cfg)
    cfg = _vault_wrap_existing_key(data.new_password, master_key, cfg)
    _vault_write_master_config(cfg)
    token, expires = _vault_issue_session(actor, master_key)
    _vault_audit(
        s, actor, "Мастер-пароль восстановлен",
        details="Выполнено с помощью Recovery Key; сохранённые пароли не изменялись"
    )
    s.commit()
    return {"ok": True, "token": token, "expires_at": expires.isoformat()}

@app.post("/api/vault/lock")
def vault_lock(actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    if x_vault_token:
        with _vault_lock:
            _vault_sessions.pop(x_vault_token, None)
    _vault_audit(s, actor, "Хранилище заблокировано")
    s.commit()
    return {"ok": True}

@app.get("/api/vault/credentials")
def vault_credentials(actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    _vault_session_key(x_vault_token, actor)
    rows = s.scalars(select(VaultCredential).order_by(VaultCredential.system_name, VaultCredential.username)).all()
    return [_vault_row_dict(v) for v in rows]

@app.post("/api/vault/credentials")
def vault_create(data: VaultCredentialIn, actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    key = _vault_session_key(x_vault_token, actor)
    if not data.system_name.strip():
        raise HTTPException(400, "Укажите систему или устройство")
    if not data.secret:
        raise HTTPException(400, "Пароль не может быть пустым")
    cipher, nonce = _vault_encrypt(data.secret, key)
    row = VaultCredential(
        system_name=data.system_name.strip(), category=data.category or "Прочее",
        address=(data.address or "").strip() or None, username=(data.username or "").strip() or None,
        secret_ciphertext=cipher, secret_nonce=nonce, notes=(data.notes or "").strip() or None,
        asset_id=data.asset_id, rotate_due=data.rotate_due,
        created_by=_vault_actor_name(actor), updated_by=_vault_actor_name(actor)
    )
    s.add(row); s.flush()
    _vault_audit(s, actor, "Доступ создан", row)
    s.commit(); s.refresh(row)
    return _vault_row_dict(row)

@app.put("/api/vault/credentials/{credential_id}")
def vault_update(credential_id: int, data: VaultCredentialUpdate, actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    key = _vault_session_key(x_vault_token, actor)
    row = s.get(VaultCredential, credential_id)
    if not row:
        raise HTTPException(404, "Запись не найдена")
    row.system_name = data.system_name.strip()
    row.category = data.category or "Прочее"
    row.address = (data.address or "").strip() or None
    row.username = (data.username or "").strip() or None
    row.notes = (data.notes or "").strip() or None
    row.asset_id = data.asset_id
    row.rotate_due = data.rotate_due
    row.updated_by = _vault_actor_name(actor)
    if data.secret:
        row.secret_ciphertext, row.secret_nonce = _vault_encrypt(data.secret, key)
    _vault_audit(s, actor, "Доступ изменён", row, "Пароль изменён" if data.secret else "Метаданные изменены")
    s.commit(); s.refresh(row)
    return _vault_row_dict(row)

@app.post("/api/vault/credentials/{credential_id}/reveal")
def vault_reveal(credential_id: int, purpose: str = "reveal", actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    key = _vault_session_key(x_vault_token, actor)
    row = s.get(VaultCredential, credential_id)
    if not row:
        raise HTTPException(404, "Запись не найдена")
    value = _vault_decrypt(row, key)
    action = "Пароль скопирован" if purpose == "copy" else "Пароль просмотрен"
    _vault_audit(s, actor, action, row)
    s.commit()
    return {"secret": value}

@app.delete("/api/vault/credentials/{credential_id}")
def vault_delete(credential_id: int, actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    _vault_session_key(x_vault_token, actor)
    row = s.get(VaultCredential, credential_id)
    if not row:
        raise HTTPException(404, "Запись не найдена")
    _vault_audit(s, actor, "Доступ удалён", row)
    s.flush()
    s.delete(row)
    s.commit()
    return {"ok": True}

@app.get("/api/vault/audit")
def vault_audit_list(actor: AppUser = Depends(require_main_admin), x_vault_token: Optional[str] = Header(default=None), s: Session = Depends(db)):
    _vault_session_key(x_vault_token, actor)
    rows = s.scalars(select(VaultAudit).order_by(VaultAudit.created_at.desc()).limit(200)).all()
    return [{
        "id": x.id, "credential_id": x.credential_id, "system_name": x.system_name,
        "action": x.action, "actor": x.actor, "details": x.details,
        "created_at": x.created_at.isoformat() if x.created_at else None
    } for x in rows]


def _ticket_dict(t: HelpdeskTicket, s: Session):
    site=s.get(Site,t.site_id) if t.site_id else None
    wp=s.get(Workplace,t.workplace_id) if t.workplace_id else None
    asset=s.get(Asset,t.asset_id) if t.asset_id else None
    assignee=s.get(AppUser,t.assignee_id) if t.assignee_id else None
    return {"id":t.id,"ticket_no":t.ticket_no,"title":t.title,"description":t.description,"category":t.category,"priority":t.priority,"status":t.status,"requester_name":t.requester_name,"requester_email":t.requester_email,"assignee_id":t.assignee_id,"assignee":assignee.display_name if assignee else None,"site_id":t.site_id,"site":site.name if site else None,"workplace_id":t.workplace_id,"workplace":wp.code if wp else None,"asset_id":t.asset_id,"asset":asset.inventory_no if asset else None,"created_at":t.created_at,"updated_at":t.updated_at,"closed_at":t.closed_at}

def _next_ticket_no(s: Session, organization_id:int):
    n=s.scalar(select(func.count()).select_from(HelpdeskTicket).where(HelpdeskTicket.organization_id==organization_id)) or 0
    while True:
        n+=1; no=f"HD-{organization_id:03d}-{n:06d}"
        if not s.scalar(select(func.count()).select_from(HelpdeskTicket).where(HelpdeskTicket.ticket_no==no)): return no

def _validate_hd_links(s:Session, organization_id:int, data):
    for cls,key,label in ((Site,'site_id','Площадка'),(Workplace,'workplace_id','Рабочее место'),(Asset,'asset_id','Оборудование')):
        value=getattr(data,key,None)
        if value: ensure_same_organization(s.get(cls,value),organization_id,label)
    if getattr(data,'assignee_id',None):
        u=s.get(AppUser,data.assignee_id)
        if not u or (u.role!='Главный администратор' and u.organization_id not in (None,organization_id)): raise HTTPException(404,'Исполнитель недоступен в этой организации')

@app.get("/api/helpdesk/tickets")
def helpdesk_tickets(status:str="", q:str="", s:Session=Depends(db), organization_id:int=Depends(current_organization_id)):
    stmt=select(HelpdeskTicket).where(HelpdeskTicket.organization_id==organization_id).order_by(HelpdeskTicket.created_at.desc())
    if status: stmt=stmt.where(HelpdeskTicket.status==status)
    if q: stmt=stmt.where((HelpdeskTicket.title.ilike(f"%{q}%")) | (HelpdeskTicket.ticket_no.ilike(f"%{q}%")) | (HelpdeskTicket.requester_name.ilike(f"%{q}%")))
    return [_ticket_dict(x,s) for x in s.scalars(stmt).all()]

@app.get("/api/helpdesk/tickets/{ticket_id}")
def helpdesk_ticket(ticket_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    t=ensure_same_organization(s.get(HelpdeskTicket,ticket_id),organization_id,"Заявка")
    out=_ticket_dict(t,s); out['comments']=[{"id":c.id,"author":c.author,"body":c.body,"created_at":c.created_at} for c in s.scalars(select(HelpdeskComment).where(HelpdeskComment.ticket_id==t.id,HelpdeskComment.organization_id==organization_id).order_by(HelpdeskComment.created_at)).all()]; return out

@app.post("/api/helpdesk/tickets")
def create_helpdesk_ticket(data:HelpdeskTicketIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    _validate_hd_links(s,organization_id,data)
    d=data.model_dump(); d['ticket_no']=_next_ticket_no(s,organization_id); d['organization_id']=organization_id
    t=HelpdeskTicket(**d); s.add(t); safe_commit(s,'HelpDesk'); s.refresh(t); return _ticket_dict(t,s)

@app.put("/api/helpdesk/tickets/{ticket_id}")
def update_helpdesk_ticket(ticket_id:int,data:HelpdeskTicketPatch,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    t=ensure_same_organization(s.get(HelpdeskTicket,ticket_id),organization_id,"Заявка")
    _validate_hd_links(s,organization_id,data)
    d=data.model_dump(exclude_unset=True)
    for k,v in d.items(): setattr(t,k,v)
    if 'status' in d:
        t.closed_at=datetime.utcnow() if d['status']=='Закрыта' else None
    t.updated_at=datetime.utcnow(); safe_commit(s,'HelpDesk'); s.refresh(t); return _ticket_dict(t,s)

@app.post("/api/helpdesk/tickets/{ticket_id}/comments")
def add_helpdesk_comment(ticket_id:int,data:HelpdeskCommentIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id),actor:Optional[AppUser]=Depends(current_actor)):
    t=ensure_same_organization(s.get(HelpdeskTicket,ticket_id),organization_id,"Заявка")
    body=data.body.strip()
    if not body: raise HTTPException(400,'Комментарий пуст')
    c=HelpdeskComment(organization_id=organization_id,ticket_id=t.id,author=(actor.display_name if actor else 'Пользователь'),body=body); s.add(c); t.updated_at=datetime.utcnow(); safe_commit(s,'Комментарий'); return {'ok':True}

def _nas_dict(n:NasDevice):
    try: details=json.loads(n.details_json or '{}')
    except Exception: details={}
    return {'id':n.id,'organization_id':n.organization_id,'site_id':n.site_id,'name':n.name,'vendor':n.vendor,'host':n.host,'port':n.port,'use_https':bool(n.use_https),'model':n.model,'dsm_version':n.dsm_version,'serial_no':n.serial_no,'status':n.status,'last_seen':n.last_seen,'last_error':n.last_error,'details':details}



@app.get("/api/nas")
def nas_list(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    return [_nas_dict(x) for x in s.scalars(select(NasDevice).where(NasDevice.organization_id==organization_id).order_by(NasDevice.name)).all()]

@app.post("/api/nas")
def nas_create(data:NasDeviceIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    name=data.name.strip(); host=data.host.strip()
    if not name or not host: raise HTTPException(400,'Укажите название и адрес NAS')
    if data.port < 1 or data.port > 65535: raise HTTPException(400,'Некорректный порт DSM')
    n=NasDevice(organization_id=organization_id,name=name,host=host,port=data.port,use_https=1 if data.use_https else 0); s.add(n); safe_commit(s,'NAS'); s.refresh(n); return _nas_dict(n)

@app.put("/api/nas/{nas_id}")
def nas_update(nas_id:int,data:NasDeviceIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id),actor:Optional[AppUser]=Depends(current_actor)):
    n=ensure_same_organization(s.get(NasDevice,nas_id),organization_id,'NAS')
    name=data.name.strip(); host=data.host.strip()
    if not name or not host: raise HTTPException(400,'Укажите название и адрес NAS')
    if data.port < 1 or data.port > 65535: raise HTTPException(400,'Некорректный порт DSM')
    target_org=int(data.organization_id or n.organization_id)
    if target_org != n.organization_id:
        if not actor or actor.role != 'Главный администратор': raise HTTPException(403,'Перенос NAS между организациями доступен только Главному администратору')
        if not s.get(Organization,target_org): raise HTTPException(400,'Организация не найдена')
    if data.site_id is not None:
        site=s.get(Site,int(data.site_id))
        if not site or site.organization_id != target_org: raise HTTPException(400,'Площадка не относится к выбранной организации')
    endpoint_changed=(n.host != host or n.port != data.port or bool(n.use_https) != bool(data.use_https))
    n.organization_id=target_org; n.site_id=data.site_id; n.name=name; n.host=host; n.port=data.port; n.use_https=1 if data.use_https else 0
    if endpoint_changed:
        n.status='Не проверен'; n.last_seen=None; n.last_error=None
    n.updated_at=datetime.utcnow(); safe_commit(s,'NAS'); s.refresh(n); return _nas_dict(n)

@app.delete("/api/nas/{nas_id}")
def nas_delete(nas_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    n=ensure_same_organization(s.get(NasDevice,nas_id),organization_id,'NAS'); s.delete(n); safe_commit(s,'NAS'); return {'ok':True}


@app.get("/", response_class=HTMLResponse)
def home():
    return (APP_DIR / "static" / "index.html").read_text(encoding="utf-8")


MAP_BG_DIR = APP_DIR / "static" / "map-backgrounds"
MAP_BG_DIR.mkdir(parents=True, exist_ok=True)

def _map_node_dict(n:AssetMapNode,s:Session):
    label=n.label
    detail=None
    status=None
    category=None
    if n.node_type=="asset" and n.ref_id:
        a=s.get(Asset,n.ref_id)
        if a:
            label=label or f"{a.inventory_no} · {' '.join(v for v in [a.manufacturer,a.model] if v) or a.category}"
            detail=a.employee.name if a.employee else (a.location.name if a.location else None)
            status=a.status; category=a.category
    elif n.node_type=="workplace" and n.ref_id:
        w=s.get(Workplace,n.ref_id)
        if w:
            label=label or w.code
            detail=" · ".join(v for v in [w.employee.name if w.employee else None,w.location.name if w.location else None] if v)
    elif n.node_type=="location" and n.ref_id:
        loc=s.get(Location,n.ref_id)
        if loc:
            label=label or loc.name
            detail=loc.parent
    return {"id":n.id,"map_id":n.map_id,"node_type":n.node_type,"ref_id":n.ref_id,"label":label or n.node_type,
            "x":n.x,"y":n.y,"width":n.width,"height":n.height,"layer":n.layer,"notes":n.notes,
            "detail":detail,"status":status,"category":category}

@app.get("/api/maps")
def map_list(s:Session=Depends(db)):
    xs=s.scalars(select(AssetMap).order_by(AssetMap.name)).all()
    return [{"id":x.id,"name":x.name,"company_id":x.company_id,"company":x.company.name if x.company else None,
             "site_id":x.site_id,"site":x.site.name if x.site else None,"floor_name":x.floor_name,
             "background_file":x.background_file,"background_url":f"/static/map-backgrounds/{x.background_file}" if x.background_file else None,
             "canvas_width":x.canvas_width,"canvas_height":x.canvas_height,"notes":x.notes,
             "nodes":s.scalar(select(func.count()).select_from(AssetMapNode).where(AssetMapNode.map_id==x.id)) or 0} for x in xs]

@app.get("/api/maps/{map_id}")
def map_get(map_id:int,s:Session=Depends(db)):
    x=s.get(AssetMap,map_id)
    if not x: raise HTTPException(404,"Карта не найдена")
    nodes=s.scalars(select(AssetMapNode).where(AssetMapNode.map_id==map_id).order_by(AssetMapNode.id)).all()
    links=s.scalars(select(AssetMapLink).where(AssetMapLink.map_id==map_id).order_by(AssetMapLink.id)).all()
    return {"id":x.id,"name":x.name,"company_id":x.company_id,"company":x.company.name if x.company else None,
            "site_id":x.site_id,"site":x.site.name if x.site else None,"floor_name":x.floor_name,
            "background_file":x.background_file,"background_url":f"/static/map-backgrounds/{x.background_file}" if x.background_file else None,
            "canvas_width":x.canvas_width,"canvas_height":x.canvas_height,"notes":x.notes,
            "nodes":[_map_node_dict(n,s) for n in nodes],
            "links":[{"id":l.id,"map_id":l.map_id,"source_node_id":l.source_node_id,"target_node_id":l.target_node_id,
                      "label":l.label,"line_style":l.line_style} for l in links]}

@app.post("/api/maps")
def map_create(d:AssetMapIn,s:Session=Depends(db)):
    x=AssetMap(**d.model_dump());s.add(x);s.commit();s.refresh(x)
    return {"id":x.id}

@app.put("/api/maps/{map_id}")
def map_update(map_id:int,d:AssetMapIn,s:Session=Depends(db)):
    x=s.get(AssetMap,map_id)
    if not x: raise HTTPException(404,"Карта не найдена")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.commit(); return {"ok":True}

@app.delete("/api/maps/{map_id}")
def map_delete(map_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    x=s.get(AssetMap,map_id)
    if not x: raise HTTPException(404,"Карта не найдена")
    for l in s.scalars(select(AssetMapLink).where(AssetMapLink.map_id==map_id)).all(): s.delete(l)
    for n in s.scalars(select(AssetMapNode).where(AssetMapNode.map_id==map_id)).all(): s.delete(n)
    if x.background_file:
        try:(MAP_BG_DIR/x.background_file).unlink(missing_ok=True)
        except Exception: pass
    s.add(AuditLog(action="Карта удалена",details=f"{x.name}; {actor.username}"));s.delete(x);s.commit()
    return {"ok":True}

@app.post("/api/maps/{map_id}/background")
def map_background(map_id:int,file:UploadFile=File(...),s:Session=Depends(db)):
    x=s.get(AssetMap,map_id)
    if not x: raise HTTPException(404,"Карта не найдена")
    ext=Path(file.filename or "").suffix.lower()
    if ext not in (".png",".jpg",".jpeg",".webp"): raise HTTPException(400,"Для фона поддерживаются PNG, JPG и WEBP")
    raw=file.file.read()
    if len(raw)>12*1024*1024: raise HTTPException(400,"Файл фона больше 12 МБ")
    name=f"map_{map_id}_{int(datetime.utcnow().timestamp())}{ext}"
    (MAP_BG_DIR/name).write_bytes(raw)
    if x.background_file:
        try:(MAP_BG_DIR/x.background_file).unlink(missing_ok=True)
        except Exception: pass
    x.background_file=name;s.commit()
    return {"ok":True,"background_url":f"/static/map-backgrounds/{name}"}

@app.post("/api/maps/{map_id}/nodes")
def map_node_add(map_id:int,d:AssetMapNodeIn,s:Session=Depends(db)):
    if not s.get(AssetMap,map_id): raise HTTPException(404,"Карта не найдена")
    if d.node_type not in ("asset","workplace","location","zone"): raise HTTPException(400,"Неизвестный тип объекта")
    if d.ref_id and d.node_type!="zone":
        dup=s.scalar(select(AssetMapNode).where(AssetMapNode.map_id==map_id,AssetMapNode.node_type==d.node_type,AssetMapNode.ref_id==d.ref_id))
        if dup: return {"id":dup.id}
    n=AssetMapNode(map_id=map_id,**d.model_dump());s.add(n);s.commit();s.refresh(n);return {"id":n.id}

@app.put("/api/maps/nodes/{node_id}")
def map_node_move(node_id:int,d:AssetMapNodeMove,s:Session=Depends(db)):
    n=s.get(AssetMapNode,node_id)
    if not n: raise HTTPException(404,"Объект карты не найден")
    n.x=max(0,d.x);n.y=max(0,d.y)
    if d.width is not None:n.width=max(50,d.width)
    if d.height is not None:n.height=max(30,d.height)
    s.commit();return {"ok":True}

@app.delete("/api/maps/nodes/{node_id}")
def map_node_delete(node_id:int,s:Session=Depends(db)):
    n=s.get(AssetMapNode,node_id)
    if not n: raise HTTPException(404,"Объект карты не найден")
    for l in s.scalars(select(AssetMapLink).where((AssetMapLink.source_node_id==node_id)|(AssetMapLink.target_node_id==node_id))).all():
        s.delete(l)
    s.delete(n);s.commit();return {"ok":True}

@app.post("/api/maps/{map_id}/links")
def map_link_add(map_id:int,d:AssetMapLinkIn,s:Session=Depends(db)):
    if d.source_node_id==d.target_node_id: raise HTTPException(400,"Нельзя связать объект с самим собой")
    source=s.get(AssetMapNode,d.source_node_id); target=s.get(AssetMapNode,d.target_node_id)
    if not source or not target or source.map_id!=map_id or target.map_id!=map_id:
        raise HTTPException(400,"Оба объекта должны находиться на текущей карте")
    style=d.line_style if d.line_style in ("solid","dashed") else "solid"
    dup=s.scalar(select(AssetMapLink).where(AssetMapLink.map_id==map_id,
        AssetMapLink.source_node_id==d.source_node_id,AssetMapLink.target_node_id==d.target_node_id))
    if dup:
        dup.label=(d.label or "").strip() or None;dup.line_style=style;s.commit();return {"id":dup.id}
    l=AssetMapLink(map_id=map_id,source_node_id=d.source_node_id,target_node_id=d.target_node_id,
                   label=(d.label or "").strip() or None,line_style=style)
    s.add(l);s.commit();s.refresh(l);return {"id":l.id}

@app.delete("/api/maps/links/{link_id}")
def map_link_delete(link_id:int,s:Session=Depends(db)):
    l=s.get(AssetMapLink,link_id)
    if not l: raise HTTPException(404,"Связь не найдена")
    s.delete(l);s.commit();return {"ok":True}

@app.get("/api/dashboard")
def dashboard(s: Session = Depends(db), organization_id:int=Depends(current_organization_id)):
    total = s.scalar(select(func.count()).select_from(Asset).where(Asset.organization_id==organization_id)) or 0
    statuses = dict(s.execute(select(Asset.status, func.count()).where(Asset.organization_id==organization_id).group_by(Asset.status)).all())
    return {"total": total, "warehouse": statuses.get("На складе",0), "active": statuses.get("В эксплуатации",0), "repair": statuses.get("В ремонте",0), "unassigned": s.scalar(select(func.count()).select_from(Asset).where(Asset.organization_id==organization_id,Asset.employee_id.is_(None))) or 0}

@app.get("/api/assets")
def assets(q: str = "", status: str = "", category: str = "", s: Session = Depends(db), organization_id:int=Depends(current_organization_id)):
    stmt = select(Asset).where(Asset.organization_id==organization_id).order_by(Asset.id.desc())
    if q:
        x=f"%{q}%"; stmt=stmt.where((Asset.inventory_no.ilike(x)) | (Asset.serial_no.ilike(x)) | (Asset.model.ilike(x)) | (Asset.manufacturer.ilike(x)))
    if status: stmt=stmt.where(Asset.status==status)
    if category: stmt=stmt.where(Asset.category==category)
    return [asset_dict(a) for a in s.scalars(stmt).all()]

@app.get("/api/assets/{asset_id}")
def asset(asset_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    out=asset_dict(a)
    out["components"]=[{"id":c.id,"component_type":c.component_type,"slot":c.slot,"manufacturer":c.manufacturer,"model":c.model,"serial_no":c.serial_no,"specification":c.specification,"notes":c.notes} for c in s.scalars(select(Component).where(Component.asset_id==asset_id).order_by(Component.id)).all()]
    out["history"]=[{"action":x.action,"details":x.details,"created_at":x.created_at.isoformat()} for x in s.scalars(select(AuditLog).where(AuditLog.asset_id==asset_id).order_by(AuditLog.id.desc())).all()]
    return out

def next_no(s:Session, organization_id: Optional[int] = None):
    # Keep automatic numbering independent per tenant.
    stmt=select(Asset.inventory_no)
    if organization_id is not None: stmt=stmt.where(Asset.organization_id==organization_id)
    highest=0
    rx=re.compile(rf"^{re.escape(PREFIX)}-(\d+)$",re.IGNORECASE)
    for value in s.scalars(stmt):
        m=rx.fullmatch((value or "").strip())
        if m: highest=max(highest,int(m.group(1)))
    return f"{PREFIX}-{highest+1:06d}"

SERVER_ONLY_FIELDS = ("server_room_id","rack_id","rack_unit","device_height_u","server_kind","os_name","hypervisor","management_ip","primary_ip","purpose","cluster_name")
def normalize_asset_data(d: dict) -> dict:
    # Серверные поля имеют смысл только для категории «Сервер».
    # При смене категории очищаем их на backend, а не только прячем в UI.
    if d.get("category") != "Сервер":
        for k in SERVER_ONLY_FIELDS:
            d[k] = None
    return d


def _transfer_no(s: Session, kind: str, d: date) -> str:
    prefix = "АПП" if kind == "transfer" else "ВЗВ"
    stem = f"{prefix}-{d.strftime('%Y%m%d')}"
    n = s.scalar(select(func.count(EquipmentTransfer.id)).where(
        EquipmentTransfer.document_type == kind,
        EquipmentTransfer.transfer_date == d
    )) or 0
    while True:
        candidate = f"{stem}-{n+1:03d}"
        if not s.scalar(select(EquipmentTransfer).where(EquipmentTransfer.document_no == candidate)):
            return candidate
        n += 1

def _transfer_snapshot(s: Session, employee: Employee, assets: list[Asset]) -> dict:
    company = s.get(Company, employee.company_id) if employee.company_id else None
    site = s.get(Site, employee.site_id) if employee.site_id else None
    org = s.get(OrgUnit, employee.org_unit_id) if employee.org_unit_id else None
    location = s.get(Location, employee.location_id) if employee.location_id else None
    return {
        "employee": {
            "id": employee.id, "name": employee.name, "position": employee.position,
            "personnel_no": employee.personnel_no, "company": company.name if company else None,
            "site": site.name if site else None, "org_unit": org.name if org else None,
            "location": location.name if location else None,
        },
        "assets": [{
            "id": a.id, "inventory_no": a.inventory_no, "category": a.category,
            "manufacturer": a.manufacturer, "model": a.model, "serial_no": a.serial_no,
            "status": a.status
        } for a in assets]
    }

def _transfer_dict(x: EquipmentTransfer) -> dict:
    snap = json.loads(x.snapshot_json or "{}")
    return {
        "id": x.id, "document_no": x.document_no, "document_type": x.document_type,
        "employee_id": x.employee_id, "parent_transfer_id": x.parent_transfer_id,
        "transfer_date": str(x.transfer_date), "handed_by": x.handed_by,
        "received_by": x.received_by, "note": x.note,
        "asset_ids": json.loads(x.asset_ids_json or "[]"), "snapshot": snap,
        "created_by": x.created_by, "created_at": x.created_at.isoformat() if x.created_at else None,
    }

@app.get("/api/transfers")
def transfers(employee_id: Optional[int] = None, asset_id: Optional[int] = None, s: Session = Depends(db)):
    xs = s.scalars(select(EquipmentTransfer).order_by(EquipmentTransfer.id.desc())).all()
    out = []
    for x in xs:
        ids = json.loads(x.asset_ids_json or "[]")
        if employee_id and x.employee_id != employee_id:
            continue
        if asset_id and asset_id not in ids:
            continue
        out.append(_transfer_dict(x))
    return out

@app.post("/api/transfers")
def create_transfer(d: EquipmentTransferIn, s: Session = Depends(db), actor: Optional[AppUser] = Depends(current_actor)):
    employee = s.get(Employee, d.employee_id)
    if not employee:
        raise HTTPException(404, "Сотрудник не найден")
    ids = list(dict.fromkeys(d.asset_ids))
    if not ids:
        raise HTTPException(400, "Не выбрано оборудование")
    assets = [s.get(Asset, aid) for aid in ids]
    if any(a is None for a in assets):
        raise HTTPException(404, "Одно из устройств не найдено")
    conflicts = [a.inventory_no for a in assets if a.employee_id not in (None, employee.id)]
    if conflicts:
        raise HTTPException(409, "Оборудование уже закреплено за другим сотрудником: " + ", ".join(conflicts))
    td = d.transfer_date or date.today()
    snapshot = _transfer_snapshot(s, employee, assets)
    doc = EquipmentTransfer(
        document_no=_transfer_no(s, "transfer", td), document_type="transfer",
        employee_id=employee.id, transfer_date=td, handed_by=d.handed_by,
        received_by=employee.name, note=d.note, asset_ids_json=json.dumps(ids),
        snapshot_json=json.dumps(snapshot, ensure_ascii=False),
        created_by=(actor.display_name if actor else None)
    )
    s.add(doc); s.flush()
    for a in assets:
        a.employee_id = employee.id
        if a.status in ("На складе", "Резерв"):
            a.status = "В эксплуатации"
        s.add(AuditLog(asset_id=a.id, action="Передача оборудования",
                       details=f"Акт {doc.document_no}; передано сотруднику {employee.name}"))
    s.add(AuditLog(action="Акт приёма-передачи",
                   details=f"{doc.document_no}; {employee.name}; единиц оборудования: {len(assets)}"))
    s.commit(); s.refresh(doc)
    return _transfer_dict(doc)

@app.post("/api/transfers/{transfer_id}/return")
def return_transfer(transfer_id: int, d: EquipmentReturnIn, s: Session = Depends(db), actor: Optional[AppUser] = Depends(current_actor)):
    parent = s.get(EquipmentTransfer, transfer_id)
    if not parent or parent.document_type != "transfer":
        raise HTTPException(404, "Исходный акт передачи не найден")
    original_ids = json.loads(parent.asset_ids_json or "[]")
    ids = list(dict.fromkeys(d.asset_ids or original_ids))
    if not ids or any(aid not in original_ids for aid in ids):
        raise HTTPException(400, "Возвращать можно только оборудование из исходного акта")
    assets = [s.get(Asset, aid) for aid in ids]
    assets = [a for a in assets if a]
    rd = d.return_date or date.today()
    parent_snap = json.loads(parent.snapshot_json or "{}")
    snap = {
        "employee": parent_snap.get("employee", {}),
        "assets": [next((z for z in parent_snap.get("assets", []) if z.get("id") == a.id), {
            "id":a.id,"inventory_no":a.inventory_no,"category":a.category,
            "manufacturer":a.manufacturer,"model":a.model,"serial_no":a.serial_no
        }) for a in assets]
    }
    doc = EquipmentTransfer(
        document_no=_transfer_no(s, "return", rd), document_type="return",
        employee_id=parent.employee_id, parent_transfer_id=parent.id,
        transfer_date=rd, handed_by=parent.received_by,
        received_by=d.received_by, note=d.note, asset_ids_json=json.dumps(ids),
        snapshot_json=json.dumps(snap, ensure_ascii=False),
        created_by=(actor.display_name if actor else None)
    )
    s.add(doc); s.flush()
    for a in assets:
        if a.employee_id == parent.employee_id:
            a.employee_id = None
            a.workplace_id = None
            a.status = "На складе"
        s.add(AuditLog(asset_id=a.id, action="Возврат оборудования",
                       details=f"Акт {doc.document_no}; возврат по {parent.document_no}"))
    s.add(AuditLog(action="Акт возврата", details=f"{doc.document_no}; по акту {parent.document_no}; единиц: {len(assets)}"))
    s.commit(); s.refresh(doc)
    return _transfer_dict(doc)

@app.get("/api/transfers/{transfer_id}/print", response_class=HTMLResponse)
def print_transfer(transfer_id: int, s: Session = Depends(db)):
    x = s.get(EquipmentTransfer, transfer_id)
    if not x:
        raise HTTPException(404, "Акт не найден")
    snap = json.loads(x.snapshot_json or "{}")
    emp = snap.get("employee", {})
    assets = snap.get("assets", [])
    title = "АКТ ПРИЁМА-ПЕРЕДАЧИ ОБОРУДОВАНИЯ" if x.document_type == "transfer" else "АКТ ВОЗВРАТА ОБОРУДОВАНИЯ"
    rows = "".join(
        f"<tr><td>{i}</td><td>{html_escape(a.get('category'))}</td><td>{html_escape(' '.join(v for v in [a.get('manufacturer'),a.get('model')] if v))}</td>"
        f"<td>{html_escape(a.get('inventory_no'))}</td><td>{html_escape(a.get('serial_no'))}</td></tr>"
        for i,a in enumerate(assets,1)
    )
    company = html_escape(emp.get("company") or "")
    org = html_escape(emp.get("org_unit") or "")
    employee = html_escape(emp.get("name") or "")
    position = html_escape(emp.get("position") or "")
    handed = html_escape(x.handed_by or "")
    received = html_escape(x.received_by or employee)
    note = html_escape(x.note or "")
    return HTMLResponse(f"""<!doctype html><html><head><meta charset="utf-8"><title>{html_escape(x.document_no)}</title>
<style>
@page{{size:A4;margin:16mm}} body{{font-family:Arial,sans-serif;color:#111;font-size:12pt}} h1{{font-size:16pt;text-align:center;margin:10mm 0 4mm}}
.meta{{display:flex;justify-content:space-between;margin-bottom:8mm}} table{{width:100%;border-collapse:collapse;margin:6mm 0}}
th,td{{border:1px solid #333;padding:6px;font-size:10.5pt}} th{{text-align:left}} .sign{{display:grid;grid-template-columns:1fr 1fr;gap:20mm;margin-top:18mm}}
.line{{border-bottom:1px solid #333;min-height:20px;margin-top:12px}} .muted{{font-size:9pt;color:#555}} .noprint{{margin:0 0 10mm}}
@media print{{.noprint{{display:none}}}}
</style></head><body>
<button class="noprint" onclick="window.print()">Печать / сохранить в PDF</button>
<h1>{title}</h1><div class="meta"><b>№ {html_escape(x.document_no)}</b><span>{x.transfer_date.strftime('%d.%m.%Y')}</span></div>
<p><b>Организация:</b> {company or '________________________'}</p>
<p><b>Подразделение:</b> {org or '________________________'}</p>
<p>Оборудование по настоящему акту {'передано' if x.document_type=='transfer' else 'возвращено'}: <b>{employee}</b>{' · '+position if position else ''}.</p>
<table><thead><tr><th>№</th><th>Тип</th><th>Производитель / модель</th><th>Инв. №</th><th>S/N</th></tr></thead><tbody>{rows}</tbody></table>
{f'<p><b>Примечание:</b> {note}</p>' if note else ''}
<div class="sign"><div><b>Передал:</b><div class="line">{handed}</div><div class="muted">ФИО / подпись</div></div>
<div><b>Принял:</b><div class="line">{received}</div><div class="muted">ФИО / подпись</div></div></div>
<script>window.addEventListener('load',()=>setTimeout(()=>window.print(),250));</script></body></html>""")

@app.post("/api/assets")
def create_asset(data:AssetIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    d=normalize_asset_data(data.model_dump()); d["inventory_no"]=d["inventory_no"] or next_no(s,organization_id)
    if s.scalar(select(Asset).where(Asset.organization_id==organization_id,func.lower(Asset.inventory_no)==d["inventory_no"].lower())): raise HTTPException(409,"Инвентарный номер уже существует в этой организации")
    a=Asset(**d,organization_id=organization_id); s.add(a); s.flush(); s.add(AuditLog(asset_id=a.id,action="Создано",details=f"Поставлено на учёт как {a.inventory_no}")); s.commit(); s.refresh(a); return asset_dict(a)

@app.put("/api/assets/{asset_id}")
def update_asset(asset_id:int,data:AssetIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    changes=[]
    incoming=data.model_dump(exclude_unset=True)
    if incoming.get("category", a.category) != "Сервер":
        incoming.update({k: None for k in SERVER_ONLY_FIELDS})
    for k,v in incoming.items():
        old=getattr(a,k)
        if old!=v: changes.append(f"{k}: {old or '—'} → {v or '—'}"); setattr(a,k,v)
    if changes: s.add(AuditLog(asset_id=a.id,action="Изменено",details="; ".join(changes)))
    s.commit(); s.refresh(a); return asset_dict(a)

class AssetDeletionMarkIn(BaseModel):
    reason: Optional[str] = None

@app.post("/api/assets/{asset_id}/deletion-mark")
def mark_asset_for_deletion(asset_id:int, data:AssetDeletionMarkIn, s:Session=Depends(db), actor:AppUser=Depends(require_org_admin), organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    a.deletion_marked_at=datetime.utcnow(); a.deletion_marked_by=actor.display_name or actor.username; a.deletion_reason=(data.reason or "").strip() or None
    s.add(AuditLog(asset_id=a.id,action="Пометка на удаление",details=f"{a.inventory_no}; {a.deletion_marked_by}; {a.deletion_reason or 'без причины'}"))
    s.commit(); return asset_dict(a)

@app.delete("/api/assets/{asset_id}/deletion-mark")
def unmark_asset_for_deletion(asset_id:int, s:Session=Depends(db), actor:AppUser=Depends(require_org_admin), organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    a.deletion_marked_at=None; a.deletion_marked_by=None; a.deletion_reason=None
    s.add(AuditLog(asset_id=a.id,action="Пометка на удаление снята",details=f"{a.inventory_no}; {actor.display_name or actor.username}"))
    s.commit(); return asset_dict(a)

@app.get("/api/admin/deletion-queue")
def deletion_queue(s:Session=Depends(db), actor:AppUser=Depends(require_main_admin)):
    xs=s.scalars(select(Asset).where(Asset.deletion_marked_at.is_not(None)).order_by(Asset.deletion_marked_at.desc())).all()
    out=[]
    for a in xs:
        org=s.get(Organization,a.organization_id) if a.organization_id else None
        d=asset_dict(a); d["organization"]=org.name if org else None; out.append(d)
    return out

@app.delete("/api/assets/{asset_id}")
def delete_asset(asset_id:int,s:Session=Depends(db), actor: AppUser = Depends(require_main_admin),organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    if not a.deletion_marked_at:
        raise HTTPException(409, "Сначала поставьте оборудование на удаление. Окончательное удаление выполняет Главный администратор.")
    inv=a.inventory_no
    transfer_refs=[x for x in s.scalars(select(EquipmentTransfer)).all() if asset_id in json.loads(x.asset_ids_json or "[]")]
    if transfer_refs:
        raise HTTPException(409, "Оборудование участвует в актах передачи/возврата и не может быть физически удалено. Оставьте карточку помеченной или измените статус на «Списано».")
    for x in s.scalars(select(Component).where(Component.asset_id==asset_id)).all(): s.delete(x)
    for x in s.scalars(select(SoftwareInstallation).where(SoftwareInstallation.asset_id==asset_id)).all(): s.delete(x)
    for x in s.scalars(select(ConsumableCompatibility).where(ConsumableCompatibility.asset_id==asset_id)).all(): s.delete(x)
    p=s.scalar(select(PrintDeviceProfile).where(PrintDeviceProfile.asset_id==asset_id))
    if p: s.delete(p)
    for x in s.scalars(select(InventoryScan).where(InventoryScan.asset_id==asset_id)).all(): s.delete(x)

    # Исторические и эксплуатационные записи сохраняем, но отвязываем от удаляемого оборудования.
    # Иначе PostgreSQL блокирует DELETE из-за внешних ключей на assets.id.
    for x in s.scalars(select(AuditLog).where(AuditLog.asset_id==asset_id)).all(): x.asset_id=None
    for x in s.scalars(select(VaultCredential).where(VaultCredential.asset_id==asset_id)).all(): x.asset_id=None
    for x in s.scalars(select(HelpdeskTicket).where(HelpdeskTicket.asset_id==asset_id)).all(): x.asset_id=None

    s.add(AuditLog(action="Оборудование удалено",details=f"{inv}; Главный администратор: {actor.username}; ранее помечено: {a.deletion_marked_by or '—'}"))
    s.delete(a); s.commit(); return {"ok":True}

class ComponentIn(BaseModel):
    component_type: str
    slot: Optional[str] = None
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    serial_no: Optional[str] = None
    specification: Optional[str] = None
    notes: Optional[str] = None

@app.post("/api/assets/{asset_id}/components")
def add_component(asset_id:int,d:ComponentIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    a=ensure_same_organization(s.get(Asset,asset_id),organization_id,"Оборудование")
    c=Component(asset_id=asset_id,**d.model_dump()); s.add(c); s.flush()
    s.add(AuditLog(asset_id=asset_id,action="Комплектация",details=f"Добавлен компонент: {c.component_type} {c.manufacturer or ''} {c.model or ''}".strip()))
    s.commit(); s.refresh(c); return {"id":c.id}

@app.delete("/api/assets/{asset_id}/components/{component_id}")
def delete_component(asset_id:int,component_id:int,s:Session=Depends(db)):
    c=s.get(Component,component_id)
    if not c or c.asset_id!=asset_id: raise HTTPException(404,"Компонент не найден")
    label=f"{c.component_type} {c.manufacturer or ''} {c.model or ''}".strip(); s.delete(c)
    s.add(AuditLog(asset_id=asset_id,action="Комплектация",details=f"Удалён компонент: {label}")); s.commit(); return {"ok":True}

def software_install_dict(x: SoftwareInstallation):
    a=x.asset
    return {
        "id":x.id,"software_id":x.software_id,"software_name":x.software.name if x.software else None,
        "software_vendor":x.software.vendor if x.software else None,"software_version":x.software.version if x.software else None,
        "asset_id":x.asset_id,"inventory_no":a.inventory_no if a else None,"asset_category":a.category if a else None,
        "asset_name":" ".join([v for v in [a.manufacturer if a else None,a.model if a else None] if v]) or (a.category if a else None),
        "current_employee_id":a.employee_id if a else None,"current_employee":a.employee.name if a and a.employee else None,
        "installed_for_employee_id":x.installed_for_employee_id,
        "installed_for_employee":x.installed_for_employee.name if x.installed_for_employee else None,
        "installed_at":str(x.installed_at) if x.installed_at else None,"environment":x.environment,
        "license_info":x.license_info,"notes":x.notes,
    }

@app.get("/api/software")
def software_list(s:Session=Depends(db)):
    xs=s.scalars(select(Software).order_by(Software.name,Software.version)).all()
    return [{"id":x.id,"name":x.name,"vendor":x.vendor,"version":x.version,"license_type":x.license_type,"notes":x.notes,
             "installations":s.scalar(select(func.count()).select_from(SoftwareInstallation).where(SoftwareInstallation.software_id==x.id)) or 0} for x in xs]

@app.post("/api/software")
def software_add(d:SoftwareIn,s:Session=Depends(db)):
    x=Software(**d.model_dump());s.add(x);s.commit();s.refresh(x);return {"id":x.id}

@app.put("/api/software/{item_id}")
def software_edit(item_id:int,d:SoftwareIn,s:Session=Depends(db)):
    x=s.get(Software,item_id)
    if not x: raise HTTPException(404,"ПО не найдено")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.commit();return {"ok":True}

@app.delete("/api/software/{item_id}")
def software_delete(item_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    x=s.get(Software,item_id)
    if not x: raise HTTPException(404,"ПО не найдено")
    if s.scalar(select(func.count()).select_from(SoftwareInstallation).where(SoftwareInstallation.software_id==item_id)):
        raise HTTPException(409,"Сначала удалите установки этого ПО")
    s.delete(x);s.commit();return {"ok":True}

@app.get("/api/software/installations")
def software_installations(asset_id:Optional[int]=None,employee_id:Optional[int]=None,s:Session=Depends(db)):
    stmt=select(SoftwareInstallation).order_by(SoftwareInstallation.installed_at.desc(),SoftwareInstallation.id.desc())
    if asset_id: stmt=stmt.where(SoftwareInstallation.asset_id==asset_id)
    if employee_id:
        stmt=stmt.join(Asset,SoftwareInstallation.asset_id==Asset.id).where((SoftwareInstallation.installed_for_employee_id==employee_id)|(Asset.employee_id==employee_id))
    return [software_install_dict(x) for x in s.scalars(stmt).all()]

@app.post("/api/software/installations")
def software_install_add(d:SoftwareInstallationIn,s:Session=Depends(db)):
    sw=s.get(Software,d.software_id);a=s.get(Asset,d.asset_id)
    if not sw: raise HTTPException(404,"ПО не найдено")
    if not a: raise HTTPException(404,"Оборудование не найдено")
    data=d.model_dump();data["installed_at"]=data.get("installed_at") or date.today()
    if data.get("installed_for_employee_id") is None: data["installed_for_employee_id"]=a.employee_id
    x=SoftwareInstallation(**data);s.add(x);s.flush()
    s.add(AuditLog(asset_id=a.id,action="ПО установлено",details=f"{sw.name} {sw.version or ''} · {x.installed_at}".strip()))
    s.commit();s.refresh(x);return software_install_dict(x)

@app.put("/api/software/installations/{item_id}")
def software_install_edit(item_id:int,d:SoftwareInstallationIn,s:Session=Depends(db)):
    x=s.get(SoftwareInstallation,item_id)
    if not x: raise HTTPException(404,"Установка ПО не найдена")
    data=d.model_dump();data["installed_at"]=data.get("installed_at") or x.installed_at or date.today()
    for k,v in data.items(): setattr(x,k,v)
    s.commit();s.refresh(x);return software_install_dict(x)

@app.delete("/api/software/installations/{item_id}")
def software_install_delete(item_id:int,s:Session=Depends(db)):
    x=s.get(SoftwareInstallation,item_id)
    if not x: raise HTTPException(404,"Установка ПО не найдена")
    asset_id=x.asset_id; label=x.software.name if x.software else "ПО"
    s.delete(x);s.add(AuditLog(asset_id=asset_id,action="ПО удалено",details=label));s.commit();return {"ok":True}

@app.get("/api/organizations")
def organizations_list(include_all: bool = False, s: Session = Depends(db), actor: Optional[AppUser] = Depends(current_actor)):
    stmt = select(Organization).order_by(Organization.name)
    if include_all and actor and actor.role == "Главный администратор":
        pass
    else:
        stmt = stmt.where(Organization.service_status == "active", Organization.is_active == 1)
        if actor and actor.role != "Главный администратор" and actor.organization_id:
            stmt = stmt.where(Organization.id == actor.organization_id)
    rows=s.scalars(stmt).all()
    out=[]
    for x in rows:
        item={"id":x.id,"name":x.name,"organization_type":x.organization_type,"is_active":bool(x.is_active),"service_status":x.service_status or ("active" if x.is_active else "archived"),"created_at":x.created_at.isoformat() if x.created_at else None}
        if include_all and actor and actor.role == "Главный администратор":
            item.update({
                "sites_count": s.scalar(select(func.count(Site.id)).where(Site.organization_id==x.id)) or 0,
                "assets_count": s.scalar(select(func.count(Asset.id)).where(Asset.organization_id==x.id)) or 0,
                "users_count": s.scalar(select(func.count(AppUser.id)).where(AppUser.organization_id==x.id)) or 0,
                "tickets_count": s.scalar(select(func.count(HelpdeskTicket.id)).where(HelpdeskTicket.organization_id==x.id)) or 0,
                "nas_count": s.scalar(select(func.count(NasDevice.id)).where(NasDevice.organization_id==x.id)) or 0,
            })
        out.append(item)
    return out

@app.post("/api/organizations")
def organization_add(d: OrganizationIn, s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    name=d.name.strip()
    if not name: raise HTTPException(400,"Название организации обязательно")
    if d.organization_type not in ("internal","client"):
        raise HTTPException(400,"Тип организации: internal или client")
    status=(d.service_status or "active").strip().lower()
    if status not in ("active","paused","archived"):
        raise HTTPException(400,"Статус организации должен быть active, paused или archived")
    x=Organization(name=name,organization_type=d.organization_type,service_status=status,is_active=1 if status=="active" else 0)
    s.add(x);safe_commit(s,"Организация");s.refresh(x)
    return {"id":x.id,"name":x.name,"organization_type":x.organization_type,"is_active":bool(x.is_active),"service_status":x.service_status}

@app.put("/api/organizations/{item_id}")
def organization_edit(item_id:int,d:OrganizationIn,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    x=s.get(Organization,item_id)
    if not x: raise HTTPException(404,"Организация не найдена")
    status=(d.service_status or "active").strip().lower()
    if status not in ("active","paused","archived"):
        raise HTTPException(400,"Статус организации должен быть active, paused или archived")
    x.name=d.name.strip();x.organization_type=d.organization_type;x.service_status=status;x.is_active=1 if status=="active" else 0
    safe_commit(s,"Организация");return {"ok":True}

@app.delete("/api/organizations/{item_id}")
def organization_delete(item_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    x=s.get(Organization,item_id)
    if not x: raise HTTPException(404,"Организация не найдена")
    busy=0
    for model in (Company,Site,OrgUnit,Employee,Location,Workplace,Asset,AssetMap,InventorySession,NasDevice,HelpdeskTicket):
        busy += s.scalar(select(func.count(model.id)).where(model.organization_id==item_id)) or 0
    if busy:
        raise HTTPException(409, f"Организация содержит связанные данные ({busy}). Сначала перенесите или пометьте/удалите объекты.")
    if s.scalar(select(func.count(AppUser.id)).where(AppUser.organization_id==item_id)):
        raise HTTPException(409,"К организации привязаны пользователи системы. Сначала переназначьте их.")
    name=x.name; s.delete(x); s.add(AuditLog(action="Организация удалена",details=f"{name}; {actor.username}")); s.commit(); return {"ok":True}

@app.get("/api/companies")
def companies(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    return [{"id":x.id,"name":x.name,"organization_id":x.organization_id} for x in s.scalars(select(Company).where(Company.organization_id==organization_id).order_by(Company.name)).all()]
@app.post("/api/companies")
def add_company(d:OrgIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    name=d.name.strip()
    if s.scalar(select(Company.id).where(Company.organization_id==organization_id,func.lower(Company.name)==name.lower())): raise HTTPException(409,"Компания с таким названием уже есть в этой организации")
    x=Company(name=name,organization_id=organization_id); s.add(x); safe_commit(s,"Компания"); s.refresh(x); return {"id":x.id,"name":x.name,"organization_id":x.organization_id}
@app.put("/api/companies/{item_id}")
def edit_company(item_id:int,d:OrgIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Company,item_id),organization_id,"Компания")
    x.name=d.name.strip(); s.commit(); return {"ok":True}


@app.delete("/api/companies/{item_id}")
def delete_company(item_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Company,item_id),organization_id,"Компания")
    blockers=[]
    if s.scalar(select(func.count()).select_from(Employee).where(Employee.company_id==item_id)): blockers.append("сотрудники")
    if s.scalar(select(func.count()).select_from(OrgUnit).where(OrgUnit.company_id==item_id)): blockers.append("отделы")
    if s.scalar(select(func.count()).select_from(Asset).where(Asset.company_id==item_id)): blockers.append("оборудование")
    if s.scalar(select(func.count()).select_from(Department).where(Department.company_id==item_id)): blockers.append("старые подразделения")
    if blockers: raise HTTPException(409,"Нельзя удалить компанию: связаны " + ", ".join(blockers))
    name=x.name;s.delete(x);s.add(AuditLog(action="Компания удалена",details=f"{name}; {actor.username}"));s.commit();return {"ok":True}

@app.get("/api/sites")
def sites(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    return [{"id":x.id,"name":x.name,"site_type":x.site_type,"address":x.address,"notes":x.notes,"organization_id":x.organization_id} for x in s.scalars(select(Site).where(Site.organization_id==organization_id).order_by(Site.name)).all()]

@app.post("/api/sites")
def site_add(d:SiteIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    if s.scalar(select(Site.id).where(Site.organization_id==organization_id,func.lower(Site.name)==d.name.strip().lower())): raise HTTPException(409,"Площадка с таким названием уже есть в этой организации")
    x=Site(**d.model_dump(),organization_id=organization_id);s.add(x);safe_commit(s,"Площадка");s.refresh(x);return {"id":x.id}

@app.put("/api/sites/{item_id}")
def site_edit(item_id:int,d:SiteIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Site,item_id),organization_id,"Площадка")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    safe_commit(s,"Площадка");return {"ok":True}


@app.delete("/api/sites/{item_id}")
def site_delete(item_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Site,item_id),organization_id,"Площадка")
    blockers=[]
    if s.scalar(select(func.count()).select_from(Employee).where(Employee.site_id==item_id)): blockers.append("сотрудники")
    if s.scalar(select(func.count()).select_from(Asset).where(Asset.site_id==item_id)): blockers.append("оборудование")
    if blockers: raise HTTPException(409,"Нельзя удалить площадку: связаны " + ", ".join(blockers))
    name=x.name;s.delete(x);s.add(AuditLog(action="Площадка удалена",details=f"{name}; {actor.username}"));s.commit();return {"ok":True}

@app.get("/api/org-units")
def org_units(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    xs=s.scalars(select(OrgUnit).where(OrgUnit.organization_id==organization_id).order_by(OrgUnit.name)).all()
    return [{"id":x.id,"name":x.name,"company_id":x.company_id,"company":x.company.name if x.company else None,"notes":x.notes} for x in xs]

@app.post("/api/org-units")
def org_unit_add(d:OrgUnitIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=OrgUnit(**d.model_dump(),organization_id=organization_id);s.add(x);safe_commit(s,"Отдел");s.refresh(x);return {"id":x.id}

@app.put("/api/org-units/{item_id}")
def org_unit_edit(item_id:int,d:OrgUnitIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(OrgUnit,item_id),organization_id,"Отдел")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    safe_commit(s,"Отдел");return {"ok":True}


@app.delete("/api/org-units/{item_id}")
def org_unit_delete(item_id:int,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    x=s.get(OrgUnit,item_id)
    if not x: raise HTTPException(404,"Отдел не найден")
    blockers=[]
    if s.scalar(select(func.count()).select_from(Employee).where(Employee.org_unit_id==item_id)): blockers.append("сотрудники")
    if s.scalar(select(func.count()).select_from(Asset).where(Asset.org_unit_id==item_id)): blockers.append("оборудование")
    if blockers: raise HTTPException(409,"Нельзя удалить отдел: связаны " + ", ".join(blockers))
    name=x.name;s.delete(x);s.add(AuditLog(action="Отдел удалён",details=f"{name}; {actor.username}"));s.commit();return {"ok":True}

@app.get("/api/departments")
def departments(s:Session=Depends(db)):
    xs=s.scalars(select(Department).order_by(Department.name)).all()
    return [{"id":x.id,"name":x.name,"company_id":x.company_id,"company":x.company.name if x.company else None} for x in xs]
@app.post("/api/departments")
def add_department(d:OrgIn,s:Session=Depends(db)):
    if not d.company_id: raise HTTPException(400,"Выберите компанию")
    x=Department(name=d.name.strip(),company_id=d.company_id); s.add(x); s.commit(); s.refresh(x); return {"id":x.id,"name":x.name}
@app.put("/api/departments/{item_id}")
def edit_department(item_id:int,d:OrgIn,s:Session=Depends(db)):
    x=s.get(Department,item_id)
    if not x: raise HTTPException(404,"Подразделение не найдено")
    x.name=d.name.strip(); x.company_id=d.company_id or x.company_id; s.commit(); return {"ok":True}

@app.get("/api/server-rooms")
def server_rooms(s:Session=Depends(db)):
    xs=s.scalars(select(ServerRoom).order_by(ServerRoom.name)).all()
    return [{"id":x.id,"name":x.name,"company_id":x.company_id,"site_id":x.site_id,"org_unit_id":x.org_unit_id,"location_id":x.location_id,"company":x.company.name if x.company else None,"site":x.site.name if x.site else None,"org_unit":x.org_unit.name if x.org_unit else None,"location":x.location.name if x.location else None,"notes":x.notes} for x in xs]
@app.post("/api/server-rooms")
def server_room_add(d:ServerRoomIn,s:Session=Depends(db)):
    x=ServerRoom(**d.model_dump());s.add(x);s.commit();s.refresh(x);return {"id":x.id}
@app.put("/api/server-rooms/{item_id}")
def server_room_edit(item_id:int,d:ServerRoomIn,s:Session=Depends(db)):
    x=s.get(ServerRoom,item_id)
    if not x: raise HTTPException(404,"Серверная не найдена")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.commit();return {"ok":True}
@app.delete("/api/server-rooms/{item_id}")
def server_room_delete(item_id:int,s:Session=Depends(db)):
    x=s.get(ServerRoom,item_id)
    if not x: raise HTTPException(404,"Серверная не найдена")
    if s.scalar(select(func.count()).select_from(Rack).where(Rack.server_room_id==item_id)):
        raise HTTPException(409,"Сначала удалите или перенесите стойки из серверной")
    for a in s.scalars(select(Asset).where(Asset.server_room_id==item_id)).all(): a.server_room_id=None
    s.delete(x);s.commit();return {"ok":True}

@app.get("/api/racks")
def racks(s:Session=Depends(db)):
    xs=s.scalars(select(Rack).order_by(Rack.code)).all()
    return [{"id":x.id,"server_room_id":x.server_room_id,"server_room":x.server_room.name if x.server_room else None,"code":x.code,"name":x.name,"units":x.units,"notes":x.notes} for x in xs]
@app.post("/api/racks")
def rack_add(d:RackIn,s:Session=Depends(db)):
    x=Rack(**d.model_dump());s.add(x);s.commit();s.refresh(x);return {"id":x.id}
@app.put("/api/racks/{item_id}")
def rack_edit(item_id:int,d:RackIn,s:Session=Depends(db)):
    x=s.get(Rack,item_id)
    if not x: raise HTTPException(404,"Стойка не найдена")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.commit();return {"ok":True}
@app.delete("/api/racks/{item_id}")
def rack_delete(item_id:int,s:Session=Depends(db)):
    x=s.get(Rack,item_id)
    if not x: raise HTTPException(404,"Стойка не найдена")
    for a in s.scalars(select(Asset).where(Asset.rack_id==item_id)).all(): a.rack_id=None;a.rack_unit=None
    s.delete(x);s.commit();return {"ok":True}

@app.get("/api/employees")
def employees(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    xs=s.scalars(select(Employee).where(Employee.organization_id==organization_id).order_by(Employee.name)).all()
    return [{"id":x.id,"name":x.name,"email":x.email,"company_id":x.company_id,"company":x.company.name if x.company else None,
             "site_id":x.site_id,"site":x.site.name if x.site else None,
             "org_unit_id":x.org_unit_id,"org_unit":x.org_unit.name if x.org_unit else None,
             "location_id":x.location_id,"location":x.location_rel.name if x.location_rel else None,
             "position":x.position,"personnel_no":x.personnel_no,"work_phone":x.work_phone,"extension":x.extension,
             "mobile_phone":x.mobile_phone,"account_name":x.account_name,"employment_status":x.employment_status or "Работает",
             "started_at":str(x.started_at) if x.started_at else None,"ended_at":str(x.ended_at) if x.ended_at else None,
             "notes":x.notes,"department":x.department,"department_id":x.department_id,
             "department_name":x.department_rel.name if x.department_rel else x.department} for x in xs]

@app.post("/api/employees")
def add_employee(d:EmployeeIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=Employee(**d.model_dump(),organization_id=organization_id);s.add(x);s.commit();s.refresh(x);return {"id":x.id,"name":x.name}

@app.put("/api/employees/{item_id}")
def edit_employee(item_id:int,d:EmployeeIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Employee,item_id),organization_id,"Сотрудник")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.commit();return {"ok":True}

@app.delete("/api/employees/{item_id}")
def del_employee(item_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Employee,item_id),organization_id,"Сотрудник")
    for a in s.scalars(select(Asset).where(Asset.employee_id==item_id)).all(): a.employee_id=None
    for i in s.scalars(select(SoftwareInstallation).where(SoftwareInstallation.installed_for_employee_id==item_id)).all(): i.installed_for_employee_id=None
    for w in s.scalars(select(Workplace).where(Workplace.employee_id==item_id)).all(): w.employee_id=None
    for u in s.scalars(select(AppUser).where(AppUser.employee_id==item_id)).all(): u.employee_id=None
    s.delete(x);s.commit();return {"ok":True}

@app.get("/api/locations")
def locations(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)): return [{"id":x.id,"name":x.name,"parent":x.parent} for x in s.scalars(select(Location).where(Location.organization_id==organization_id).order_by(Location.name)).all()]
@app.post("/api/locations")
def add_location(d:NamedIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=Location(name=d.name,parent=d.parent,organization_id=organization_id); s.add(x); s.commit(); s.refresh(x); return {"id":x.id,"name":x.name}
@app.put("/api/locations/{item_id}")
def edit_location(item_id:int,d:NamedIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Location,item_id),organization_id,"Помещение")
    x.name=d.name; x.parent=d.parent; s.commit(); return {"ok":True}
@app.delete("/api/locations/{item_id}")
def del_location(item_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Location,item_id),organization_id,"Помещение")
    for a in s.scalars(select(Asset).where(Asset.location_id==item_id)).all(): a.location_id=None
    for w in s.scalars(select(Workplace).where(Workplace.location_id==item_id)).all(): w.location_id=None
    for inv in s.scalars(select(InventorySession).where(InventorySession.location_id==item_id)).all(): inv.location_id=None
    s.delete(x); s.commit(); return {"ok":True}
@app.get("/api/workplaces")
def workplaces(s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    xs=s.scalars(select(Workplace).where(Workplace.organization_id==organization_id).order_by(Workplace.code)).all()
    out=[]
    for x in xs:
        assets=s.scalars(select(Asset).where(Asset.workplace_id==x.id).order_by(Asset.category,Asset.inventory_no)).all()
        out.append({"id":x.id,"code":x.code,"name":x.name,"employee_id":x.employee_id,"location_id":x.location_id,
                    "company_id":x.company_id,"department_id":x.department_id,
                    "employee":x.employee.name if x.employee else None,"location":x.location.name if x.location else None,
                    "assets":[{"id":a.id,"inventory_no":a.inventory_no,"category":a.category,"manufacturer":a.manufacturer,"model":a.model} for a in assets]})
    return out
_workplace_number_lock = threading.Lock()

def next_workplace_code(s: Session, organization_id: Optional[int] = None):
    highest=0
    stmt=select(Workplace.code)
    if organization_id is not None: stmt=stmt.where(Workplace.organization_id==organization_id)
    for code in s.scalars(stmt):
        match=re.fullmatch(r"WP-(\d+)",(code or '').strip(),re.IGNORECASE)
        if match: highest=max(highest,int(match.group(1)))
    return f"WP-{highest+1:04d}"

def normalized_workplace_code(value):
    code=(value or '').strip()
    if len(code)>80 or any(ord(c)<32 for c in code):
        raise HTTPException(422,"Код рабочего места: не более 80 символов, без управляющих символов")
    return code

@app.post("/api/workplaces")
def add_workplace(d:WorkplaceIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    requested=normalized_workplace_code(d.code)
    with _workplace_number_lock:
        for attempt in range(8):
            # Serialize automatic allocation between PostgreSQL workers, without a migration.
            if not requested and engine.dialect.name=="postgresql":
                s.execute(text("SELECT pg_advisory_xact_lock(806121206)"))
            code=requested or next_workplace_code(s, organization_id)
            if s.scalar(select(Workplace.id).where(Workplace.organization_id==organization_id,func.lower(Workplace.code)==code.lower())):
                s.rollback()
                if requested: raise HTTPException(409,"Рабочее место с таким кодом уже существует")
                continue
            x=Workplace(**{**d.model_dump(),"code":code,"organization_id":organization_id});s.add(x)
            try:
                s.commit();s.refresh(x)
                return {"id":x.id,"code":x.code}
            except IntegrityError:
                s.rollback()
                if requested: raise HTTPException(409,"Код рабочего места занят либо некорректна привязка к сотруднику/помещению") from None
        raise HTTPException(409,"Не удалось назначить номер рабочего места. Повторите сохранение.")
@app.put("/api/workplaces/{item_id}")
def edit_workplace(item_id:int,d:WorkplaceIn,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Workplace,item_id),organization_id,"Рабочее место")
    code=normalized_workplace_code(d.code) or x.code
    dup=s.scalar(select(Workplace).where(Workplace.organization_id==organization_id,func.lower(Workplace.code)==code.lower(), Workplace.id!=item_id))
    if dup: raise HTTPException(409,"Рабочее место с таким кодом уже существует")
    for k,v in {**d.model_dump(),"code":code}.items(): setattr(x,k,v)
    safe_commit(s,"Рабочее место"); return {"ok":True}
@app.delete("/api/workplaces/{item_id}")
def del_workplace(item_id:int,s:Session=Depends(db),organization_id:int=Depends(current_organization_id)):
    x=ensure_same_organization(s.get(Workplace,item_id),organization_id,"Рабочее место")
    for a in s.scalars(select(Asset).where(Asset.workplace_id==item_id)).all(): a.workplace_id=None
    s.delete(x); s.commit(); return {"ok":True}

@app.get("/api/audit")
def audit(s:Session=Depends(db)):
    return [{"id":x.id,"asset_id":x.asset_id,"action":x.action,"details":x.details,"created_at":x.created_at.isoformat()} for x in s.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(300)).all()]

@app.get("/api/assets/{asset_id}/qr")
def qr(asset_id:int,s:Session=Depends(db)):
    a=s.get(Asset,asset_id)
    if not a: raise HTTPException(404)
    img=qrcode.make(a.inventory_no); b=io.BytesIO(); img.save(b,format="PNG"); b.seek(0); return StreamingResponse(b,media_type="image/png")

@app.get("/api/assets/{asset_id}/barcode")
def bar(asset_id:int,s:Session=Depends(db)):
    a=s.get(Asset,asset_id)
    if not a: raise HTTPException(404)
    cls=barcode.get_barcode_class("code128"); b=io.BytesIO(); cls(a.inventory_no,writer=SVGWriter()).write(b,options={"write_text":True}); b.seek(0); return StreamingResponse(b,media_type="image/svg+xml")


def _print_asset(a: Asset):
    return a.category in ("Принтер","МФУ","Плоттер")

@app.get("/api/printing/devices")
def printing_devices(s:Session=Depends(db)):
    assets=s.scalars(select(Asset).where(Asset.category.in_(["Принтер","МФУ","Плоттер"])).order_by(Asset.inventory_no)).all()
    profiles={x.asset_id:x for x in s.scalars(select(PrintDeviceProfile)).all()}
    out=[]
    for a in assets:
        d=asset_dict(a); p=profiles.get(a.id)
        d["print_profile"]={"technology":p.technology,"color_mode":p.color_mode,"max_format":p.max_format,"connection_type":p.connection_type,"network_name":p.network_name,"ip_address":p.ip_address,"notes":p.notes} if p else None
        out.append(d)
    return out

@app.put("/api/printing/devices/{asset_id}/profile")
def printing_profile(asset_id:int,d:PrintProfileIn,s:Session=Depends(db)):
    a=s.get(Asset,asset_id)
    if not a or not _print_asset(a): raise HTTPException(404,"Печатающее устройство не найдено")
    p=s.scalar(select(PrintDeviceProfile).where(PrintDeviceProfile.asset_id==asset_id))
    if not p: p=PrintDeviceProfile(asset_id=asset_id); s.add(p)
    for k,v in d.model_dump().items(): setattr(p,k,v)
    s.add(AuditLog(asset_id=asset_id,action="Печатающее устройство",details="Обновлены параметры печати/подключения"));s.commit();return {"ok":True}

@app.get("/api/consumables")
def consumables(s:Session=Depends(db)):
    xs=s.scalars(select(Consumable).order_by(Consumable.name)).all(); links=s.scalars(select(ConsumableCompatibility)).all()
    mp={}
    for x in links: mp.setdefault(x.consumable_id,[]).append(x.asset_id)
    return [{"id":x.id,"name":x.name,"consumable_type":x.consumable_type,"manufacturer":x.manufacturer,"model":x.model,"color":x.color,"sku":x.sku,"resource":x.resource,"quantity":x.quantity,"min_quantity":x.min_quantity,"unit":x.unit,"notes":x.notes,"compatible_asset_ids":mp.get(x.id,[]),"low_stock":x.quantity<=x.min_quantity} for x in xs]

@app.post("/api/consumables")
def consumable_add(d:ConsumableIn,s:Session=Depends(db)):
    data=d.model_dump(); ids=data.pop("compatible_asset_ids",[]); x=Consumable(**data);s.add(x);s.flush()
    for aid in sorted(set(ids)):
        a=s.get(Asset,aid)
        if a and _print_asset(a): s.add(ConsumableCompatibility(consumable_id=x.id,asset_id=aid))
    s.add(AuditLog(action="Расходный материал создан",details=f"{x.name}; остаток {x.quantity} {x.unit}"));s.commit();s.refresh(x);return {"id":x.id}

@app.put("/api/consumables/{item_id}")
def consumable_edit(item_id:int,d:ConsumableIn,s:Session=Depends(db)):
    x=s.get(Consumable,item_id)
    if not x: raise HTTPException(404,"Расходный материал не найден")
    data=d.model_dump(); ids=data.pop("compatible_asset_ids",[])
    for k,v in data.items(): setattr(x,k,v)
    for z in s.scalars(select(ConsumableCompatibility).where(ConsumableCompatibility.consumable_id==item_id)).all(): s.delete(z)
    for aid in sorted(set(ids)):
        a=s.get(Asset,aid)
        if a and _print_asset(a): s.add(ConsumableCompatibility(consumable_id=item_id,asset_id=aid))
    s.add(AuditLog(action="Расходный материал изменён",details=x.name));s.commit();return {"ok":True}

@app.post("/api/consumables/{item_id}/move")
def consumable_move(item_id:int,d:ConsumableMoveIn,s:Session=Depends(db)):
    x=s.get(Consumable,item_id)
    if not x: raise HTTPException(404,"Расходный материал не найден")
    if not d.delta: raise HTTPException(400,"Количество изменения не может быть нулём")
    if x.quantity+d.delta<0: raise HTTPException(400,"Недостаточно расходного материала на складе")
    x.quantity+=d.delta;s.add(ConsumableMovement(consumable_id=item_id,delta=d.delta,reason=d.reason));s.add(AuditLog(action="Движение расходников",details=f"{x.name}: {d.delta:+d} {x.unit}. {d.reason or ''}".strip()));s.commit();return {"ok":True,"quantity":x.quantity}

@app.get("/api/consumables/{item_id}/movements")
def consumable_movements(item_id:int,s:Session=Depends(db)):
    return [{"id":x.id,"delta":x.delta,"reason":x.reason,"created_at":x.created_at.isoformat()} for x in s.scalars(select(ConsumableMovement).where(ConsumableMovement.consumable_id==item_id).order_by(ConsumableMovement.id.desc()).limit(100)).all()]

@app.delete("/api/consumables/{item_id}")
def consumable_delete(item_id:int,s:Session=Depends(db), actor: AppUser = Depends(require_main_admin)):
    x=s.get(Consumable,item_id)
    if not x: raise HTTPException(404,"Расходный материал не найден")
    for z in s.scalars(select(ConsumableCompatibility).where(ConsumableCompatibility.consumable_id==item_id)).all(): s.delete(z)
    for z in s.scalars(select(ConsumableMovement).where(ConsumableMovement.consumable_id==item_id)).all(): s.delete(z)
    s.add(AuditLog(action="Расходный материал удалён",details=f"{x.name}; {actor.username}"));s.delete(x);s.commit();return {"ok":True}

@app.get("/api/export.xlsx")
def export_xlsx(s:Session=Depends(db)):
    wb=Workbook()
    ws=wb.active; ws.title="Оборудование"

    companies={x.id:x.name for x in s.scalars(select(Company)).all()}
    deps={x.id:x.name for x in s.scalars(select(Department)).all()}
    rooms={x.id:x.name for x in s.scalars(select(ServerRoom)).all()}
    racks={x.id:x.code for x in s.scalars(select(Rack)).all()}
    assets=s.scalars(select(Asset).order_by(Asset.inventory_no)).all()
    employees=s.scalars(select(Employee).order_by(Employee.name)).all()
    installations=s.scalars(select(SoftwareInstallation).order_by(SoftwareInstallation.installed_at,SoftwareInstallation.id)).all()

    # 1. Equipment: technical register, kept compatible with import.
    ws.append(["Инвентарный номер","Категория","Производитель","Модель","Серийный номер","Статус","Компания","Площадка","Отдел","Сотрудник","Помещение","Рабочее место","Серверная","Стойка","Позиция U","Высота U","Тип сервера","Основной IP","Management IP","ОС","Гипервизор","Кластер","Назначение","Дата покупки","Гарантия до","Комментарий"])
    for a in assets:
        ws.append([a.inventory_no,a.category,a.manufacturer,a.model,a.serial_no,a.status,companies.get(a.company_id),a.site.name if a.site else None,a.org_unit.name if a.org_unit else None,a.employee.name if a.employee else None,a.location.name if a.location else None,a.workplace.code if a.workplace else None,rooms.get(a.server_room_id),racks.get(a.rack_id),a.rack_unit,a.device_height_u,a.server_kind,a.primary_ip,a.management_ip,a.os_name,a.hypervisor,a.cluster_name,a.purpose,a.purchase_date,a.warranty_until,a.notes])

    # 2. Software: one row = one understandable installation.
    wsoft=wb.create_sheet("Программное обеспечение")
    wsoft.append(["Сотрудник","Компания","Площадка","Отдел","Устройство","Инвентарный номер","Тип устройства","Программа","Версия","Производитель ПО","Дата установки","Среда","Лицензия","Примечание"])
    for x in installations:
        a=x.asset; sw=x.software
        emp=x.installed_for_employee or (a.employee if a else None)
        wsoft.append([
            emp.name if emp else None,
            companies.get(a.company_id) if a else None,
            a.site.name if a and a.site else None,
            a.org_unit.name if a and a.org_unit else None,
            " ".join(v for v in [a.manufacturer,a.model] if v) if a else None,
            a.inventory_no if a else None,
            a.category if a else None,
            sw.name if sw else None,
            sw.version if sw else None,
            sw.vendor if sw else None,
            x.installed_at,
            x.environment,
            x.license_info or (sw.license_type if sw else None),
            x.notes
        ])

    # 3. Human-readable employee view: deliberately repeats employee/device per software row.
    wem=wb.create_sheet("Сотрудники и техника")
    wem.append(["Сотрудник","Компания","Площадка","Отдел","Должность","Рабочее место","Оборудование","Инвентарный номер","Серийный номер","Установленное ПО","Версия ПО","Дата установки"])
    for emp in employees:
        emp_assets=[a for a in assets if a.employee_id==emp.id]
        if not emp_assets:
            wem.append([emp.name,companies.get(emp.company_id),emp.site.name if emp.site else None,emp.org_unit.name if emp.org_unit else None,emp.position,None,"Нет закреплённого оборудования",None,None,None,None,None])
            continue
        for a in emp_assets:
            ins=[x for x in installations if x.asset_id==a.id and (x.installed_for_employee_id in (None,emp.id) or a.employee_id==emp.id)]
            if ins:
                for x in ins:
                    wem.append([emp.name,companies.get(emp.company_id or a.company_id),emp.site.name if emp.site else None,emp.org_unit.name if emp.org_unit else None,emp.position,a.workplace.code if a.workplace else None," ".join(v for v in [a.category,a.manufacturer,a.model] if v),a.inventory_no,a.serial_no,x.software.name if x.software else None,x.software.version if x.software else None,x.installed_at])
            else:
                wem.append([emp.name,companies.get(emp.company_id or a.company_id),emp.site.name if emp.site else None,emp.org_unit.name if emp.org_unit else None,emp.position,a.workplace.code if a.workplace else None," ".join(v for v in [a.category,a.manufacturer,a.model] if v),a.inventory_no,a.serial_no,"ПО не зарегистрировано",None,None])

    # 4. Servers and server software.
    wsv=wb.create_sheet("Серверы и ПО")
    wsv.append(["Сервер","Инвентарный номер","Компания","Площадка","Отдел","Назначение","ОС","IP","Серверная","Стойка","Программа","Версия","Дата установки","Среда","Лицензия","Примечание"])
    server_assets=[a for a in assets if (a.category or '').lower() in ('сервер','server') or a.server_kind]
    for a in server_assets:
        ins=[x for x in installations if x.asset_id==a.id]
        base=[" ".join(v for v in [a.manufacturer,a.model] if v) or a.inventory_no,a.inventory_no,companies.get(a.company_id),a.site.name if a.site else None,a.org_unit.name if a.org_unit else None,a.purpose,a.os_name,a.primary_ip,rooms.get(a.server_room_id),racks.get(a.rack_id)]
        if ins:
            for x in ins: wsv.append(base+[x.software.name if x.software else None,x.software.version if x.software else None,x.installed_at,x.environment,x.license_info or (x.software.license_type if x.software else None),x.notes])
        else:
            wsv.append(base+["ПО не зарегистрировано",None,None,None,None,None])

    # 5. Summary for managers / non-IT readers.
    sm=wb.create_sheet("Сводка",0)
    sm.append(["ИТ.Контроль v2 — сводный отчёт"])
    sm.append(["Показатель","Значение"])
    sm.append(["Всего единиц оборудования",len(assets)])
    sm.append(["Сотрудников",len(employees)])
    sm.append(["Серверов",len(server_assets)])
    sm.append(["Зарегистрированных программ",s.scalar(select(func.count()).select_from(Software)) or 0])
    sm.append(["Установок программного обеспечения",len(installations)])
    sm.append(["Оборудование без ответственного",sum(1 for a in assets if not a.employee_id)])
    sm.append([])
    sm.append(["Как читать файл"])
    sm.append(["Оборудование","Полный технический реестр имущества."])
    sm.append(["Программное обеспечение","Каждая строка показывает: кому, на какое устройство, какое ПО и когда установлено."])
    sm.append(["Сотрудники и техника","Самый простой лист: сотрудник → его техника → установленное ПО."])
    sm.append(["Серверы и ПО","Отдельный понятный отчёт по серверам и установленным на них программам."])

    worg=wb.create_sheet("Оргструктура")
    worg.append(["Тип","Компания","Название","Вид площадки","Адрес","Комментарий"])
    for x in s.scalars(select(Site).order_by(Site.name)).all():
        worg.append(["Площадка",None,x.name,x.site_type,x.address,x.notes])
    for x in s.scalars(select(OrgUnit).order_by(OrgUnit.name)).all():
        worg.append(["Отдел",x.company.name if x.company else None,x.name,None,None,x.notes])

    we=wb.create_sheet("Сотрудники")
    we.append(["Сотрудник","Компания","Площадка","Отдел","Должность","Табельный номер","Помещение","Email","Рабочий телефон","Внутренний номер","Мобильный телефон","Логин","Статус","Дата приёма","Дата увольнения","Комментарий"])
    for x in employees:
        we.append([x.name,x.company.name if x.company else None,x.site.name if x.site else None,x.org_unit.name if x.org_unit else None,x.position,x.personnel_no,x.location_rel.name if x.location_rel else None,x.email,x.work_phone,x.extension,x.mobile_phone,x.account_name,x.employment_status,x.started_at,x.ended_at,x.notes])

    wc=wb.create_sheet("Комплектация"); wc.append(["Инвентарный номер","Тип компонента","Слот/порт","Производитель","Модель","Серийный номер","Характеристика","Комментарий"])
    for c,a in s.execute(select(Component,Asset).join(Asset,Component.asset_id==Asset.id).order_by(Asset.inventory_no,Component.id)).all(): wc.append([a.inventory_no,c.component_type,c.slot,c.manufacturer,c.model,c.serial_no,c.specification,c.notes])
    wr=wb.create_sheet("Серверные"); wr.append(["Серверная","Компания","Площадка","Отдел","Помещение","Комментарий"])
    for x in s.scalars(select(ServerRoom).order_by(ServerRoom.name)).all(): wr.append([x.name,companies.get(x.company_id),x.site.name if x.site else None,x.org_unit.name if x.org_unit else None,x.location.name if x.location else None,x.notes])
    wk=wb.create_sheet("Стойки"); wk.append(["Стойка","Серверная","Название","Высота U","Комментарий"])
    for x in s.scalars(select(Rack).order_by(Rack.code)).all(): wk.append([x.code,x.server_room.name if x.server_room else None,x.name,x.units,x.notes])
    wp=wb.create_sheet("Печатающая техника"); wp.append(["Инвентарный номер","Технология","Цветность","Макс. формат","Подключение","Сетевое имя","IP","Комментарий"])
    for p,a in s.execute(select(PrintDeviceProfile,Asset).join(Asset,PrintDeviceProfile.asset_id==Asset.id).order_by(Asset.inventory_no)).all(): wp.append([a.inventory_no,p.technology,p.color_mode,p.max_format,p.connection_type,p.network_name,p.ip_address,p.notes])
    wsu=wb.create_sheet("Расходные материалы"); wsu.append(["Наименование","Тип","Производитель","Модель","Цвет","Артикул","Ресурс","Остаток","Минимальный остаток","Ед. изм.","Совместимое оборудование","Комментарий"])
    links=s.scalars(select(ConsumableCompatibility)).all(); compat={}
    for z in links: compat.setdefault(z.consumable_id,[]).append(s.get(Asset,z.asset_id).inventory_no if s.get(Asset,z.asset_id) else '')
    for x in s.scalars(select(Consumable).order_by(Consumable.name)).all(): wsu.append([x.name,x.consumable_type,x.manufacturer,x.model,x.color,x.sku,x.resource,x.quantity,x.min_quantity,x.unit,", ".join(v for v in compat.get(x.id,[]) if v),x.notes])


    # Friendly workbook styling: readable headers, filters, sensible widths.
    header_fill=PatternFill("solid",fgColor="DDEFE8")
    header_font=Font(bold=True,color="18392F")
    thin=Side(style="thin",color="D9E2DE")
    for sh in wb.worksheets:
        if sh.title=="Сводка":
            sh["A1"].font=Font(bold=True,size=16)
            sh.merge_cells("A1:B1")
            sh["A2"].fill=header_fill; sh["B2"].fill=header_fill
            sh["A2"].font=header_font; sh["B2"].font=header_font
            sh.column_dimensions["A"].width=38; sh.column_dimensions["B"].width=80
            for row in sh.iter_rows(): 
                for cell in row: cell.alignment=Alignment(vertical="top",wrap_text=True)
            continue
        if sh.max_row>=1:
            for cell in sh[1]:
                cell.font=header_font; cell.fill=header_fill; cell.alignment=Alignment(vertical="center",wrap_text=True)
                cell.border=Border(bottom=thin)
            sh.freeze_panes="A2"
            sh.auto_filter.ref=sh.dimensions
        for col in sh.columns:
            letter=col[0].column_letter
            maxlen=max([len(str(c.value)) if c.value is not None else 0 for c in col] or [0])
            sh.column_dimensions[letter].width=min(max(maxlen+2,12),38)
        for row in sh.iter_rows(min_row=2):
            for cell in row: cell.alignment=Alignment(vertical="top",wrap_text=True)

    # Treat user-provided values as text rather than executable spreadsheet formulas.
    for sheet in wb.worksheets:
        for row in sheet:
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith(("=", "+", "-", "@")):
                    cell.value = "'" + cell.value
    b=io.BytesIO(); wb.save(b); b.seek(0)
    return StreamingResponse(b,media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":"attachment; filename=inventory_with_software.xlsx"})



@app.post("/api/import.xlsx")
def import_xlsx(file:UploadFile=File(...),s:Session=Depends(db)):
    raw=file.file.read(); wb=load_workbook(io.BytesIO(raw),data_only=True)
    def rows(sheet):
        if sheet not in wb.sheetnames: return [],{}
        w=wb[sheet]; hh=[str(x.value or '').strip() for x in w[1]]; return list(w.iter_rows(min_row=2,values_only=True)),{h:i for i,h in enumerate(hh)}
    company_map={x.name:x.id for x in s.scalars(select(Company)).all()}
    rr,ii=rows("Компании")
    for r in rr:
        name=str(r[ii.get("Компания",0)] or '').strip()
        if name and name not in company_map: x=Company(name=name);s.add(x);s.flush();company_map[name]=x.id
    dep_map={(x.company_id,x.name):x.id for x in s.scalars(select(Department)).all()}
    rr,ii=rows("Подразделения")
    for r in rr:
        cn=str(r[ii.get("Компания",0)] or '').strip(); dn=str(r[ii.get("Подразделение",1)] or '').strip(); cid=company_map.get(cn)
        if cid and dn and (cid,dn) not in dep_map: x=Department(company_id=cid,name=dn);s.add(x);s.flush();dep_map[(cid,dn)]=x.id
    emp_map={x.name:x.id for x in s.scalars(select(Employee)).all()}
    rr,ii=rows("Сотрудники")
    for r in rr:
        name=str(r[ii.get("Сотрудник",0)] or '').strip(); cn=str(r[ii.get("Компания",1)] or '').strip(); dn=str(r[ii.get("Подразделение",2)] or '').strip(); cid=company_map.get(cn); did=dep_map.get((cid,dn))
        if name and name not in emp_map: x=Employee(name=name,company_id=cid,department_id=did,department=dn or None);s.add(x);s.flush();emp_map[name]=x.id
    room_map={x.name:x.id for x in s.scalars(select(ServerRoom)).all()}
    rr,ii=rows("Серверные")
    for r in rr:
        rn=str(r[ii.get("Серверная",0)] or '').strip(); cn=str(r[ii.get("Компания",1)] or '').strip(); cid=company_map.get(cn)
        dn=str(r[ii.get("Подразделение",2)] or '').strip() if "Подразделение" in ii else ""; did=dep_map.get((cid,dn))
        sn=str(r[ii.get("Площадка",2)] or '').strip() if "Площадка" in ii else ""
        on=str(r[ii.get("Отдел",3)] or '').strip() if "Отдел" in ii else ""
        loc_idx=ii.get("Помещение",4 if "Площадка" in ii else 3); loc=str(r[loc_idx] or '').strip() if loc_idx is not None else ""
        site_id=s.scalar(select(Site.id).where(Site.name==sn)) if sn else None
        org_id=s.scalar(select(OrgUnit.id).where(OrgUnit.company_id==cid,OrgUnit.name==on)) if cid and on else None
        lid=s.scalar(select(Location.id).where(Location.name==loc)) if loc else None
        comment_idx=ii.get("Комментарий",5 if "Площадка" in ii else 4)
        comment=str(r[comment_idx] or '').strip() if comment_idx is not None else ""
        if rn and rn not in room_map: x=ServerRoom(name=rn,company_id=cid,department_id=did,site_id=site_id,org_unit_id=org_id,location_id=lid,notes=comment or None);s.add(x);s.flush();room_map[rn]=x.id
    rack_map={x.code:x.id for x in s.scalars(select(Rack)).all()}
    rr,ii=rows("Стойки")
    for r in rr:
        code=str(r[ii.get("Стойка",0)] or '').strip(); rn=str(r[ii.get("Серверная",1)] or '').strip(); name=str(r[ii.get("Название",2)] or '').strip(); units=int(r[ii.get("Высота U",3)] or 42)
        if code and code not in rack_map and room_map.get(rn): x=Rack(code=code,server_room_id=room_map[rn],name=name or None,units=units,notes=str(r[ii.get("Комментарий",4)] or '').strip() or None);s.add(x);s.flush();rack_map[code]=x.id
    wp_map={x.code:x.id for x in s.scalars(select(Workplace)).all()}
    rr,ii=rows("Рабочие места")
    for r in rr:
        code=str(r[ii.get("Код",0)] or '').strip(); name=str(r[ii.get("Название",1)] or code).strip(); en=str(r[ii.get("Сотрудник",2)] or '').strip(); cn=str(r[ii.get("Компания",3)] or '').strip(); dn=str(r[ii.get("Подразделение",4)] or '').strip(); cid=company_map.get(cn);did=dep_map.get((cid,dn))
        if code and code not in wp_map: x=Workplace(code=code,name=name,employee_id=emp_map.get(en),company_id=cid,department_id=did);s.add(x);s.flush();wp_map[code]=x.id
    ws=wb["Оборудование"] if "Оборудование" in wb.sheetnames else wb.active; headers=[str(x.value or '').strip() for x in ws[1]]; ci={h:i for i,h in enumerate(headers)}; count=0;components=0
    for row in ws.iter_rows(min_row=2,values_only=True):
        if not any(row): continue
        def v(n): return str(row[ci[n]]).strip() if n in ci and row[ci[n]] is not None else ''
        inv=v("Инвентарный номер") or next_no(s)
        if s.scalar(select(Asset).where(Asset.inventory_no==inv)): continue
        cn,en,wp=v("Компания"),v("Сотрудник"),v("Рабочее место"); cid=company_map.get(cn)
        dn=v("Подразделение (legacy)") or v("Подразделение"); did=dep_map.get((cid,dn))
        site_name=v("Площадка"); org_name=v("Отдел")
        site_id=s.scalar(select(Site.id).where(Site.name==site_name)) if site_name else None
        org_id=s.scalar(select(OrgUnit.id).where(OrgUnit.company_id==cid,OrgUnit.name==org_name)) if cid and org_name else None
        rn,rk=v("Серверная"),v("Стойка")
        def iv(n):
            try: return int(float(v(n))) if v(n) else None
            except: return None
        a=Asset(inventory_no=inv,category=v("Категория") or "Другое",manufacturer=v("Производитель") or None,model=v("Модель") or None,serial_no=v("Серийный номер") or None,status=v("Статус") or "В эксплуатации",notes=v("Комментарий") or None,company_id=cid,department_id=did,site_id=site_id,org_unit_id=org_id,employee_id=emp_map.get(en),workplace_id=wp_map.get(wp),server_room_id=room_map.get(rn),rack_id=rack_map.get(rk),rack_unit=iv("Позиция U"),device_height_u=iv("Высота U"),server_kind=v("Тип сервера") or None,primary_ip=v("Основной IP") or None,management_ip=v("Management IP") or None,os_name=v("ОС") or None,hypervisor=v("Гипервизор") or None,cluster_name=v("Кластер") or None,purpose=v("Назначение") or None);s.add(a);s.flush();s.add(AuditLog(asset_id=a.id,action="Импорт Excel",details=f"Добавлено {inv}"));count+=1
    s.flush(); rr,ci=rows("Комплектация")
    for row in rr:
        def v(n): return str(row[ci[n]]).strip() if n in ci and row[ci[n]] is not None else ''
        inv,typ=v("Инвентарный номер"),v("Тип компонента"); a=s.scalar(select(Asset).where(Asset.inventory_no==inv))
        if a and typ: s.add(Component(asset_id=a.id,component_type=typ,slot=v("Слот/порт") or None,manufacturer=v("Производитель") or None,model=v("Модель") or None,serial_no=v("Серийный номер") or None,specification=v("Характеристика") or None,notes=v("Комментарий") or None));components+=1
    # Печатающая техника
    rr,pi=rows("Печатающая техника")
    for row in rr:
        def pv(n): return str(row[pi[n]]).strip() if n in pi and row[pi[n]] is not None else ''
        a=s.scalar(select(Asset).where(Asset.inventory_no==pv("Инвентарный номер")))
        if a and _print_asset(a):
            p=s.scalar(select(PrintDeviceProfile).where(PrintDeviceProfile.asset_id==a.id)) or PrintDeviceProfile(asset_id=a.id)
            p.technology=pv("Технология") or None;p.color_mode=pv("Цветность") or None;p.max_format=pv("Макс. формат") or None;p.connection_type=pv("Подключение") or None;p.network_name=pv("Сетевое имя") or None;p.ip_address=pv("IP") or None;p.notes=pv("Комментарий") or None;s.add(p)
    rr,si=rows("Расходные материалы")
    for row in rr:
        def sv(n): return str(row[si[n]]).strip() if n in si and row[si[n]] is not None else ''
        name=sv("Наименование")
        if not name: continue
        try: qty=int(float(sv("Остаток") or 0)); minq=int(float(sv("Минимальный остаток") or 0))
        except: qty=0;minq=0
        x=s.scalar(select(Consumable).where(Consumable.name==name,Consumable.model==(sv("Модель") or None)))
        if not x:
            x=Consumable(name=name,consumable_type=sv("Тип") or "Картридж",manufacturer=sv("Производитель") or None,model=sv("Модель") or None,color=sv("Цвет") or None,sku=sv("Артикул") or None,resource=sv("Ресурс") or None,quantity=qty,min_quantity=minq,unit=sv("Ед. изм.") or "шт.",notes=sv("Комментарий") or None);s.add(x);s.flush()
        for inv in [z.strip() for z in sv("Совместимое оборудование").split(',') if z.strip()]:
            a=s.scalar(select(Asset).where(Asset.inventory_no==inv))
            if a and _print_asset(a) and not s.scalar(select(ConsumableCompatibility).where(ConsumableCompatibility.consumable_id==x.id,ConsumableCompatibility.asset_id==a.id)): s.add(ConsumableCompatibility(consumable_id=x.id,asset_id=a.id))
    # Программное обеспечение: импорт из человекочитаемого листа экспорта.
    software_count=0; installation_count=0
    rr,soi=rows("Программное обеспечение")
    software_map={(x.name.strip().lower(),(x.version or '').strip().lower()):x.id for x in s.scalars(select(Software)).all()}
    for row in rr:
        def sov(n): return str(row[soi[n]]).strip() if n in soi and row[soi[n]] is not None else ''
        name=sov("Программа"); version=sov("Версия"); inv=sov("Инвентарный номер")
        if not name or not inv: continue
        a=s.scalar(select(Asset).where(Asset.inventory_no==inv))
        if not a: continue
        key=(name.lower(),version.lower())
        sw_id=software_map.get(key)
        if not sw_id:
            sw=Software(name=name,vendor=sov("Производитель ПО") or None,version=version or None,license_type=sov("Лицензия") or None)
            s.add(sw);s.flush();sw_id=sw.id;software_map[key]=sw_id;software_count+=1
        emp_name=sov("Сотрудник")
        emp_id=emp_map.get(emp_name) if emp_name else a.employee_id
        raw_date=row[soi["Дата установки"]] if "Дата установки" in soi else None
        installed=raw_date.date() if isinstance(raw_date,datetime) else raw_date if isinstance(raw_date,date) else None
        if not installed and raw_date:
            try: installed=datetime.strptime(str(raw_date)[:10],"%Y-%m-%d").date()
            except: installed=date.today()
        installed=installed or date.today()
        exists=s.scalar(select(SoftwareInstallation).where(SoftwareInstallation.software_id==sw_id,SoftwareInstallation.asset_id==a.id,SoftwareInstallation.installed_at==installed))
        if not exists:
            s.add(SoftwareInstallation(software_id=sw_id,asset_id=a.id,installed_for_employee_id=emp_id,installed_at=installed,environment=sov("Среда") or None,license_info=sov("Лицензия") or None,notes=sov("Примечание") or None));installation_count+=1
    s.commit(); return {"imported":count,"components":components,"software":software_count,"software_installations":installation_count,"companies":len(company_map),"departments":len(dep_map),"employees":len(emp_map)}

@app.post("/api/inventories")
def create_inventory(d:InventoryIn,s:Session=Depends(db)):
    x=InventorySession(name=d.name,location_id=d.location_id); s.add(x); s.commit(); s.refresh(x); return {"id":x.id,"name":x.name,"status":x.status}
@app.get("/api/inventories")
def inventories(s:Session=Depends(db)):
    xs=s.scalars(select(InventorySession).order_by(InventorySession.id.desc())).all(); return [{"id":x.id,"name":x.name,"status":x.status,"location_id":x.location_id,"created_at":x.created_at.isoformat()} for x in xs]
@app.put("/api/inventories/{sid}")
def edit_inventory(sid:int,d:InventoryIn,s:Session=Depends(db), actor: AppUser = Depends(require_main_admin)):
    x=s.get(InventorySession,sid)
    if not x: raise HTTPException(404,"Инвентаризация не найдена")
    x.name=d.name; x.location_id=d.location_id; s.add(AuditLog(action="Инвентаризация изменена",details=f"#{sid} {x.name}; {actor.username}")); s.commit(); return {"ok":True}
@app.delete("/api/inventories/{sid}")
def delete_inventory(sid:int,s:Session=Depends(db), actor: AppUser = Depends(require_main_admin)):
    x=s.get(InventorySession,sid)
    if not x: raise HTTPException(404,"Инвентаризация не найдена")
    name=x.name
    for sc in s.scalars(select(InventoryScan).where(InventoryScan.session_id==sid)).all(): s.delete(sc)
    s.delete(x); s.add(AuditLog(action="Инвентаризация удалена",details=f"#{sid} {name}; {actor.username}")); s.commit(); return {"ok":True}
@app.post("/api/inventories/{sid}/scan")
def scan(sid:int,d:ScanIn,s:Session=Depends(db)):
    inv=s.get(InventorySession,sid)
    if not inv: raise HTTPException(404,"Инвентаризация не найдена")
    a=s.scalar(select(Asset).where((Asset.inventory_no==d.code)|(Asset.serial_no==d.code)))
    if not a: raise HTTPException(404,"Код не найден")
    exists=s.scalar(select(InventoryScan).where(InventoryScan.session_id==sid,InventoryScan.asset_id==a.id))
    if not exists:
        result="Найдено" if not inv.location_id or a.location_id==inv.location_id else "Не на своём месте"
        s.add(InventoryScan(session_id=sid,asset_id=a.id,result=result)); s.add(AuditLog(asset_id=a.id,action="Инвентаризация",details=f"{inv.name}: {result}")); s.commit()
    return {"asset":asset_dict(a),"result": "Уже отсканировано" if exists else result}
@app.get("/api/inventories/{sid}/results")
def inventory_results(sid:int,s:Session=Depends(db)):
    inv=s.get(InventorySession,sid)
    if not inv: raise HTTPException(404)
    expected=s.scalars(select(Asset).where(Asset.location_id==inv.location_id) if inv.location_id else select(Asset)).all()
    scans=s.execute(select(InventoryScan.asset_id,InventoryScan.result).where(InventoryScan.session_id==sid)).all(); found={x[0]:x[1] for x in scans}
    return {"expected":len(expected),"scanned":len(found),"missing":[asset_dict(a) for a in expected if a.id not in found],"found":[{"asset":asset_dict(a),"result":found[a.id]} for a in expected if a.id in found]}

def _safe_extract_update(raw: bytes):
    if len(raw) > MAX_UPDATE_SIZE:
        raise HTTPException(413, "Пакет обновления слишком большой")
    tmp = Path(tempfile.mkdtemp(prefix="itinv_update_"))
    try:
        zpath = tmp / "package.zip"
        zpath.write_bytes(raw)
        with zipfile.ZipFile(zpath) as z:
            names = z.namelist()
            if len(names) > 500 or sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024:
                raise HTTPException(413, "Распакованный пакет обновления слишком большой")
            if "update.json" not in names:
                raise HTTPException(400, "В пакете отсутствует update.json")
            for name in names:
                pp = Path(name)
                if pp.is_absolute() or ".." in pp.parts:
                    raise HTTPException(400, "Некорректный путь внутри ZIP")
                if name != "update.json" and name != "migration.sql" and not name.startswith("app/"):
                    raise HTTPException(400, f"Недопустимый файл в пакете: {name}")
            z.extractall(tmp / "content")
        manifest = json.loads((tmp / "content" / "update.json").read_text(encoding="utf-8"))
        target = str(manifest.get("version", "")).strip()
        if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][A-Za-z0-9._-]+)?", target):
            raise HTTPException(400, "Некорректная версия в update.json")
        if version_key(target) <= version_key(current_version()):
            raise HTTPException(409, f"Версия {target} не новее текущей {current_version()}")
        if not (tmp / "content" / "app").is_dir():
            raise HTTPException(400, "В пакете отсутствует каталог app")

        edition = str(manifest.get("edition", "")).strip()
        current_edition = str(os.getenv("ITCONTROL_EDITION", "")).strip()
        if edition and current_edition and edition.lower() != current_edition.lower():
            raise HTTPException(409, f"Пакет предназначен для редакции {edition}, установлена {current_edition}")

        allowed_from = manifest.get("from_versions")
        if isinstance(allowed_from, list) and allowed_from and "*" not in allowed_from:
            if current_version() not in [str(x) for x in allowed_from]:
                raise HTTPException(409, f"Пакет нельзя установить поверх версии {current_version()}")

        hashes = manifest.get("sha256")
        if hashes is not None:
            if not isinstance(hashes, dict) or not hashes:
                raise HTTPException(400, "Некорректный раздел sha256 в update.json")
            for rel, expected in hashes.items():
                rel = str(rel)
                pp = Path(rel)
                if pp.is_absolute() or ".." in pp.parts or rel == "update.json":
                    raise HTTPException(400, f"Некорректный путь контрольной суммы: {rel}")
                target_file = tmp / "content" / rel
                if not target_file.is_file():
                    raise HTTPException(400, f"Файл из sha256 отсутствует: {rel}")
                actual = hashlib.sha256(target_file.read_bytes()).hexdigest()
                if actual.lower() != str(expected).strip().lower():
                    raise HTTPException(400, f"Контрольная сумма не совпадает: {rel}")

        return tmp, manifest
    except Exception:
        if tmp.exists(): shutil.rmtree(tmp, ignore_errors=True)
        raise

def _postgres_cli_config():
    """Return PostgreSQL CLI connection settings from the same DATABASE_URL used by SQLAlchemy.

    Environment variables remain supported as a fallback, but DATABASE_URL is authoritative so
    backup/update/restore cannot silently use credentials different from the running application.
    """
    cfg = {
        "host": os.getenv("POSTGRES_HOST", "db"),
        "port": str(os.getenv("POSTGRES_PORT", "5432")),
        "user": os.getenv("POSTGRES_USER", "inventory"),
        "password": os.getenv("POSTGRES_PASSWORD") or os.getenv("PGPASSWORD") or "inventory",
        "database": os.getenv("POSTGRES_DB", "inventory"),
    }
    if DATABASE_URL.startswith("postgresql"):
        try:
            u = urllib.parse.urlsplit(DATABASE_URL)
            if u.hostname:
                cfg["host"] = u.hostname
            if u.port:
                cfg["port"] = str(u.port)
            if u.username is not None:
                cfg["user"] = urllib.parse.unquote(u.username)
            if u.password is not None:
                cfg["password"] = urllib.parse.unquote(u.password)
            if u.path and u.path != "/":
                cfg["database"] = urllib.parse.unquote(u.path.lstrip("/"))
        except Exception:
            pass
    return cfg

def _db_env():
    cfg = _postgres_cli_config()
    return {**os.environ, "PGPASSWORD": cfg["password"]}

def _postgres_cli_base(tool: str):
    cfg = _postgres_cli_config()
    return [tool, "-h", cfg["host"], "-p", cfg["port"], "-U", cfg["user"], "-d", cfg["database"]]

def _major_version_from_text(raw: str) -> Optional[int]:
    m=re.search(r"(\d+)(?:\.\d+)?", raw or "")
    return int(m.group(1)) if m else None

def _postgres_versions():
    env=_db_env()
    server=subprocess.run(
        _postgres_cli_base("psql") + ["-Atc","SHOW server_version;"],
        env=env,capture_output=True,text=True,timeout=30
    )
    dump=subprocess.run(["pg_dump","--version"],capture_output=True,text=True,timeout=15)
    psql=subprocess.run(["psql","--version"],capture_output=True,text=True,timeout=15)
    if server.returncode!=0:
        raise RuntimeError("Не удалось определить версию PostgreSQL сервера: "+(server.stderr or server.stdout))
    if dump.returncode!=0 or psql.returncode!=0:
        raise RuntimeError("Не удалось определить версии pg_dump/psql")
    return {
        "server":(server.stdout or "").strip(),
        "pg_dump":(dump.stdout or "").strip(),
        "psql":(psql.stdout or "").strip(),
        "server_major":_major_version_from_text(server.stdout),
        "pg_dump_major":_major_version_from_text(dump.stdout),
        "psql_major":_major_version_from_text(psql.stdout),
    }

def _assert_pg_compatibility():
    v=_postgres_versions()
    if not v["server_major"] or not v["pg_dump_major"] or not v["psql_major"]:
        raise RuntimeError("Не удалось определить major-версии PostgreSQL")
    if v["pg_dump_major"] != v["server_major"] or v["psql_major"] != v["server_major"]:
        raise RuntimeError(
            f"Несовместимые PostgreSQL tools: сервер {v['server']}; "
            f"{v['pg_dump']}; {v['psql']}. Требуется одна major-версия."
        )
    return v

def _sanitize_legacy_dump(src: Path) -> tuple[Path,bool]:
    """Creates a temporary restore-safe copy for known forward-only SET statements."""
    raw=src.read_text(encoding="utf-8",errors="replace")
    cleaned=re.sub(r"(?mi)^SET\s+transaction_timeout\s*=\s*[^;]+;\s*$","",raw)
    # Future-proof a small class of SET variables not supported by older target servers:
    # only sanitize configuration SET lines that the live server explicitly rejects.
    changed=(cleaned!=raw)
    if not changed:
        return src,False
    tmp=src.with_name(src.name+".compat.sql")
    tmp.write_text(cleaned,encoding="utf-8")
    return tmp,True

def _backup_database(dest: Path):
    versions=_assert_pg_compatibility()
    cmd = _postgres_cli_base("pg_dump") + ["--clean", "--if-exists", "--no-owner",
           "--no-privileges", "-f", str(dest)]
    r = subprocess.run(cmd, env=_db_env(), capture_output=True, text=True, timeout=180)
    if r.returncode != 0:
        raise RuntimeError("Не удалось создать резервную копию БД: " + (r.stderr or r.stdout))
    meta=dest.with_suffix(dest.suffix+".meta.json")
    meta.write_text(json.dumps(versions,ensure_ascii=False,indent=2),encoding="utf-8")

def _restore_database(src: Path):
    restore_src,compat_copy=_sanitize_legacy_dump(src)
    try:
        cmd = _postgres_cli_base("psql") + ["-v", "ON_ERROR_STOP=1", "-f", str(restore_src)]
        r = subprocess.run(cmd, env=_db_env(), capture_output=True, text=True, timeout=300)
        if r.returncode != 0:
            raise RuntimeError("Не удалось восстановить БД: " + (r.stderr or r.stdout))
    finally:
        if compat_copy:
            try: restore_src.unlink()
            except Exception: pass

def _validate_staged_app(staged: Path):
    required = ("main.py", "community_entry.py")
    missing = [name for name in required if not (staged / name).is_file()]
    if missing:
        raise RuntimeError("Пакет обновления неполный: отсутствуют " + ", ".join(missing))
    r = subprocess.run(
        ["python", "-m", "compileall", "-q", str(staged)],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if r.returncode != 0:
        raise RuntimeError("Python-проверка пакета обновления не пройдена: " + (r.stderr or r.stdout))


def _restart_later():
    # Docker restart: unless-stopped will start this container again.
    threading.Timer(1.2, lambda: os._exit(0)).start()

def _password_hash(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 120000).hex()
    return f"pbkdf2_sha256$120000${salt}${digest}"

def _password_verify(password: str, stored: Optional[str]) -> bool:
    if not stored:
        return False
    try:
        scheme, rounds, salt, expected = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(rounds)).hex()
        return secrets.compare_digest(digest, expected)
    except Exception:
        return False


def _user_dict(u: AppUser, s: Optional[Session] = None):
    org = s.get(Organization, u.organization_id) if s is not None and u.organization_id else None
    return {
        "id": u.id, "username": u.username, "display_name": u.display_name,
        "role": u.role, "is_active": bool(u.is_active), "organization_id": u.organization_id,
        "organization": org.name if org else ("Все организации" if u.role == "Главный администратор" else None),
        "employee_id": u.employee_id, "employee": u.employee.name if u.employee else None,
        "password_configured": bool(u.password_hash),
        "created_at": u.created_at.isoformat() if u.created_at else None,
        "updated_at": u.updated_at.isoformat() if u.updated_at else None,
    }

USER_ROLES = ("Главный администратор", "Администратор организации", "ИТ-специалист", "Пользователь")
LEGACY_USER_ROLES = ("Администратор", "Сотрудник")

def _validate_user_payload(data: UserIn, s: Session):
    data.username = data.username.strip()
    data.display_name = data.display_name.strip()
    if not data.username or not data.display_name:
        raise HTTPException(400, "Логин и имя пользователя обязательны")
    if data.role not in USER_ROLES + LEGACY_USER_ROLES:
        raise HTTPException(400, "Недопустимая роль")
    if data.role in ("Главный администратор", "Администратор организации", "Администратор") and not data.username.lower().endswith("-adm"):
        raise HTTPException(400, "Логин администратора должен заканчиваться на -adm")
    if data.role != "Главный администратор":
        if not data.organization_id:
            raise HTTPException(400, "Для пользователя необходимо выбрать организацию")
        org=s.get(Organization, data.organization_id)
        if not org or not org.is_active:
            raise HTTPException(400, "Выбранная организация недоступна")
    if data.employee_id:
        emp=s.get(Employee, data.employee_id)
        if not emp:
            raise HTTPException(400, "Связанный сотрудник не найден")
        if data.role != "Главный администратор" and emp.organization_id != data.organization_id:
            raise HTTPException(400, "Сотрудник относится к другой организации")

@app.get("/api/users")
def users_list(s: Session = Depends(db), actor: Optional[AppUser] = Depends(current_actor)):
    stmt=select(AppUser).order_by(AppUser.id)
    if actor and actor.role != "Главный администратор" and actor.organization_id:
        stmt=stmt.where((AppUser.organization_id == actor.organization_id) | (AppUser.id == actor.id))
    return [_user_dict(x, s) for x in s.scalars(stmt).all()]

@app.post("/api/users")
def users_create(data: UserIn, s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    _validate_user_payload(data, s)
    if s.scalar(select(AppUser).where(func.lower(AppUser.username) == data.username.lower())):
        raise HTTPException(409, "Пользователь с таким логином уже существует")
    if data.role == "Главный администратор" and s.scalar(select(AppUser).where(AppUser.role=="Главный администратор")):
        raise HTTPException(400, "Главный администратор системы уже существует")
    u = AppUser(username=data.username, display_name=data.display_name, role=data.role,
                organization_id=(None if data.role == "Главный администратор" else data.organization_id),
                is_active=1 if data.is_active else 0, employee_id=data.employee_id)
    if data.password:
        if len(data.password) < 12: raise HTTPException(400, "Пароль должен быть не короче 12 символов")
        u.password_hash = _password_hash(data.password)
    elif data.role != "Главный администратор":
        raise HTTPException(400, "Для нового пользователя задайте пароль не короче 12 символов")
    s.add(u); s.flush()
    s.add(AuditLog(action="Пользователь создан", details=f"{u.display_name} ({u.username}), роль: {u.role}, организация: {u.organization_id or 'все'}"))
    s.commit(); s.refresh(u)
    return _user_dict(u, s)

@app.put("/api/users/{user_id}")
def users_update(user_id: int, data: UserIn, s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    _validate_user_payload(data, s)
    u = s.get(AppUser, user_id)
    if not u: raise HTTPException(404, "Пользователь не найден")
    duplicate = s.scalar(select(AppUser).where(func.lower(AppUser.username) == data.username.lower(), AppUser.id != user_id))
    if duplicate: raise HTTPException(409, "Пользователь с таким логином уже существует")
    if u.role == "Главный администратор" and data.role != "Главный администратор":
        raise HTTPException(400, "Нельзя понизить Главного администратора системы")
    if u.role == "Главный администратор" and not data.is_active:
        raise HTTPException(400, "Нельзя отключить Главного администратора системы")
    if data.role == "Главный администратор" and u.role != "Главный администратор":
        raise HTTPException(400, "Назначение второго Главного администратора запрещено")
    before = f"{u.display_name} ({u.username}), {u.role}, организация {u.organization_id or 'все'}, {'активен' if u.is_active else 'отключён'}"
    u.username=data.username; u.display_name=data.display_name; u.role=data.role
    u.organization_id=None if data.role == "Главный администратор" else data.organization_id
    if not data.is_active or data.password or u.role != data.role or u.organization_id != data.organization_id:
        from app.security import AuthSession
        s.query(AuthSession).filter_by(user_id=u.id).delete(synchronize_session=False)
    u.is_active=1 if data.is_active else 0; u.employee_id=data.employee_id
    if data.password:
        if len(data.password) < 12: raise HTTPException(400, "Пароль должен быть не короче 12 символов")
        u.password_hash = _password_hash(data.password)
    s.add(AuditLog(action="Пользователь изменён", details=f"{before} → {u.display_name} ({u.username}), {u.role}, организация {u.organization_id or 'все'}, {'активен' if u.is_active else 'отключён'}"))
    s.commit(); s.refresh(u)
    return _user_dict(u, s)

@app.delete("/api/users/{user_id}")
def users_delete(user_id: int, s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    u=s.get(AppUser,user_id)
    if not u: raise HTTPException(404,"Пользователь не найден")
    if u.role == "Главный администратор": raise HTTPException(400,"Главного администратора системы нельзя удалить")
    details=f"{u.display_name} ({u.username}), роль: {u.role}, организация: {u.organization_id or 'все'}"
    # Keep historical tickets readable even if an assignee account is removed.
    for t in s.scalars(select(HelpdeskTicket).where(HelpdeskTicket.assignee_id==u.id)).all():
        t.assignee_id=None
    from app.security import AuthSession
    s.query(AuthSession).filter_by(user_id=u.id).delete(synchronize_session=False)
    s.delete(u); s.add(AuditLog(action="Пользователь удалён",details=details)); s.commit()
    return {"ok":True}


class OrgResetIn(BaseModel):
    clear_assets: bool = True
    clear_employees: bool = False
    delete_empty_sites: bool = False
    delete_empty_org_units: bool = False

class BulkOrgIn(BaseModel):
    asset_ids: list[int]
    company_id: Optional[int] = None
    site_id: Optional[int] = None
    org_unit_id: Optional[int] = None

@app.get("/api/admin/org-reset/preview")
def org_reset_preview(s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    return {
        "assets_total": s.scalar(select(func.count()).select_from(Asset)) or 0,
        "assets_with_site": s.scalar(select(func.count()).select_from(Asset).where(Asset.site_id.is_not(None))) or 0,
        "assets_with_org_unit": s.scalar(select(func.count()).select_from(Asset).where(Asset.org_unit_id.is_not(None))) or 0,
        "employees_total": s.scalar(select(func.count()).select_from(Employee)) or 0,
        "employees_with_site": s.scalar(select(func.count()).select_from(Employee).where(Employee.site_id.is_not(None))) or 0,
        "employees_with_org_unit": s.scalar(select(func.count()).select_from(Employee).where(Employee.org_unit_id.is_not(None))) or 0,
        "sites": s.scalar(select(func.count()).select_from(Site)) or 0,
        "org_units": s.scalar(select(func.count()).select_from(OrgUnit)) or 0,
    }

@app.post("/api/admin/org-reset")
def org_reset(data:OrgResetIn,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    stamp=datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup=BACKUP_DIR/f"{stamp}_before_org_reset"
    backup.mkdir(parents=True,exist_ok=False)
    try:
        _backup_database(backup/"database.sql")
    except Exception:
        shutil.rmtree(backup,ignore_errors=True)
        raise
    changed_assets=changed_employees=deleted_sites=deleted_org_units=0
    if data.clear_assets:
        xs=s.scalars(select(Asset).where((Asset.site_id.is_not(None)) | (Asset.org_unit_id.is_not(None)))).all()
        changed_assets=len(xs)
        for x in xs:
            x.site_id=None; x.org_unit_id=None
    if data.clear_employees:
        xs=s.scalars(select(Employee).where((Employee.site_id.is_not(None)) | (Employee.org_unit_id.is_not(None)))).all()
        changed_employees=len(xs)
        for x in xs:
            x.site_id=None; x.org_unit_id=None
    s.flush()
    if data.delete_empty_org_units:
        for x in s.scalars(select(OrgUnit)).all():
            ec=s.scalar(select(func.count()).select_from(Employee).where(Employee.org_unit_id==x.id)) or 0
            ac=s.scalar(select(func.count()).select_from(Asset).where(Asset.org_unit_id==x.id)) or 0
            if not ec and not ac: s.delete(x);deleted_org_units+=1
    if data.delete_empty_sites:
        for x in s.scalars(select(Site)).all():
            ec=s.scalar(select(func.count()).select_from(Employee).where(Employee.site_id==x.id)) or 0
            ac=s.scalar(select(func.count()).select_from(Asset).where(Asset.site_id==x.id)) or 0
            if not ec and not ac: s.delete(x);deleted_sites+=1
    s.add(AuditLog(action="Сброс оргпривязок",details=f"{actor.username}; оборудование: {changed_assets}; сотрудники: {changed_employees}; удалено пустых площадок: {deleted_sites}; отделов: {deleted_org_units}; backup: {backup.name}"))
    s.commit()
    return {"ok":True,"assets_cleared":changed_assets,"employees_cleared":changed_employees,"sites_deleted":deleted_sites,"org_units_deleted":deleted_org_units,"backup":backup.name}

@app.post("/api/assets/bulk-org")
def bulk_asset_org(data:BulkOrgIn,s:Session=Depends(db)):
    if not data.asset_ids: raise HTTPException(400,"Не выбрано оборудование")
    if data.company_id and data.org_unit_id:
        ou=s.get(OrgUnit,data.org_unit_id)
        if not ou or ou.company_id!=data.company_id: raise HTTPException(400,"Выбранный отдел не относится к выбранной компании")
    changed=0
    for asset_id in data.asset_ids:
        a=s.get(Asset,asset_id)
        if not a: continue
        before=(a.company_id,a.site_id,a.org_unit_id)
        a.company_id=data.company_id; a.site_id=data.site_id; a.org_unit_id=data.org_unit_id
        if before!=(a.company_id,a.site_id,a.org_unit_id):
            changed+=1
            s.add(AuditLog(asset_id=a.id,action="Массовая оргпривязка",details=f"company={data.company_id or '—'}; site={data.site_id or '—'}; org_unit={data.org_unit_id or '—'}"))
    s.commit()
    return {"ok":True,"changed":changed}


class LegacyOrgMapIn(BaseModel):
    department_id: int
    target: str  # "site" or "org_unit"

@app.get("/api/admin/legacy-org")
def legacy_org_preview(s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    out=[]
    for d in s.scalars(select(Department).order_by(Department.company_id,Department.name)).all():
        out.append({
            "id":d.id,"name":d.name,"company_id":d.company_id,
            "company":d.company.name if d.company else None,
            "assets":s.scalar(select(func.count()).select_from(Asset).where(Asset.department_id==d.id)) or 0,
            "employees":s.scalar(select(func.count()).select_from(Employee).where(Employee.department_id==d.id)) or 0,
            "server_rooms":s.scalar(select(func.count()).select_from(ServerRoom).where(ServerRoom.department_id==d.id)) or 0,
        })
    return out

@app.post("/api/admin/legacy-org/map")
def legacy_org_map(data:LegacyOrgMapIn,s:Session=Depends(db),actor:AppUser=Depends(require_main_admin)):
    d=s.get(Department,data.department_id)
    if not d: raise HTTPException(404,"Старое значение не найдено")
    if data.target not in ("site","org_unit"): raise HTTPException(400,"Выберите Площадку или Отдел")
    assets=s.scalars(select(Asset).where(Asset.department_id==d.id)).all()
    employees=s.scalars(select(Employee).where(Employee.department_id==d.id)).all()
    rooms=s.scalars(select(ServerRoom).where(ServerRoom.department_id==d.id)).all()
    if data.target=="site":
        target=s.scalar(select(Site).where(func.lower(Site.name)==d.name.lower()))
        if not target:
            target=Site(name=d.name,site_type="Другое");s.add(target);s.flush()
        for x in assets:
            if not x.site_id: x.site_id=target.id
        for x in employees:
            if not x.site_id: x.site_id=target.id
        for x in rooms:
            if not x.site_id: x.site_id=target.id
        target_label=f"Площадка «{target.name}»"
    else:
        target=s.scalar(select(OrgUnit).where(OrgUnit.company_id==d.company_id,func.lower(OrgUnit.name)==d.name.lower()))
        if not target:
            target=OrgUnit(company_id=d.company_id,name=d.name);s.add(target);s.flush()
        for x in assets:
            if not x.org_unit_id: x.org_unit_id=target.id
        for x in employees:
            if not x.org_unit_id: x.org_unit_id=target.id
        for x in rooms:
            if not x.org_unit_id: x.org_unit_id=target.id
        target_label=f"Отдел «{target.name}»"
    s.add(AuditLog(action="Миграция старой оргструктуры",details=f"{d.company.name if d.company else ''} / {d.name} → {target_label}; {actor.username}"))
    s.commit()
    return {"ok":True,"target":target_label,"assets":len(assets),"employees":len(employees),"server_rooms":len(rooms)}

@app.get("/api/system/postgres")
def postgres_compatibility(actor: AppUser = Depends(require_main_admin)):
    try:
        v=_postgres_versions()
        v["compatible"]=bool(v["server_major"] and v["pg_dump_major"]==v["server_major"] and v["psql_major"]==v["server_major"])
        return v
    except Exception as e:
        return {"compatible":False,"error":str(e)}

@app.get("/api/system/version")
def system_version():
    return {"version": current_version(), "update_mode": "local-package"}

@app.get("/api/updates")
def update_history(s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    xs = s.scalars(select(UpdateRecord).order_by(UpdateRecord.id.desc()).limit(100)).all()
    return [{"id":x.id,"from_version":x.from_version,"to_version":x.to_version,"status":x.status,"package_name":x.package_name,"details":x.details,"created_at":x.created_at.isoformat()} for x in xs]

@app.post("/api/updates/check")
def check_update(file: UploadFile = File(...), actor: AppUser = Depends(require_main_admin)):
    raw = file.file.read()
    tmp, manifest = _safe_extract_update(raw)
    try:
        return {"ok": True, "current_version": current_version(), "target_version": manifest["version"], "name": manifest.get("name", "ИТ.Контроль update"), "notes": manifest.get("notes", ""), "has_migration": (tmp / "content" / "migration.sql").exists()}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

@app.post("/api/updates/install")
def install_update(file: UploadFile = File(...), s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    raw = file.file.read()
    tmp, manifest = _safe_extract_update(raw)
    old_ver = current_version(); new_ver = manifest["version"]
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup = BACKUP_DIR / f"{stamp}_{old_ver}_to_{new_ver}"
    backup.mkdir(parents=True, exist_ok=False)
    try:
        staged = tmp / "content" / "app"
        _validate_staged_app(staged)
        shutil.copytree(APP_DIR, backup / "app")
        _backup_database(backup / "database.sql")
        shutil.copy2(tmp / "package.zip", backup / "package.zip")
        migration = tmp / "content" / "migration.sql"
        if migration.exists():
            cmd=_postgres_cli_base("psql") + ["-v","ON_ERROR_STOP=1","--single-transaction","-f",str(migration)]
            r=subprocess.run(cmd,env=_db_env(),capture_output=True,text=True,timeout=180)
            if r.returncode != 0: raise RuntimeError("Ошибка миграции: "+(r.stderr or r.stdout))
        # Replace only application files. Database lives outside APP_DIR.
        for child in list(APP_DIR.iterdir()):
            if child.is_dir(): shutil.rmtree(child)
            else: child.unlink()
        for child in staged.iterdir():
            dest = APP_DIR / child.name
            if child.is_dir(): shutil.copytree(child, dest)
            else: shutil.copy2(child, dest)
        VERSION_FILE.write_text(new_ver + "\n", encoding="utf-8")
        rec=UpdateRecord(from_version=old_ver,to_version=new_ver,status="Установлено",package_name=file.filename,backup_path=str(backup),details=str(manifest.get("notes", "")))
        s.add(rec); s.commit(); s.refresh(rec)
        _restart_later()
        return {"ok":True,"from_version":old_ver,"to_version":new_ver,"message":"Обновление установлено. Приложение перезапускается."}
    except Exception as e:
        try:
            if (backup / "app").exists():
                for child in list(APP_DIR.iterdir()):
                    if child.is_dir(): shutil.rmtree(child)
                    else: child.unlink()
                for child in (backup / "app").iterdir():
                    dest=APP_DIR/child.name
                    if child.is_dir(): shutil.copytree(child,dest)
                    else: shutil.copy2(child,dest)
            if (backup / "database.sql").exists(): _restore_database(backup / "database.sql")
        except Exception as rollback_error:
            raise HTTPException(500, f"Ошибка установки: {e}. Автооткат также завершился ошибкой: {rollback_error}")
        raise HTTPException(500, f"Обновление не установлено, выполнен откат: {e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

@app.post("/api/updates/{record_id}/rollback")
def rollback_update(record_id: int, s: Session = Depends(db), actor: AppUser = Depends(require_main_admin)):
    rec=s.get(UpdateRecord,record_id)
    if not rec or not rec.backup_path: raise HTTPException(404,"Резервная копия не найдена")
    backup=Path(rec.backup_path).resolve()
    try:
        backup.relative_to(BACKUP_DIR)
    except ValueError:
        raise HTTPException(400,"Некорректный путь резервной копии")
    if not (backup/"app").exists() or not (backup/"database.sql").exists(): raise HTTPException(404,"Резервная копия неполная")
    safety=BACKUP_DIR / f"rollback_safety_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{current_version()}"
    safety.mkdir(parents=True,exist_ok=False)
    try:
        shutil.copytree(APP_DIR,safety/"app"); _backup_database(safety/"database.sql")
        for child in list(APP_DIR.iterdir()):
            if child.is_dir(): shutil.rmtree(child)
            else: child.unlink()
        for child in (backup/"app").iterdir():
            dest=APP_DIR/child.name
            if child.is_dir(): shutil.copytree(child,dest)
            else: shutil.copy2(child,dest)
        _restore_database(backup/"database.sql")
        # Update history may have been reverted with DB restore; add a new record if table exists.
        Base.metadata.create_all(engine)
        with SessionLocal() as s2:
            s2.add(UpdateRecord(from_version=rec.to_version,to_version=rec.from_version,status="Откат",package_name=rec.package_name,backup_path=str(safety),details=f"Откат обновления #{record_id}")); s2.commit()
        _restart_later()
        return {"ok":True,"version":rec.from_version,"message":"Откат выполнен. Приложение перезапускается."}
    except Exception as e:
        raise HTTPException(500,f"Не удалось выполнить откат: {e}")



def _migration_decode(value):
    if not isinstance(value, dict) or "__type__" not in value:
        return value
    typ = value.get("__type__")
    raw = value.get("value")
    if typ == "datetime":
        try: return datetime.fromisoformat(raw.replace("Z", "+00:00")).replace(tzinfo=None)
        except Exception: return raw
    if typ == "date":
        try: return date.fromisoformat(raw)
        except Exception: return raw
    if typ == "bytes":
        try: return base64.b64decode(raw)
        except Exception: return None
    return raw

def _migration_limits():
    limits = {
        "archive_mb": DEFAULT_MIGRATION_ARCHIVE_MB,
        "unpacked_mb": DEFAULT_MIGRATION_UNPACKED_MB,
    }
    try:
        if MIGRATION_LIMITS_FILE.exists():
            saved = json.loads(MIGRATION_LIMITS_FILE.read_text(encoding="utf-8"))
            limits["archive_mb"] = int(saved.get("archive_mb", limits["archive_mb"]))
            limits["unpacked_mb"] = int(saved.get("unpacked_mb", limits["unpacked_mb"]))
    except Exception:
        pass
    limits["archive_mb"] = max(50, min(MIGRATION_HARD_ARCHIVE_MB, int(limits["archive_mb"])))
    limits["unpacked_mb"] = max(limits["archive_mb"], min(MIGRATION_HARD_UNPACKED_MB, int(limits["unpacked_mb"])))
    return limits

def _save_migration_limits(archive_mb: int, unpacked_mb: int):
    archive_mb = max(50, min(MIGRATION_HARD_ARCHIVE_MB, int(archive_mb)))
    unpacked_mb = max(archive_mb, min(MIGRATION_HARD_UNPACKED_MB, int(unpacked_mb)))
    payload = {"archive_mb": archive_mb, "unpacked_mb": unpacked_mb}
    tmp = MIGRATION_LIMITS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(MIGRATION_LIMITS_FILE)
    return payload

def _read_migration_package(raw: bytes):
    limits = _migration_limits()
    archive_limit = limits["archive_mb"] * 1024 * 1024
    unpacked_limit = limits["unpacked_mb"] * 1024 * 1024
    if len(raw) > archive_limit:
        raise HTTPException(
            413,
            f"Архив миграции слишком большой: {len(raw)/(1024*1024):.1f} МБ. "
            f"Текущий лимит — {limits['archive_mb']} МБ."
        )
    try:
        with zipfile.ZipFile(io.BytesIO(raw), "r") as z:
            infos = z.infolist()
            if len(infos) > MIGRATION_MAX_FILES:
                raise HTTPException(400, f"В архиве слишком много файлов: {len(infos)}")
            total_unpacked = sum(max(0, int(info.file_size)) for info in infos)
            if total_unpacked > unpacked_limit:
                raise HTTPException(
                    413,
                    f"Распакованный пакет слишком большой: {total_unpacked/(1024*1024):.1f} МБ. "
                    f"Текущий лимит — {limits['unpacked_mb']} МБ."
                )
            for info in infos:
                if info.file_size <= 0:
                    continue
                compressed = max(1, int(info.compress_size))
                ratio = info.file_size / compressed
                if ratio > MIGRATION_MAX_COMPRESSION_RATIO:
                    raise HTTPException(400, f"Подозрительно высокий коэффициент сжатия у файла {info.filename}")
            names = set(z.namelist())
            required = {"manifest.json", "schema.json", "data.json"}
            if not required.issubset(names):
                raise HTTPException(400, "Это не пакет миграции ИТ.Контроль")
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            schema = json.loads(z.read("schema.json").decode("utf-8"))
            data = json.loads(z.read("data.json").decode("utf-8"))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"Не удалось прочитать архив миграции: {e}")
    if manifest.get("format") != "itcontrol-migration" or int(manifest.get("format_version", 0)) != 1:
        raise HTTPException(400, "Неподдерживаемый формат миграции")
    return manifest, schema, data

def _migration_table_order(schema, data):
    # Build dependencies from both the exported 1.12 schema and the actual v2 metadata.
    # Some legacy exports do not describe every FK (notably server_rooms/racks), while v2 does.
    tables = [t for t in data.keys() if t in Base.metadata.tables and t != "organizations"]
    deps = {t:set() for t in tables}
    for t in tables:
        for _col,(rt,_rc) in _migration_fk_map(schema,t).items():
            if rt in deps and rt != t:
                deps[t].add(rt)
    out=[]; remaining=set(tables)
    while remaining:
        ready=sorted([t for t in remaining if not (deps[t] & remaining)])
        if not ready:
            # A real FK cycle cannot be solved by leaking old IDs. Keep a stable order here;
            # mapped_fk() below will stop with an explicit relation error if the dependency
            # has not been materialised yet.
            out.extend(sorted(remaining)); break
        out.extend(ready); remaining -= set(ready)
    return out

def _migration_row_index(data):
    return {
        table: {row.get("id"): row for row in rows if isinstance(row, dict) and row.get("id") is not None}
        for table, rows in data.items() if isinstance(rows, list)
    }

def _migration_fk_map(schema, table_name):
    out={}
    # First take relations explicitly exported by 1.12.
    for fk in (schema.get(table_name, {}).get("foreign_keys") or []):
        rt=fk.get("referred_table")
        referred_cols=fk.get("referred_columns") or ["id"]
        constrained=fk.get("constrained_columns") or []
        for i,c in enumerate(constrained):
            if rt:
                out[c]=(rt, referred_cols[i] if i < len(referred_cols) else "id")

    # Then complete the map from the current v2 SQLAlchemy metadata. This is critical for
    # legacy packages where a relation existed in data but was not emitted into schema.json.
    target=Base.metadata.tables.get(table_name)
    if target is not None:
        for col in target.c:
            if col.name == "organization_id":
                continue
            for fk in col.foreign_keys:
                try:
                    rt=fk.column.table.name
                    rc=fk.column.name
                except Exception:
                    continue
                if rt and rt != "organizations":
                    out.setdefault(col.name,(rt,rc))
    return out

def _migration_company_resolver(schema, data):
    """Resolve source company ownership without requiring every legacy row to have company_id.

    v1.12 contains legitimate rows (especially sites/locations/workplaces) whose owner can only
    be inferred from related business objects. Explicit company_id is authoritative. For rows
    without one, ownership is propagated across FK links between tenant-scoped legacy entities,
    in both directions, until the graph stabilizes. Shared legacy entities can therefore resolve
    to several source companies and will be cloned into each mapped v2 tenant.
    """
    index=_migration_row_index(data)

    # Only propagate ownership through entities that are tenant-scoped in v2. This deliberately
    # excludes global catalogs such as software, so a software installation cannot accidentally
    # turn a global catalog row into a tenant-owned row.
    tenant_tables=set()
    for table_name in data.keys():
        target=Base.metadata.tables.get(table_name)
        if target is not None and "organization_id" in target.c:
            tenant_tables.add(table_name)
    tenant_tables.add("companies")

    owners={}
    explicit=set()
    nodes={}
    for table_name, rows in data.items():
        if table_name not in tenant_tables or not isinstance(rows,list):
            continue
        for row in rows:
            if not isinstance(row,dict): continue
            rid=row.get("id")
            if rid is None: continue
            key=(table_name,rid)
            nodes[key]=row
            cur=set()
            if table_name=="companies":
                cur.add(rid); explicit.add(key)
            cid=row.get("company_id")
            if cid is not None:
                cur.add(cid); explicit.add(key)
            owners[key]=cur

    # Build FK edges only between tenant-scoped source entities.
    edges=set()
    for table_name,rowmap in ((t,index.get(t,{})) for t in tenant_tables):
        for rid,row in rowmap.items():
            if (table_name,rid) not in nodes: continue
            for col,(rt,rc) in _migration_fk_map(schema,table_name).items():
                if rt not in tenant_tables or rc!="id": continue
                val=row.get(col)
                if val is None or (rt,val) not in nodes: continue
                a=(table_name,rid); b=(rt,val)
                if a!=b: edges.add((a,b))

    # Fixed-point propagation. Explicitly-owned rows never absorb another company's ownership,
    # but their ownership may flow to unowned related rows. This preserves the "explicit wins"
    # rule while recovering orphan sites/locations/etc.
    changed=True
    rounds=0
    max_rounds=max(8, min(200, len(nodes)+1))
    while changed and rounds < max_rounds:
        changed=False; rounds+=1
        for a,b in edges:
            oa=owners.get(a,set()); ob=owners.get(b,set())
            if a not in explicit:
                nv=oa | ob
                if nv != oa:
                    owners[a]=nv; oa=nv; changed=True
            if b not in explicit:
                nv=ob | oa
                if nv != ob:
                    owners[b]=nv; changed=True

    def resolve(table_name,row):
        if not isinstance(row,dict): return set()
        rid=row.get("id")
        if rid is not None and (table_name,rid) in owners:
            return set(owners[(table_name,rid)])

        # Non-indexed/global rows keep the old forward-resolution behavior.
        result=set()
        if table_name=="companies" and rid is not None:
            result.add(rid)
        cid=row.get("company_id")
        if cid is not None:
            result.add(cid)
            return result
        for col,(rt,rc) in _migration_fk_map(schema,table_name).items():
            val=row.get(col)
            if val is None or rc!="id": continue
            if rt=="companies":
                result.add(val); continue
            if (rt,val) in owners:
                result.update(owners[(rt,val)])
        return result

    return resolve

def _migration_company_summaries(schema, data):
    resolve=_migration_company_resolver(schema,data)
    out=[]
    for c in data.get("companies",[]) or []:
        cid=c.get("id")
        counts={"sites":0,"employees":0,"workplaces":0,"assets":0,"users":0}
        for t,k in (("sites","sites"),("employees","employees"),("workplaces","workplaces"),("assets","assets"),("app_users","users")):
            for row in data.get(t,[]) or []:
                if cid in resolve(t,row): counts[k]+=1
        out.append({"id":cid,"name":c.get("name") or f"Компания {cid}",**counts})
    return out

def _migration_global_conflicts(data, s: Session):
    # Tenant-scoped values are validated after the user maps source companies to target organizations.
    result=[]
    incoming=[r.get("username") for r in data.get("app_users",[]) if r.get("username")]
    if incoming:
        existing=set(s.execute(select(AppUser.username)).scalars().all())
        dup=sorted({str(x) for x in incoming if x in existing and x!="admin-adm"})
        if dup: result.append({"table":"app_users","field":"username","values":dup[:20],"count":len(dup)})
    return result

def _migration_parse_targets(raw_mapping, data, s: Session):
    try:
        mapping=json.loads(raw_mapping or "{}")
    except Exception:
        raise HTTPException(400,"Некорректное сопоставление организаций")
    companies=data.get("companies",[]) or []
    expected={str(c.get("id")) for c in companies if c.get("id") is not None}
    if set(mapping.keys()) != expected:
        missing=sorted(expected-set(mapping.keys()))
        extra=sorted(set(mapping.keys())-expected)
        msg=[]
        if missing: msg.append("не назначены: "+", ".join(missing[:20]))
        if extra: msg.append("лишние: "+", ".join(extra[:20]))
        raise HTTPException(400,"Для каждой компании 1.12 нужно выбрать организацию"+(": "+"; ".join(msg) if msg else ""))
    result={}
    created_by_name={}
    for source_id, spec in mapping.items():
        if not isinstance(spec,dict): raise HTTPException(400,f"Компания {source_id}: некорректное действие")
        mode=(spec.get("mode") or "").strip().lower()
        if mode=="existing":
            try: oid=int(spec.get("organization_id"))
            except Exception: raise HTTPException(400,f"Компания {source_id}: выберите существующую организацию")
            org=s.get(Organization,oid)
            if not org: raise HTTPException(404,f"Компания {source_id}: организация v2 не найдена")
        elif mode=="new":
            name=(spec.get("organization_name") or "").strip()
            if not name: raise HTTPException(400,f"Компания {source_id}: укажите название новой организации")
            key=name.casefold()
            org=created_by_name.get(key) or s.scalar(select(Organization).where(func.lower(Organization.name)==name.lower()))
            if not org:
                org=Organization(name=name,organization_type="managed",is_active=1,service_status="active")
                s.add(org); s.flush()
            created_by_name[key]=org
        else:
            raise HTTPException(400,f"Компания {source_id}: выберите «Новая» или «Существующая»")
        result[int(source_id)]=org
    return result

def _migration_validate_scoped_uniques(data, schema, source_targets, s: Session):
    resolve=_migration_company_resolver(schema,data)
    checks=(("companies","name"),("sites","name"),("workplaces","code"),("assets","inventory_no"))
    issues=[]
    for table_name,field in checks:
        target=Base.metadata.tables.get(table_name)
        if target is None: continue
        seen={}
        for row in data.get(table_name,[]) or []:
            val=row.get(field)
            if val in (None,""): continue
            cids=resolve(table_name,row)
            org_ids={source_targets[c].id for c in cids if c in source_targets}
            if not org_ids and len(set(o.id for o in source_targets.values()))==1:
                org_ids={next(iter(source_targets.values())).id}
            for oid in org_ids:
                key=(oid,str(val).casefold())
                if key in seen:
                    issues.append(f"{table_name}.{field}: «{val}» повторяется внутри одной целевой организации")
                seen[key]=1
                q=select(target.c.id).where(target.c.organization_id==oid)
                if field in ("name","code","inventory_no"):
                    q=q.where(func.lower(target.c[field])==str(val).lower())
                else: q=q.where(target.c[field]==val)
                if s.connection().execute(q.limit(1)).first():
                    issues.append(f"{table_name}.{field}: «{val}» уже существует в выбранной организации")
    return issues[:30]

class MigrationLimitsIn(BaseModel):
    archive_mb: int = DEFAULT_MIGRATION_ARCHIVE_MB
    unpacked_mb: int = DEFAULT_MIGRATION_UNPACKED_MB

@app.get("/api/migration/limits")
def migration_limits_get():
    limits = _migration_limits()
    return {
        **limits,
        "hard_archive_mb": MIGRATION_HARD_ARCHIVE_MB,
        "hard_unpacked_mb": MIGRATION_HARD_UNPACKED_MB,
        "max_files": MIGRATION_MAX_FILES,
    }

@app.put("/api/migration/limits")
def migration_limits_put(body: MigrationLimitsIn):
    if body.archive_mb < 50:
        raise HTTPException(400, "Минимальный лимит архива — 50 МБ")
    if body.archive_mb > MIGRATION_HARD_ARCHIVE_MB:
        raise HTTPException(400, f"Максимальный лимит архива — {MIGRATION_HARD_ARCHIVE_MB} МБ")
    if body.unpacked_mb < body.archive_mb:
        raise HTTPException(400, "Лимит распакованных данных не может быть меньше лимита ZIP")
    if body.unpacked_mb > MIGRATION_HARD_UNPACKED_MB:
        raise HTTPException(400, f"Максимальный лимит распакованных данных — {MIGRATION_HARD_UNPACKED_MB} МБ")
    return {"ok": True, **_save_migration_limits(body.archive_mb, body.unpacked_mb)}

@app.post("/api/migration/import-vault")
async def migration_import_vault(
    file: UploadFile = File(...),
    transfer_password: str = Form(...),
    actor: AppUser = Depends(require_main_admin),
    x_vault_token: Optional[str] = Header(default=None),
    s: Session = Depends(db),
):
    if len(transfer_password or "") < 10:
        raise HTTPException(400, "Пароль переноса должен содержать не менее 10 символов")
    target_key = _vault_session_key(x_vault_token, actor)
    raw = await file.read()
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(413, "Пакет доступов слишком большой")
    try:
        with zipfile.ZipFile(io.BytesIO(raw), "r") as z:
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            encrypted = z.read("vault.enc")
        if manifest.get("format") != "itcontrol-vault-migration" or int(manifest.get("format_version", 0)) != 1:
            raise HTTPException(400, "Это не пакет переноса доступов ИТ.Контроль")
        salt = base64.b64decode(manifest["salt"]); nonce = base64.b64decode(manifest["nonce"])
        transfer_key = _vault_kdf(transfer_password, salt)
        clear = AESGCM(transfer_key).decrypt(nonce, encrypted, b"ITCONTROL-VAULT-MIGRATION-V1")
        payload = json.loads(clear.decode("utf-8"))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, "Не удалось расшифровать пакет доступов. Проверьте временный пароль переноса") from e
    updated=0; created=0; ambiguous=[]
    for item in payload.get("credentials", []):
        legacy_cipher=item.get("legacy_ciphertext"); legacy_nonce=item.get("legacy_nonce")
        row=None
        if legacy_cipher and legacy_nonce:
            matches=s.scalars(select(VaultCredential).where(VaultCredential.secret_ciphertext==legacy_cipher, VaultCredential.secret_nonce==legacy_nonce)).all()
            if len(matches)==1: row=matches[0]
        if row is None:
            q=select(VaultCredential).where(
                VaultCredential.system_name==(item.get("system_name") or ""),
                VaultCredential.username==item.get("username"),
                VaultCredential.address==item.get("address"),
            )
            matches=s.scalars(q).all()
            if len(matches)==1: row=matches[0]
            elif len(matches)>1:
                ambiguous.append(item.get("system_name") or f"legacy#{item.get('legacy_id')}"); continue
        cipher, n = _vault_encrypt(item.get("secret") or "", target_key)
        if row:
            row.secret_ciphertext=cipher; row.secret_nonce=n; row.updated_by=_vault_actor_name(actor); updated+=1
        else:
            rotate_due=None
            if item.get("rotate_due"):
                try: rotate_due=date.fromisoformat(item["rotate_due"])
                except Exception: pass
            row=VaultCredential(system_name=item.get("system_name") or "Без названия", category=item.get("category") or "Прочее", address=item.get("address"), username=item.get("username"), secret_ciphertext=cipher, secret_nonce=n, notes=item.get("notes"), rotate_due=rotate_due, created_by=_vault_actor_name(actor), updated_by=_vault_actor_name(actor))
            s.add(row); created+=1
    _vault_audit(s, actor, "Импорт доступов из 1.12", details=f"Обновлено: {updated}; создано: {created}; неоднозначно: {len(ambiguous)}")
    s.commit()
    return {"ok": True, "updated": updated, "created": created, "ambiguous": ambiguous}

@app.post("/api/migration/preview")
async def migration_preview(file: UploadFile = File(...), s: Session = Depends(db)):
    raw = await file.read()
    manifest, schema, data = _read_migration_package(raw)
    important = {k: len(data.get(k, [])) for k in ["companies","sites","departments","employees","workplaces","assets","software","software_installations","app_users"]}
    orgs=s.scalars(select(Organization).order_by(Organization.name)).all()
    return {
        "ok": True,
        "source_version": manifest.get("source_version"),
        "exported_at": manifest.get("exported_at"),
        "counts": important,
        "companies": _migration_company_summaries(schema,data),
        "organizations": [{"id":x.id,"name":x.name,"status":x.service_status or "active"} for x in orgs],
        "total_rows": sum(len(v) for v in data.values() if isinstance(v,list)),
        "contains_accesses": bool(data.get("app_users")),
        "password_hashes": bool(manifest.get("contains_password_hashes")),
        "conflicts": _migration_global_conflicts(data, s),
    }

@app.post("/api/migration/import")
async def migration_import(file: UploadFile = File(...), target_mapping: str = Form(...), s: Session = Depends(db)):
    raw = await file.read()
    manifest, schema, data = _read_migration_package(raw)
    conflicts=_migration_global_conflicts(data,s)
    if conflicts:
        msg="; ".join(f"{x['table']}.{x['field']}: {x['count']} конфликт(ов)" for x in conflicts)
        raise HTTPException(409,"Импорт остановлен: "+msg)
    backup_file = BACKUP_DIR / f"migration_pre_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{current_version()}.sql"
    try:
        _backup_database(backup_file)
    except Exception as e:
        raise HTTPException(500, f"Импорт не начат: не удалось создать резервную копию базы: {e}")

    source_targets=_migration_parse_targets(target_mapping,data,s)
    scoped_issues=_migration_validate_scoped_uniques(data,schema,source_targets,s)
    if scoped_issues:
        s.rollback()
        raise HTTPException(409,"Конфликты внутри выбранных организаций: "+"; ".join(scoped_issues[:10]))

    resolve_company=_migration_company_resolver(schema,data)
    distinct_target_ids={x.id for x in source_targets.values()}

    # id_maps[table][old_id][organization_context] = new_id. organization_context=None means global row.
    id_maps={}
    inserted={}; reused={}; skipped={}
    conn=s.connection()

    def mapped_fk(rt, old_value, org_context, table_name=None, column_name=None):
        if old_value is None: return None
        by_org=id_maps.get(rt,{}).get(old_value,{})
        if org_context in by_org: return by_org[org_context]
        if None in by_org: return by_org[None]
        vals=set(by_org.values())
        if len(vals)==1: return next(iter(vals))
        relation=f"{table_name}.{column_name}" if table_name and column_name else "внешний ключ"
        if not vals:
            raise ValueError(
                f"{relation}: не найден новый ID для {rt}#{old_value}. "
                "Старый ID из 1.12 не может использоваться в v2; проверьте порядок/полноту связей миграции."
            )
        raise ValueError(f"{relation}: неоднозначная связь {rt}#{old_value} для организации {org_context}")

    try:
        for table_name in _migration_table_order(schema,data):
            target=Base.metadata.tables.get(table_name)
            if target is None: continue
            id_maps.setdefault(table_name,{})
            inserted[table_name]=0; reused[table_name]=0; skipped[table_name]=0
            source_fks=_migration_fk_map(schema,table_name)
            for src in data.get(table_name,[]):
                old_id=src.get("id")
                # Reuse built-in superadmin instead of overwriting current v2 credentials.
                if table_name=="app_users" and src.get("username")=="admin-adm":
                    row=conn.execute(select(target.c.id).where(target.c.username=="admin-adm")).first()
                    if row:
                        if old_id is not None:id_maps[table_name].setdefault(old_id,{})[None]=row[0]
                        reused[table_name]+=1
                        continue

                cids=resolve_company(table_name,src)
                org_contexts=sorted({source_targets[c].id for c in cids if c in source_targets})
                if not org_contexts:
                    # A truly global row (software catalog, system settings, etc.) is inserted once.
                    # Tenant-scoped orphan rows are safe only when the whole migration targets one tenant.
                    if "organization_id" in target.c:
                        if table_name=="app_users" and src.get("role")=="Главный администратор":
                            org_contexts=[None]
                        elif len(distinct_target_ids)==1:
                            org_contexts=[next(iter(distinct_target_ids))]
                        else:
                            raise ValueError(f"{table_name}#{old_id}: запись действительно не связана ни с одной компанией даже через связанные объекты. Импортёр не может безопасно выбрать tenant автоматически.")
                    else:
                        org_contexts=[None]

                for org_context in org_contexts:
                    vals={}
                    for col in target.c:
                        name=col.name
                        if name in ("id","organization_id") or name not in src: continue
                        v=_migration_decode(src.get(name))
                        if name in source_fks and v is not None:
                            rt,_=source_fks[name]
                            v=mapped_fk(rt,v,org_context,table_name,name)
                        vals[name]=v
                    if "organization_id" in target.c:
                        vals["organization_id"]=org_context
                    if table_name=="app_users":
                        role=src.get("role")
                        vals["role"]={"Администратор":"Администратор организации","Сотрудник":"Пользователь"}.get(role,role or "Пользователь")
                    result=conn.execute(target.insert().values(**vals))
                    new_id=result.inserted_primary_key[0] if result.inserted_primary_key else None
                    if old_id is not None and new_id is not None:
                        id_maps[table_name].setdefault(old_id,{})[org_context]=new_id
                    inserted[table_name]+=1

        target_names=sorted({x.name for x in source_targets.values()})
        s.add(AuditLog(action="Миграция 1.12 → v2",details=f"Импорт {manifest.get('source_version')} в организации: {', '.join(target_names)}"))
        s.commit()
    except Exception as e:
        s.rollback()
        raise HTTPException(500,f"Импорт отменён, транзакция откатана: {e}")
    return {
        "ok":True,
        "organizations":[{"id":x.id,"name":x.name} for x in sorted({o.id:o for o in source_targets.values()}.values(),key=lambda z:z.name)],
        "company_mapping":[{"source_company_id":cid,"organization_id":org.id,"organization":org.name} for cid,org in source_targets.items()],
        "inserted":inserted,"reused":reused,"skipped":skipped,"source_version":manifest.get("source_version")
    }


@app.on_event("startup")
def seed():
    Base.metadata.create_all(engine)
    ensure_schema_compatibility()
    with SessionLocal() as s:
        default_org_id=s.scalar(select(Organization.id).where(Organization.is_active==1).order_by(Organization.id))
        if not s.scalar(select(func.count()).select_from(AppUser)):
            s.add_all([
                AppUser(username="admin-adm", display_name="Главный администратор", role="Главный администратор", is_active=1, organization_id=None),
            ])
            s.commit()
        # v1.0.4: один из существующих администраторов становится Главным администратором.
        if not s.scalar(select(AppUser).where(AppUser.role=="Главный администратор")):
            u=s.scalar(select(AppUser).where(AppUser.role=="Администратор", AppUser.is_active==1).order_by(AppUser.id))
            if u:
                u.role="Главный администратор"
                if not u.username.lower().endswith("-adm"):
                    base=re.sub(r"[^a-zA-Z0-9._-]","",u.username) or "admin"
                    candidate=base+"-adm"; n=2
                    while s.scalar(select(AppUser).where(AppUser.username==candidate, AppUser.id!=u.id)):
                        candidate=f"{base}{n}-adm"; n+=1
                    u.username=candidate
                s.commit()
        # Все административные логины должны оканчиваться на -adm.
        changed=False
        # v2 role normalization: preserve the main admin, modernize legacy role labels.
        for u in s.scalars(select(AppUser).where(AppUser.role=="Администратор")).all():
            u.role="Администратор организации"; changed=True
        for u in s.scalars(select(AppUser).where(AppUser.role=="Сотрудник")).all():
            u.role="Пользователь"; changed=True
        s.flush()
        for u in s.scalars(select(AppUser).where(AppUser.role.in_(["Главный администратор","Администратор организации"]))).all():
            if not u.username.lower().endswith("-adm"):
                base=re.sub(r"[^a-zA-Z0-9._-]","",u.username) or "admin"
                candidate=base+"-adm"; n=2
                while s.scalar(select(AppUser).where(AppUser.username==candidate, AppUser.id!=u.id)):
                    candidate=f"{base}{n}-adm"; n+=1
                u.username=candidate; changed=True
        for u in s.scalars(select(AppUser).where(AppUser.role=="Главный администратор")).all():
            if u.organization_id is not None:
                u.organization_id=None; changed=True
        if changed: s.commit()



from app.security import install_security
install_security(app)
