let expenseCache={items:[],summary:{},contractors:[]};
let expenseFilters={q:'',category:'',status:'',from:'',to:''};

function expenseMoney(v,c='RUB'){
 let n=Number(v||0);
 try{return new Intl.NumberFormat('ru-RU',{style:'currency',currency:c||'RUB',maximumFractionDigits:2}).format(n)}
 catch(e){return n.toLocaleString('ru-RU')+' '+(c||'₽')}
}
function expenseOption(v,label,selected){return `<option value="${v}" ${String(v)===String(selected??'')?'selected':''}>${esc(label)}</option>`}
function expenseFiltered(){
 let q=(expenseFilters.q||'').trim().toLowerCase();
 return expenseCache.items.filter(x=>{
  if(expenseFilters.category&&x.category!==expenseFilters.category)return false;
  if(expenseFilters.status&&x.status!==expenseFilters.status)return false;
  if(expenseFilters.from&&x.expense_date<expenseFilters.from)return false;
  if(expenseFilters.to&&x.expense_date>expenseFilters.to)return false;
  if(q&&![
    x.description,x.vendor_name,x.contractor,x.contract,x.employee,x.department,x.site,x.asset,
    x.document_number,x.document_location,x.buyer_name,x.notes
  ].join(' ').toLowerCase().includes(q))return false;
  return true;
 });
}
async function expensesLoad(){
 let [items,summary]=await Promise.all([api('/expenses'),api('/expenses/summary')]);
 let contractors=[];
 try{contractors=await api('/contractors')}catch(e){}
 expenseCache={items,summary,contractors};
}
async function expensesPage(){
 try{await expensesLoad()}catch(e){$('#page').innerHTML=`<div class=panel><b>Расходы недоступны</b><div class=danger>${esc(friendlyError(e.message))}</div></div>`;return}
 let s=expenseCache.summary||{};
 $('#page').innerHTML=`<div class=top><div><h1>Расходы</h1><div style="color:var(--muted);margin-top:5px">Учёт фактических и плановых расходов на ИТ</div></div><div class=contractor-actions>${isOrgAdmin()?'<button class="btn primary" onclick="expenseModal()">＋ Добавить расход</button>':''}<button class=btn onclick="expenseExport()">Excel</button></div></div>
 <div class=expenses-grid>
  <div class=expenses-metric><b>${expenseMoney(s.month_total)}</b><span>Расходы за текущий месяц</span></div>
  <div class=expenses-metric><b>${expenseMoney(s.year_total)}</b><span>Расходы за текущий год</span></div>
  <div class=expenses-metric><b>${Number(s.count||0).toLocaleString('ru-RU')}</b><span>Записей в реестре</span></div>
  <div class=expenses-metric><b>${Number(s.documents_missing||0).toLocaleString('ru-RU')}</b><span>Без места хранения документа</span></div>
 </div>
 <div class=panel>
  <div class=expenses-toolbar>
   <input placeholder="Поиск…" value="${esc(expenseFilters.q)}" oninput="expenseFilters.q=this.value;expensesRenderTable()">
   <select onchange="expenseFilters.category=this.value;expensesRenderTable()"><option value="">Все категории</option>
    ${[['equipment','Оборудование'],['software','ПО и лицензии'],['communications','Связь и интернет'],['repair','Ремонт'],['consumables','Расходники'],['services','Услуги'],['subscription','Подписки'],['leasing','Аренда / лизинг'],['other','Прочее']].map(v=>expenseOption(v[0],v[1],expenseFilters.category)).join('')}
   </select>
   <select onchange="expenseFilters.status=this.value;expensesRenderTable()"><option value="">Все статусы</option>
    ${[['planned','Запланировано'],['paid','Оплачено'],['documents_pending','Ждём документы'],['closed','Закрыто']].map(v=>expenseOption(v[0],v[1],expenseFilters.status)).join('')}
   </select>
   <input type=date title="С даты" value="${expenseFilters.from}" onchange="expenseFilters.from=this.value;expensesRenderTable()">
   <input type=date title="По дату" value="${expenseFilters.to}" onchange="expenseFilters.to=this.value;expensesRenderTable()">
  </div>
  <div id=expensesTable></div>
 </div>`;
 expensesRenderTable();
}
function expensesRenderTable(){
 let b=$('#expensesTable');if(!b)return;
 let xs=expenseFiltered();
 b.innerHTML=xs.length?`<table><thead><tr><th>Дата</th><th>Что купили / оплатили</th><th>Поставщик</th><th>Для кого / чего</th><th>Сумма</th><th>Документы</th><th>Статус</th><th></th></tr></thead><tbody>
 ${xs.map(x=>{
  let target=[x.employee,x.department,x.site,x.asset].filter(Boolean).join(' · ')||'—';
  let vendor=x.contractor||x.vendor_name||'—';
  let doc=[x.document_type,x.document_number?('№ '+x.document_number):'',x.document_date].filter(Boolean).join(' · ');
  let loc=x.document_location?(`<div class=expenses-doc>${/^https?:\/\//i.test(x.document_location)?`<a href="${esc(x.document_location)}" target=_blank rel=noopener>${esc(x.document_location)}</a>`:esc(x.document_location)}</div>`):'<span class=expenses-danger>Не указано</span>';
  return `<tr><td>${esc(x.expense_date)}</td><td><b>${esc(x.description)}</b><div class=contractor-sub>${esc(x.category_label||'')}</div></td><td>${esc(vendor)}${x.contract?`<div class=contractor-sub>Договор ${esc(x.contract)}</div>`:''}</td><td>${esc(target)}</td><td class=expenses-amount>${expenseMoney(x.amount,x.currency)}</td><td>${doc?`<div>${esc(doc)}</div>`:''}${loc}</td><td class="expenses-status-${esc(x.status)}">${esc(x.status_label)}</td><td><div class=expenses-actions>${isOrgAdmin()?`<button class=btn onclick="expenseModal(${x.id})">Изменить</button>`:''}${isMainAdmin()?`<button class="btn danger" onclick="expenseDelete(${x.id})">Удалить</button>`:''}</div></td></tr>`
 }).join('')}</tbody></table>`:'<div class=empty>Расходов пока нет</div>';
}
function expenseContractOptions(selected){
 return '<option value="">— не выбран —</option>'+expenseCache.contractors.map(c=>expenseOption(c.id,c.name,selected)).join('');
}
function expenseContractsFor(contractorId){
 let c=expenseCache.contractors.find(z=>String(z.id)===String(contractorId));
 return c?(c.contracts||[]):expenseCache.contractors.flatMap(z=>z.contracts||[]);
}
function expenseContractSelect(selected,contractorId){
 return '<option value="">— не выбран —</option>'+expenseContractsFor(contractorId).map(c=>expenseOption(c.id,(c.number||'Без номера')+(c.title?' · '+c.title:''),selected)).join('');
}
function expenseRefreshContracts(){
 let f=$('#expenseForm');if(!f)return;
 f.contract_id.innerHTML=expenseContractSelect('',f.contractor_id.value);
}
async function expenseModal(id){
 let x=id?expenseCache.items.find(z=>z.id===id):{};
 let contractorsAvailable=expenseCache.contractors.length>0;
 $('#modal').innerHTML=`<div class=modal><div class=modalbox style="max-width:920px"><h2>${id?'Расход':'Новый расход'}</h2>
 <form id=expenseForm class=grid2>
  <div class=field><label>Дата расхода</label><input type=date name=expense_date required value="${esc(x.expense_date||new Date().toISOString().slice(0,10))}"></div>
  <div class=field><label>Категория</label><select name=category>${[['equipment','Оборудование'],['software','ПО и лицензии'],['communications','Связь и интернет'],['repair','Ремонт'],['consumables','Расходники'],['services','Услуги'],['subscription','Подписки'],['leasing','Аренда / лизинг'],['other','Прочее']].map(v=>expenseOption(v[0],v[1],x.category||'equipment')).join('')}</select></div>
  <div class="field wide"><label>Что купили / за что платили</label><input name=description required value="${esc(x.description||'')}"></div>
  <div class=field><label>Сумма, ₽</label><input type=number step=0.01 min=0 name=amount required value="${x.amount??''}"></div>
  <div class=field><label>Статус</label><select name=status>${[['planned','Запланировано'],['paid','Оплачено'],['documents_pending','Ждём документы'],['closed','Закрыто']].map(v=>expenseOption(v[0],v[1],x.status||'paid')).join('')}</select></div>
  <div class=field><label>Поставщик (текст)</label><input name=vendor_name value="${esc(x.vendor_name||'')}"></div>
  <div class=field><label>Кто купил / инициатор</label><input name=buyer_name value="${esc(x.buyer_name||'')}"></div>
  <div class=field><label>Контрагент${contractorsAvailable?'':' (модуль не подключён)'}</label><select name=contractor_id onchange=expenseRefreshContracts() ${contractorsAvailable?'':'disabled'}>${expenseContractOptions(x.contractor_id)}</select></div>
  <div class=field><label>Договор</label><select name=contract_id ${contractorsAvailable?'':'disabled'}>${expenseContractSelect(x.contract_id,x.contractor_id)}</select></div>
  <div class=field><label>Сотрудник</label><select name=employee_id><option value="">—</option>${(state.employees||[]).map(z=>expenseOption(z.id,z.name,z.id===x.employee_id?z.id:x.employee_id)).join('')}</select></div>
  <div class=field><label>Подразделение</label><select name=department_id><option value="">—</option>${(state.departments||[]).map(z=>expenseOption(z.id,z.name,x.department_id)).join('')}</select></div>
  <div class=field><label>Площадка</label><select name=site_id><option value="">—</option>${(state.sites||[]).map(z=>expenseOption(z.id,z.name,x.site_id)).join('')}</select></div>
  <div class=field><label>Оборудование</label><select name=asset_id><option value="">—</option>${(state.assets||[]).map(z=>expenseOption(z.id,[z.inventory_no,z.manufacturer,z.model].filter(Boolean).join(' · ')||('#'+z.id),x.asset_id)).join('')}</select></div>
  <div class=field><label>Способ оплаты</label><select name=payment_method>${[['bank','Безналичный расчёт'],['corporate_card','Корпоративная карта'],['cash','Наличные'],['personal','Личные средства'],['other','Другое']].map(v=>expenseOption(v[0],v[1],x.payment_method||'bank')).join('')}</select></div>
  <div class=field><label>Тип документа</label><input name=document_type placeholder="Счёт, УПД, акт…" value="${esc(x.document_type||'')}"></div>
  <div class=field><label>№ документа</label><input name=document_number value="${esc(x.document_number||'')}"></div>
  <div class=field><label>Дата документа</label><input type=date name=document_date value="${esc(x.document_date||'')}"></div>
  <div class="field wide"><label>Где хранится документ / ссылка</label><input name=document_location placeholder="\\\\server\\docs\\... или https://..." value="${esc(x.document_location||'')}"></div>
  <div class="field wide"><label>Комментарий</label><textarea name=notes>${esc(x.notes||'')}</textarea></div>
 </form>
 <div class=modalfoot><button class=btn onclick=closeM()>Отмена</button><button class="btn primary" onclick="expenseSave(${id||'null'})">Сохранить</button></div></div></div>`;
}
async function expenseSave(id){
 let f=$('#expenseForm'),o=Object.fromEntries(new FormData(f).entries());
 for(let k of ['contractor_id','contract_id','asset_id','employee_id','department_id','site_id'])o[k]=o[k]?Number(o[k]):null;
 o.amount=Number(o.amount||0);o.currency='RUB';o.document_date=o.document_date||null;
 try{await api('/expenses'+(id?'/'+id:''),{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});closeM();await expensesPage()}
 catch(e){alert(friendlyError(e.message))}
}
async function expenseDelete(id){
 if(!isMainAdmin()){alert('Удаление расходов доступно только Главному администратору');return}
 let x=expenseCache.items.find(z=>z.id===id);
 if(!confirm('Удалить расход «'+(x?.description||id)+'»? Запись попадёт в журнал аудита.'))return;
 try{await api('/expenses/'+id,{method:'DELETE'});await expensesPage()}catch(e){alert(friendlyError(e.message))}
}
async function expenseExport(){
 try{
  let r=await api('/expenses/export.xlsx');
  let blob=await r.blob(),u=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=u;a.download='ITControl_Расходы.xlsx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);
 }catch(e){alert(friendlyError(e.message))}
}
