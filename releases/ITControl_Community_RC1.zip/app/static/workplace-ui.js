/* Progressive enhancement: keep the existing select as the submitted ID. */
(() => {
 let serial=0;
 const normalize=value=>String(value||'').toLocaleLowerCase('ru').replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
 window.enhanceWorkplaceSelectors=root=>{
  if(!root)return;
  for(const source of root.querySelectorAll('select[name="workplace_id"]')){
   if(source.dataset.wpEnhanced)continue;
   const wrap=document.createElement('div');wrap.className='wp-picker';
   const input=document.createElement('input');input.type='text';input.className='wp-picker-input';input.autocomplete='off';input.placeholder='Код, сотрудник, помещение…';input.setAttribute('role','combobox');input.setAttribute('aria-label','Поиск рабочего места');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-expanded','false');
   const clear=document.createElement('button');clear.type='button';clear.className='wp-picker-clear';clear.textContent='×';clear.setAttribute('aria-label','Убрать привязку к рабочему месту');
   const list=document.createElement('div');list.className='wp-picker-list';list.id='wp-options-'+(++serial);list.setAttribute('role','listbox');list.setAttribute('aria-label','Рабочие места');list.hidden=true;input.setAttribute('aria-controls',list.id);
   const hint=document.createElement('small');hint.className='wp-picker-hint';hint.textContent='Поиск по коду, названию, сотруднику, компании и помещению.';
   source.before(wrap);wrap.append(input,clear,list,hint,source);
   let confirmed=source.value,pending=false,active=-1,rendered=[];
   const label=()=>source.selectedOptions[0]?.value?source.selectedOptions[0].textContent:'';
   const catalog=()=>Array.from(source.options).filter(o=>o.value).map(o=>{
    const workplace=state.workplaces.find(w=>String(w.id)===o.value);
    const company=workplace?state.companies.find(c=>c.id===workplace.company_id)?.name||'':'';
    return {value:o.value,code:workplace?.code||o.textContent,detail:[workplace?.employee,workplace?.location,workplace?.name,company].filter(Boolean).join(' · ')||o.textContent,text:normalize([o.textContent,company].join(' '))};
   });
   function close(){list.hidden=true;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');active=-1}
   function sync(){confirmed=source.value;pending=false;input.value=label();input.setCustomValidity('');clear.disabled=source.disabled||!source.value;input.disabled=source.disabled;close()}
   function choose(value){source.value=value;source.dispatchEvent(new Event('change',{bubbles:true}));input.focus();close()}
   function highlight(index){active=index;const options=list.querySelectorAll('[role=option]');options.forEach((option,i)=>{option.setAttribute('aria-selected',String(i===index));option.classList.toggle('wp-active',i===index)});if(options[index]){input.setAttribute('aria-activedescendant',options[index].id);options[index].scrollIntoView?.({block:'nearest'})}}
   function render(query){
    const terms=normalize(query).split(' ').filter(Boolean),matches=catalog().filter(item=>terms.every(term=>item.text.includes(term)));
    rendered=[{value:'',code:'Без рабочего места',detail:'Снять привязку'},...matches.slice(0,80)];
    list.replaceChildren();
    rendered.forEach((item,i)=>{
     const option=document.createElement('div');option.id=list.id+'-'+i;option.className='wp-picker-option';option.setAttribute('role','option');option.setAttribute('aria-selected','false');
     const code=document.createElement('strong');code.textContent=item.code;const detail=document.createElement('small');detail.textContent=item.detail;option.append(code,detail);
     option.onmousedown=event=>event.preventDefault();option.onclick=()=>choose(item.value);list.append(option);
    });
    if(!matches.length){const empty=document.createElement('p');empty.className='wp-picker-empty';empty.textContent='Рабочих мест по запросу не найдено.';list.append(empty)}
    if(matches.length>80){const more=document.createElement('p');more.className='wp-picker-empty';more.textContent=`Показано 80 из ${matches.length}. Уточните запрос.`;list.append(more)}
    active=-1;list.hidden=false;input.setAttribute('aria-expanded','true');input.removeAttribute('aria-activedescendant');
   }
   input.onfocus=()=>{if(!input.disabled){render(pending?input.value:'');if(!pending)input.select()}};
   input.oninput=()=>{pending=true;input.setCustomValidity('Выберите рабочее место из результатов поиска или нажмите ×, чтобы снять привязку.');clear.disabled=false;render(input.value)};
   input.onkeydown=event=>{
    if(event.key==='Escape'){event.preventDefault();source.value=confirmed;sync();return}
    if(event.key==='ArrowDown'||event.key==='ArrowUp'){
     event.preventDefault();if(list.hidden)render(pending?input.value:'');highlight(event.key==='ArrowDown'?(active<0?(rendered.length>1?1:0):Math.min(active+1,rendered.length-1)):(active<0?rendered.length-1:Math.max(active-1,0)));
    }else if(event.key==='Enter'&&!list.hidden){
     event.preventDefault();if(active>=0)choose(rendered[active].value);else if(pending&&rendered.length===2)choose(rendered[1].value);
    }else if(event.key==='Tab')close();
   };
   input.onblur=()=>setTimeout(()=>{if(!wrap.contains(document.activeElement))close()},0);
   clear.onclick=()=>choose('');source.addEventListener('change',sync);
   input.addEventListener('invalid',()=>{render(pending?input.value:'')});
   // Hide only after the enhanced control is ready. If this script is unavailable,
   // the original native selector remains fully usable.
   source.hidden=true;source.tabIndex=-1;source.dataset.wpEnhanced='1';sync();
   source._wpPicker={input,validate(){if(pending){input.reportValidity();input.focus();return false}return true}};
  }
 };
 window.validateWorkplaceSelectors=root=>{
  if(!root)return true;
  for(const select of root.querySelectorAll('select[name="workplace_id"]'))if(select._wpPicker&&!select._wpPicker.validate())return false;
  return true;
 };
})();
