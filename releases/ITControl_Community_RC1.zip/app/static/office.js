/* Office shell uses the existing commands and permissions. No parallel API layer. */
(() => {
 const iconPaths={device:'<rect x="2" y="3" width="20" height="14" rx="1"/><path d="M8 21h8M12 17v4"/>',add:'<rect x="2" y="3" width="16" height="13" rx="1"/><path d="M6 21h8M10 16v5M19 13v9M15 17h8"/>',edit:'<path d="m4 16 12-12 4 4-12 12-5 1zM14 6l4 4"/>',import:'<path d="M14 3H4v18h16V10M14 3v7h6M12 12v7M8 15l4 4 4-4"/>',export:'<path d="M14 3H4v18h16V10M14 3v7h6M8 15h9M14 12l3 3-3 3"/>',grid:'<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 9h18M9 3v18M15 3v18"/>',refresh:'<path d="M20 7a9 9 0 1 0 1 8M20 2v6h-6"/>',print:'<path d="M6 8V2h12v6M6 17H3V8h18v9h-3M6 14h12v8H6zM17 11h1"/>',user:'<circle cx="12" cy="7" r="4"/><path d="M3 22c0-11 18-11 18 0"/>',move:'<path d="M3 7h12M11 3l4 4-4 4M21 17H9M13 13l-4 4 4 4"/>',search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 7 7"/>',menu:'<path d="M4 5h16M4 12h16M4 19h16"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',folder:'<path d="M2 5h8l3 3h9v13H2z"/>'};
 const svg=(name)=>`<svg viewBox="0 0 24 24" aria-hidden="true">${iconPaths[name]||iconPaths.device}</svg>`;
 const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls||'';if(text)n.textContent=text;return n};
 let currentSource=null,selected=null,lastPage='',queued=false;
 const header=el('header','office-header');
 const brand=el('div','office-brand');brand.innerHTML='<img class="office-brand-logo" src="/static/transcepter-symbol.png" alt="Трансцептер системы"><span>ИТКонтроль</span>';header.append(brand,el('span','office-product','Учёт и инвентаризация'));
 const search=el('div','office-search');const oldSearch=document.getElementById('globalSearch');if(oldSearch){search.append(oldSearch.parentElement);oldSearch.placeholder='Поиск оборудования и команд · Ctrl+K'}const userBtn=el('button','office-user','');userBtn.type='button';userBtn.title='Пользователь';userBtn.onclick=()=>userMenuDialog();header.append(search,userBtn);
 const tabs=el('nav','office-tabs');tabs.setAttribute('aria-label','Разделы приложения');
 const ribbon=el('div','office-ribbon');ribbon.setAttribute('aria-label','Лента команд');ribbon.id='officeRibbon';
 const status=el('footer','office-statusbar');status.innerHTML='<span id="officeStatus" role="status"></span><span>ИТ.Контроль Community · RC1</span>';
 document.body.prepend(header,tabs,ribbon);document.querySelector('.app').after(status);
 document.querySelector('.side-head .brand').textContent='Рабочее пространство';document.title='ИТКонтроль · Инвентаризация';
 const tabDefs=[['assets','Главная',['assets','components','printing','servers','software']],['workplaces','Рабочие места',['workplaces']],['organizations','Организация',['organizations','employees','locations']],['maps','Карта',['maps']],['inventory','Инвентаризация',['inventory']],['audit','Журнал',['audit']],['updates','Файл',['updates']]];
 async function go(page){selected=null;state.page=page;try{await render();sync()}catch(e){alert(friendlyError(e.message))}}
 for(const [page,label,pages] of tabDefs){const b=el('button','office-tab',label);b.type='button';b.dataset.pages=pages.join(',');b.onclick=()=>go(page);tabs.append(b)}
 function commandIcon(text){if(/добав|созда|новая|новый/i.test(text))return 'add';if(/импорт/i.test(text))return 'import';if(/excel|экспорт|выгруз/i.test(text))return 'export';if(/колон|список|таблиц/i.test(text))return 'grid';if(/измен|редакт/i.test(text))return 'edit';if(/печа|qr|bar/i.test(text))return 'print';if(/обнов|провер/i.test(text))return 'refresh';if(/сотруд|пользоват/i.test(text))return 'user';return 'device'}
 function decorate(target,icon){target.classList.add('office-action');const i=el('span','office-action-icon');i.innerHTML=svg(icon);target.prepend(i)}
 function group(label){const g=el('div','office-group'),body=el('div','office-group-body');g.append(body,el('div','office-group-title',label));ribbon.append(g);return body}
 function button(body,text,icon,fn,disabled=false){const b=el('button','btn',text);b.type='button';b.disabled=disabled;b.onclick=fn;decorate(b,icon);body.append(b);return b}
 function rebuildCommands(){
  ribbon.replaceChildren();
  const source=document.querySelector('#page > .top .actions, #page > .vault-head .vault-actions');currentSource=source;
  if(source&&source.children.length){
   const g=group('Действия раздела');
   // Keep original controls in each section, including collapsed-ribbon mode.
   // Mirrors contain no cloned inputs/IDs and delegate to the actual current controls.
   for(const original of source.querySelectorAll('button, label.btn, summary.btn, a.btn')){
    const mirror=el('button',original.className,original.textContent.trim());mirror.type='button';
    mirror.disabled=!!original.disabled||original.getAttribute('aria-disabled')==='true';
    mirror.onclick=()=>{
     if(!original.isConnected||original.disabled||original.getAttribute('aria-disabled')==='true')return;
     if(original.matches('label')){
      const input=original.querySelector('input[type=file]');if(input&&!input.disabled)input.click();
     }else if(original.matches('summary')){
      const details=original.closest('details');if(details){details.open=!details.open;original.focus()}
     }else original.click();
    };
    decorate(mirror,commandIcon(original.textContent));g.append(mirror);
   }
  }
  if(state.page==='assets'){
   const g=group('Выбранное оборудование');
   button(g,'Карточка','device',()=>showAsset(selected),!selected);
   button(g,'Изменить','edit',()=>assetModal(selected),!selected);
   button(g,'Печать этикеток','print',()=>printSelectedLabels(),!selectedAssetIds().length);
   button(g,'Передать сотруднику','user',()=>openTransferModal(),!selectedAssetIds().length);
  }
  const general=group('Рабочая область');button(general,'Обновить','refresh',()=>go(state.page));button(general,'Поиск','search',()=>oldSearch?.focus());
  const view=group('Вид');button(view,'Меню','menu',()=>toggleSidebar());
  button(view,'Плотность','grid',()=>{document.body.classList.toggle('office-density-compact');localStorage.setItem('itinv_office_compact',document.body.classList.contains('office-density-compact')?'1':'0');scheduleLayout()});
  if(state.page==='assets')button(view,'Панель сведений','device',()=>{document.body.classList.toggle('office-hide-preview');localStorage.setItem('itinv_office_preview_hidden',document.body.classList.contains('office-hide-preview')?'1':'0');scheduleLayout()});
  button(view,'Свернуть ленту','close',()=>toggleRibbon());
 }
 // Selection refresh leaves section controls and their event handlers intact.
 function updateSelectionCommands(){const g=[...ribbon.querySelectorAll('.office-group')].find(x=>x.querySelector('.office-group-title')?.textContent==='Выбранное оборудование');if(!g)return;const bs=g.querySelectorAll('button');bs[0].disabled=bs[1].disabled=!selected;bs[2].disabled=bs[3].disabled=!selectedAssetIds().length}
 function toggleRibbon(){const hidden=ribbon.classList.toggle('collapsed');localStorage.setItem('itinv_office_ribbon_hidden',hidden?'1':'0');collapse.textContent=hidden?'Развернуть ленту':'Свернуть ленту';collapse.setAttribute('aria-expanded',String(!hidden));scheduleLayout()}
 const collapse=el('button','office-tab','Свернуть ленту');collapse.type='button';collapse.setAttribute('aria-controls','officeRibbon');collapse.setAttribute('aria-expanded','true');collapse.onclick=toggleRibbon;tabs.append(collapse);
 function preview(){
  const table=document.getElementById('assettable');if(state.page!=='assets'||!table)return;
  let panel=table.closest('.panel'),wrap=panel.parentElement;
  if(!wrap.classList.contains('office-assets-workspace')){wrap=el('div','office-assets-workspace');panel.before(wrap);wrap.append(panel);wrap.append(el('aside','office-preview'));wrap.lastElementChild.setAttribute('aria-label','Сведения об оборудовании')}
  const p=wrap.querySelector('.office-preview'),a=state.assets.find(a=>a.id===selected),visible=selected&&document.getElementById('arow'+selected);
  if(!a||!visible){selected=null;const markup='<h2>Сведения об оборудовании</h2><div class="office-device-icon">'+svg('device')+'</div><p class="office-preview-empty">Выберите строку в таблице, чтобы увидеть сведения об устройстве. Двойной щелчок откроет полную карточку.</p>';if(p.dataset.signature!=='empty'){p.dataset.signature='empty';p.innerHTML=markup}return}
  const name=[a.manufacturer,a.model].filter(Boolean).join(' ')||a.category;
  const fields=[['Компания',state.companies.find(c=>c.id===a.company_id)?.name||a.company],['Площадка',a.site||state.sites.find(s=>s.id===a.site_id)?.name],['Рабочее место',workplaceLabel(state.workplaces.find(w=>w.id===a.workplace_id))],['Ответственный',a.employee],['Серийный номер',a.serial_no]];
  const markup=`<h2>${esc(name)}</h2><div class="office-device-icon">${equipmentIcon(a.category,64)}</div><b>${esc(a.inventory_no)}</b><p><span class="tag">${esc(a.status||'Не указан')}</span></p><dl>${fields.map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v||'Не указано')}</dd></div>`).join('')}</dl><div class="office-preview-actions"><button class="btn primary" onclick="showAsset(${a.id})">Открыть карточку</button><button class="btn" onclick="assetModal(${a.id})">Изменить</button></div>`;
  const signature=JSON.stringify([a,fields]);if(p.dataset.signature!==signature){p.dataset.signature=signature;p.innerHTML=markup}
 }
 window.officeSelectAsset=(id)=>{selected=id;document.querySelectorAll('#assettable tbody tr').forEach(r=>r.classList.toggle('asset-row-selected',r.id==='arow'+id));preview();updateSelectionCommands();updateStatus()};
 function updateStatus(){const heading=document.querySelector('#page h1')?.textContent||'Рабочее пространство';let text=heading;if(state.page==='assets')text+=` · Всего: ${state.assets.length} · В списке: ${document.querySelectorAll('#assettable tbody tr').length} · Отмечено: ${selectedAssetIds().length}`;const s=document.getElementById('officeStatus');if(s.textContent!==text)s.textContent=text}
 // Bound every list to the workspace, preserving the original table and handlers.
 const main=document.querySelector('.main'),page=document.getElementById('page');
 let layoutFrame=0;
 function scheduleLayout(){
  if(!layoutFrame)layoutFrame=requestAnimationFrame(()=>{layoutFrame=0;fitLists()});
 }
 function fitLists(){
  if(!main||!page)return;
  const narrow=matchMedia('(max-width:620px), (max-height:540px)').matches;
  for(const table of page.querySelectorAll('table')){
   // Modal content lives outside #page. Do not wrap table internals or move controls.
   let region=table.parentElement;
   if(!region.classList.contains('office-scroll-region')){
    const standalone=region.children.length===1&&region.tagName==='DIV'&&!region.classList.contains('panel');
    if(!standalone){region=el('div','office-scroll-region');table.before(region);region.append(table)}
    else region.classList.add('office-scroll-region');
    region.tabIndex=0;
    region.setAttribute('role','region');
    region.setAttribute('aria-label','Таблица: '+(page.querySelector('h1')?.textContent||'данные'));
   }
  }
  const mainRect=main.getBoundingClientRect();
  for(const region of page.querySelectorAll('.office-scroll-region, .workspace-list, .office-preview')){
   const logicalTop=region.getBoundingClientRect().top-mainRect.top+main.scrollTop;
   // Keep a useful minimum; the workspace itself scrolls if filters need more room.
   const available=Math.max(180,Math.floor(main.clientHeight-logicalTop-24));
   region.style.maxHeight=narrow?'none':available+'px';
   if(region.matches('.workspace-list')){region.classList.add('office-card-scroll');region.tabIndex=0;region.setAttribute('aria-label','Список карточек')}
  }
 }
 window.addEventListener('resize',scheduleLayout);
 if(window.visualViewport)window.visualViewport.addEventListener('resize',scheduleLayout);
 if(window.ResizeObserver){
  const resizeObserver=new ResizeObserver(scheduleLayout);
  [main,header,tabs,ribbon,status].filter(Boolean).forEach(n=>resizeObserver.observe(n));
 }
 function sync(){
  const source=document.querySelector('#page > .top .actions, #page > .vault-head .vault-actions');
  if(source!==currentSource||state.page!==lastPage){selected=null;lastPage=state.page;rebuildCommands()}
  tabs.querySelectorAll('[data-pages]').forEach(t=>{const active=t.dataset.pages.split(',').includes(state.page);t.classList.toggle('active',active);t.setAttribute('aria-current',active?'page':'false')});
  const user=header.querySelector('.office-user'),cu=currentUser(),name=cu?(cu.display_name+' ▾'):'Войти';if(user.textContent!==name)user.textContent=name;
  preview();updateSelectionCommands();updateStatus();scheduleLayout();
 }
 const observer=new MutationObserver(()=>{if(!queued){queued=true;queueMicrotask(()=>{queued=false;sync()})}});observer.observe(document.getElementById('page'),{childList:true,subtree:true});
 document.getElementById('page').addEventListener('change',()=>{updateSelectionCommands();updateStatus()});
 document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key==='F1'){e.preventDefault();toggleRibbon()}});
 if(localStorage.getItem('itinv_office_compact')==='1')document.body.classList.add('office-density-compact');
 if(localStorage.getItem('itinv_office_preview_hidden')==='1')document.body.classList.add('office-hide-preview');
 if(localStorage.getItem('itinv_office_ribbon_hidden')==='1')toggleRibbon();sync();
})();
