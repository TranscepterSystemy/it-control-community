// DEMO SYMBOL TEST5 FINAL
// IT.Control equipment icons · exact demo symbols + matching extensions
(() => {
  const clean=v=>String(v||"").replace(/[<&]/g,"");

  const defs = `
  <svg id="itc-equipment-svg-defs" class="svg-defs" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
       style="position:absolute;width:0;height:0;overflow:hidden">
    <!-- Exact symbols from it-controller.ru demo source -->
    <symbol id="i-monitor" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/></symbol>
    <symbol id="i-laptop" viewBox="0 0 24 24"><path d="M5 16V5a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v11M2 16h20l-2 4H4z"/></symbol>
    <symbol id="i-server" viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="8" rx="2"/><rect x="4" y="13" width="16" height="8" rx="2"/><path d="M8 7h.01M8 17h.01m4-10h4m-4 10h4"/></symbol>
    <symbol id="i-printer" viewBox="0 0 24 24"><path d="M7 8V3h10v5M7 17H4V8h16v9h-3M7 14h10v7H7zM16 11h1"/></symbol>

    <!-- IT.Control extensions in the same 24x24 line language -->
    <symbol id="i-desktop" viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M9.5 7h5M9.5 10h5M9.5 13h3M12 17.5h.01"/></symbol>
    <symbol id="i-aio" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="13" rx="2"/><path d="M8 21h8m-4-5v5"/><path d="M17.5 13.5h.01"/></symbol>
    <symbol id="i-mini-pc" viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="14" rx="3"/><path d="M7 9h6M7 12h4M16.5 15.5h.01"/></symbol>
    <symbol id="i-mfp" viewBox="0 0 24 24"><path d="M7 6V3h10l2 3v3M7 17H4V8h16v9h-3M7 14h10v7H7zM15.5 11h1.5"/><path d="M8 5h8"/></symbol>
    <symbol id="i-plotter" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="9" rx="2"/><path d="M6 3h12v7M7 15v6m10-6v6M4 21h6m4 0h6"/></symbol>
    <symbol id="i-scanner" viewBox="0 0 24 24"><path d="m5 11 5-7h9l-4 7z"/><path d="M5 11h10l4 8H3zM6 15h9"/></symbol>
    <symbol id="i-barcode-scanner" viewBox="0 0 24 24"><path d="M5 4h11l3 4-7 5-7-3zM10 13l3 8H9l-2-7z"/><path d="M8 7h6"/></symbol>
    <symbol id="i-rack" viewBox="0 0 24 24"><rect x="4" y="2" width="16" height="20" rx="2"/><rect x="7" y="5" width="10" height="3" rx=".5"/><rect x="7" y="10.5" width="10" height="3" rx=".5"/><rect x="7" y="16" width="10" height="3" rx=".5"/><path d="M9 6.5h4M9 12h4M9 17.5h4"/></symbol>
    <symbol id="i-nas" viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 4v16m6-16v16M6.5 17h.01M11.5 17h.01M16.5 17h.01"/></symbol>
    <symbol id="i-ups" viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><rect x="9.5" y="6" width="5" height="4" rx=".5"/><path d="m12 6.8-1 1.5h1.7l-1 1.5"/><circle cx="12" cy="17" r="1.2"/></symbol>
    <symbol id="i-router" viewBox="0 0 24 24"><path d="M7 10V3m10 7V3"/><rect x="3" y="10" width="18" height="10" rx="2"/><path d="M5 6q2-2 4 0m6 0q2-2 4 0M7 15h.01m4 0h.01m4 0h.01"/></symbol>
    <symbol id="i-ap" viewBox="0 0 24 24"><ellipse cx="12" cy="15.5" rx="8" ry="4.5"/><path d="M6.5 7q5.5-5 11 0M9 9.5q3-3 6 0M11 12q1-1 2 0"/><path d="M12 17.5h.01"/></symbol>
    <symbol id="i-switch" viewBox="0 0 24 24"><rect x="2.5" y="7" width="19" height="10" rx="2"/><path d="M5 11h2v2H5zm4 0h2v2H9zm4 0h2v2h-2zm4 0h2v2h-2z"/></symbol>
    <symbol id="i-phone" viewBox="0 0 24 24"><path d="M5 5q5-3 10 0l-2 4-3-1-3 2z"/><rect x="9" y="8" width="11" height="12" rx="2"/><rect x="11.5" y="10" width="5" height="3" rx=".5"/><path d="M12 16h.01m2 0h.01m2 0h.01M12 18h.01m2 0h.01m2 0h.01"/></symbol>
    <symbol id="i-camera" viewBox="0 0 24 24"><path d="M4 8h13l3 2.5-3 4.5H4z"/><circle cx="15.5" cy="11.5" r="2.5"/><path d="M7 15v5M4 21h7"/></symbol>
    <symbol id="i-projector" viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="10" rx="2"/><circle cx="15.5" cy="12" r="2.5"/><path d="M6 10h4M6 18v2m12-2v2"/></symbol>
    <symbol id="i-panel" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="14" rx="2"/><path d="m6 14 4-4 3 2 5-6M12 17v4M8 21h8"/></symbol>
    <symbol id="i-tablet" viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M12 19h.01"/></symbol>
    <symbol id="i-generic" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 12h8m-4-4v8"/></symbol>
  </svg>`;

  function ensureDefs(){
    if(typeof document==="undefined") return;
    if(document.getElementById("itc-equipment-svg-defs")) return;
    document.body.insertAdjacentHTML("afterbegin", defs);
  }

  function normalizeEquipmentCategory(category,hint=""){
    const c=String(category||"").trim().toLowerCase().replace(/ё/g,"е");
    const h=String(hint||"").trim().toLowerCase().replace(/ё/g,"е");
    if(/\b(c?ap\s*xl|cap\b|wap\b|access\s*point|точк[аи]\s+доступа)\b/i.test(h))return "точка доступа";
    if(/\brb[-\s]?5009|rb5009|router|маршрутизатор/i.test(h))return "маршрутизатор";
    if(/\b(crs|css)\d|switch|коммутатор/i.test(h))return "коммутатор";
    const aliases=[
      [/^(mfp|mfd|многофункц|мфу)/,"мфу"],[/^(printer|принтер)/,"принтер"],
      [/^(plotter|плоттер)/,"плоттер"],[/^(barcode scanner|сканер штрих)/,"сканер штрихкодов"],
      [/^(scanner|сканер)/,"сканер"],[/^(laptop|notebook|ноутбук)/,"ноутбук"],
      [/^(monitor|display|монитор)/,"монитор"],[/^(rack|server rack|серверная стойка|стойка)/,"серверная стойка"],
      [/^(server|сервер)/,"сервер"],[/^(router|маршрутизатор|роутер)/,"маршрутизатор"],
      [/^(access point|ap$|точка доступа)/,"точка доступа"],[/^(switch|коммутатор)/,"коммутатор"],
      [/^(nas|сетевое хранилище)/,"nas"],[/^(ups|ибп)/,"ибп"],[/^(ip phone|voip phone|ip-телефон|ip телефон)/,"ip телефон"],
      [/^(phone|телефон)/,"телефон"],[/^(camera|ip camera|камера|видеокамера)/,"камера"],
      [/^(projector|проектор)/,"проектор"],[/^(interactive panel|интерактивная панель)/,"интерактивная панель"],
      [/^(tablet|планшет)/,"планшет"],[/^(mini ?pc|минипк|мини-пк)/,"минипк"],
      [/^(all-in-one|aio|моноблок)/,"моноблок"],[/^(desktop|workstation|pc$|пк$|компьютер|системный блок)/,"системный блок"]
    ];
    for(const [re,v] of aliases)if(re.test(c))return v;
    return c;
  }

  function symbolFor(category,hint=""){
    const c=normalizeEquipmentCategory(category,hint);
    return ({
      "монитор":"i-monitor","ноутбук":"i-laptop","сервер":"i-server","принтер":"i-printer",
      "системный блок":"i-desktop","моноблок":"i-aio","минипк":"i-mini-pc","мфу":"i-mfp",
      "плоттер":"i-plotter","сканер":"i-scanner","сканер штрихкодов":"i-barcode-scanner",
      "серверная стойка":"i-rack","nas":"i-nas","ибп":"i-ups","маршрутизатор":"i-router",
      "точка доступа":"i-ap","коммутатор":"i-switch","ip телефон":"i-phone","телефон":"i-phone",
      "камера":"i-camera","проектор":"i-projector","интерактивная панель":"i-panel","планшет":"i-tablet"
    })[c]||"i-generic";
  }

  function equipmentIcon(category,size=30,title="",hint=""){
    ensureDefs();
    const id=symbolFor(category,hint);
    const t=title?`<title>${clean(title)}</title>`:"";
    return `<svg class="itc-equipment-svg" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${t}<use href="#${id}"></use></svg>`;
  }

  if(typeof document!=="undefined"){
    if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",ensureDefs,{once:true});
    else ensureDefs();
  }

  window.normalizeEquipmentCategory=normalizeEquipmentCategory;
  window.equipmentIcon=equipmentIcon;
  window.equipmentSymbolFor=symbolFor;
})();