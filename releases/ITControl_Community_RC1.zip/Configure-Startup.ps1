# Windows PowerShell 5.1 compatible. Stdout contains no credentials.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$envPath = Join-Path $PSScriptRoot '.env'

function Read-Setting([string] $name) {
    $matches = [regex]::Matches($script:config, '(?m)^' + [regex]::Escape($name) + '=([^\r\n]*)')
    if ($matches.Count -gt 0) { return $matches[$matches.Count - 1].Groups[1].Value.Trim() }
    return ''
}

function Write-Setting([string] $name, [string] $value) {
    $pattern = '(?m)^' + [regex]::Escape($name) + '=[^\r\n]*\r?\n?'
    $script:config = [regex]::Replace($script:config, $pattern, '')
    $script:config = $script:config.TrimEnd() + [Environment]::NewLine + $name + '=' + $value + [Environment]::NewLine
}

function New-LocalSecret {
    $bytes = New-Object byte[] 32
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
    return [BitConverter]::ToString($bytes).Replace('-', '').ToLowerInvariant()
}

function Find-FreePort {
    foreach ($candidate in 8096..8195) {
        $listener = $null
        try {
            $listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Any, $candidate)
            $listener.Start()
            return $candidate
        } catch [Net.Sockets.SocketException] {
            # Includes reserved Windows/Hyper-V ports as well as occupied ports.
        } finally {
            if ($null -ne $listener) { $listener.Stop() }
        }
    }
    # Windows may reserve the entire preferred range. Ask the OS for a usable port.
    $listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Any, 0)
    try {
        $listener.Start()
        return $listener.LocalEndpoint.Port
    } finally { $listener.Stop() }
}

function Read-PreviousDocker([string[]] $arguments) {
    $ErrorActionPreference = 'Continue'
    $lines = & docker @arguments 2>$null
    if ($LASTEXITCODE -eq 0) { return $lines }
}

try {
    if (-not (Test-Path -LiteralPath $envPath)) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.env.example') -Destination $envPath
    }
    $script:config = [IO.File]::ReadAllText($envPath)
    $password = Read-Setting 'POSTGRES_PASSWORD'
    if (-not $password) {
        $oldEnv = Read-PreviousDocker @('inspect', '-f', '{{range .Config.Env}}{{println .}}{{end}}', 'itcontrol-community-rc-db-1')
        if ($oldEnv) {
            foreach ($line in $oldEnv) {
                if ($line -match '^POSTGRES_PASSWORD=(.+)$') { $password = $Matches[1] }
            }
        }
        if (-not $password) { $password = New-LocalSecret }
    }
    Write-Setting 'POSTGRES_PASSWORD' $password

    $token = Read-Setting 'ITCONTROL_SETUP_TOKEN'
    if (-not $token) { $token = New-LocalSecret }
    Write-Setting 'ITCONTROL_SETUP_TOKEN' $token

    $portText = Read-Setting 'WEB_PORT'
    if (-not $portText) {
        $oldPorts = Read-PreviousDocker @('port', 'itcontrol-community-rc-web-1', '8000/tcp')
        if ($oldPorts) {
            foreach ($line in $oldPorts) {
                if ($line -match ':(\d+)$') { $portText = $Matches[1]; break }
            }
        }
    }
    if ($portText) {
        $port = 0
        if (-not [int]::TryParse($portText, [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
            throw 'WEB_PORT in .env must be an integer between 1 and 65535.'
        }
    } else {
        $port = Find-FreePort
    }
    Write-Setting 'WEB_PORT' ([string]$port)
    $temporary = $envPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, $script:config, (New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $temporary -Destination $envPath -Force
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
    Write-Output ('Startup configuration ready. Port ' + $port)
    exit 0
} catch {
    [Console]::Error.WriteLine('Startup configuration failed: ' + $_.Exception.Message)
    exit 1
}
